#SNP Interaction Pattern Identifier (SIPI)
###function for 9 patterns

.SNP_int_9_c = function(Outcome,Adata,Bdata,a,b,X,TestType){
  wholeABData = cbind(Outcome,Adata[,a],Bdata[,b],X)
  wholeABData = wholeABData[complete.cases(wholeABData),]
  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  X = wholeABData[,4:dim(wholeABData)[2]]
  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  data_OAB = data.frame(Outcome=Outcome,Adata=Adata,Bdata=Bdata,
                        rAdata=rAdata,rBdata=rBdata)
  data_OABX = cbind(data_OAB,X)

  model1_for = as.formula(paste("Outcome~Adata+Bdata+Adata:Bdata+",
                                paste(colnames(X), collapse= "+")))
  model1 = glm(model1_for,data=data_OABX,family="binomial")

  model2_for = as.formula(paste("Outcome~Adata+Adata:Bdata+",
                                paste(colnames(X), collapse= "+")))
  model2 = glm(model2_for,data=data_OABX,family="binomial")

  model3_for = as.formula(paste("Outcome~rAdata+rAdata:Bdata+",
                                paste(colnames(X), collapse= "+")))
  model3 = glm(model3_for,data=data_OABX,family="binomial")

  model4_for = as.formula(paste("Outcome~Bdata+Adata:Bdata+",
                                paste(colnames(X), collapse= "+")))
  model4 = glm(model4_for,data=data_OABX,family="binomial")

  model5_for = as.formula(paste("Outcome~rBdata+Adata:rBdata+",
                                paste(colnames(X), collapse= "+")))
  model5 = glm(model5_for,data=data_OABX,family="binomial")

  model6_for = as.formula(paste("Outcome~Adata:Bdata+",
                                paste(colnames(X), collapse= "+")))
  model6 = glm(model6_for,data=data_OABX,family="binomial")

  model7_for = as.formula(paste("Outcome~rAdata:Bdata+",
                                paste(colnames(X), collapse= "+")))
  model7 = glm(model7_for,data=data_OABX,family="binomial")

  model8_for = as.formula(paste("Outcome~Adata:rBdata+",
                                paste(colnames(X), collapse= "+")))
  model8 = glm(model8_for,data=data_OABX,family="binomial")

  model9_for = as.formula(paste("Outcome~rAdata:rBdata+",
                                paste(colnames(X), collapse= "+")))
  model9 = glm(model9_for,data=data_OABX,family="binomial")

  biccon = log(length(Outcome))
  lenX = dim(X)[2]
  model0_for = as.formula(paste("Outcome~",
                                paste(colnames(X), collapse= "+")))
  model0 = glm(model0_for,data=data_OABX,family="binomial")

  if (is.na(model1$coefficients[length(model1$coefficients)])){
    coef1 = c(NA,NA)
    bic1 = NA
    Sta1 = c(NA,NA)
  }else{
    coef1 = summary(model1)$coefficients[(4+lenX),c(1,2)]
    bic1 = extractAIC(model1,k=biccon)[2]
    model1_for = as.formula(paste("Outcome~Adata+Bdata+",
                                  paste(colnames(X), collapse= "+")))
    if (TestType=='WaldTest'){
      anova1 = unlist(waldtest(glm(model1_for,data=data_OABX,family="binomial"),model1,test="Chisq"))
      Sta1 = c(anova1["Chisq2"],anova1["Pr(>Chisq)2"])
    }else{
      anova1 = unlist(lrtest(glm(model1_for,data=data_OABX,family="binomial"),model1))
      Sta1 = c(anova1["Chisq2"],anova1["Pr(>Chisq)2"])
    }
  }
  if (is.na(model2$coefficients[length(model2$coefficients)])){
    coef2 = c(NA,NA)
    bic2 = NA
    Sta2 = c(NA,NA)
  }else{
    coef2 = summary(model2)$coefficients[(3+lenX),c(1,2)]
    bic2 = extractAIC(model2,k=biccon)[2]
    model2_for = as.formula(paste("Outcome~Adata+",
                                  paste(colnames(X), collapse= "+")))
    if (TestType=='WaldTest'){
      anova2 = unlist(waldtest(glm(model2_for,data=data_OABX,family="binomial"),model2,test="Chisq"))
      Sta2 = c(anova2["Chisq2"],anova2["Pr(>Chisq)2"])
    }else{
      anova2 = unlist(lrtest(glm(model2_for,data=data_OABX,family="binomial"),model2))
      Sta2 = c(anova2["Chisq2"],anova2["Pr(>Chisq)2"])
    }
  }
  if (is.na(model3$coefficients[length(model3$coefficients)])){
    coef3 = c(NA,NA)
    bic3 = NA
    Sta3 = c(NA,NA)
  }else{
    coef3 = summary(model3)$coefficients[(3+lenX),c(1,2)]
    bic3 = extractAIC(model3,k=biccon)[2]
    model3_for = as.formula(paste("Outcome~rAdata+",
                                  paste(colnames(X), collapse= "+")))
    if (TestType=='WaldTest'){
      anova3 = unlist(waldtest(glm(model3_for,data=data_OABX,family="binomial"),model3,test="Chisq"))
      Sta3 = c(anova3["Chisq2"],anova3["Pr(>Chisq)2"])
    }else{
      anova3 = unlist(lrtest(glm(model3_for,data=data_OABX,family="binomial"),model3))
      Sta3 = c(anova3["Chisq2"],anova3["Pr(>Chisq)2"])
    }
  }
  if (is.na(model4$coefficients[length(model4$coefficients)])){
    coef4 = c(NA,NA)
    bic4 = NA
    Sta4 = c(NA,NA)
  }else{
    coef4 = summary(model4)$coefficients[(3+lenX),c(1,2)]
    bic4 = extractAIC(model4,k=biccon)[2]
    model4_for = as.formula(paste("Outcome~Bdata+",
                                  paste(colnames(X), collapse= "+")))
    if (TestType=='WaldTest'){
      anova4 = unlist(waldtest(glm(model4_for,data=data_OABX,family="binomial") ,model4,test="Chisq"))
      Sta4 = c(anova4["Chisq2"],anova4["Pr(>Chisq)2"])
    }else{
      anova4 = unlist(lrtest(glm(model4_for,data=data_OABX,family="binomial") ,model4))
      Sta4 = c(anova4["Chisq2"],anova4["Pr(>Chisq)2"])
    }
  }
  if (is.na(model5$coefficients[length(model5$coefficients)])){
    coef5 = c(NA,NA)
    bic5 = NA
    Sta5 = c(NA,NA)
  }else{
    coef5 = summary(model5)$coefficients[(3+lenX),c(1,2)]
    bic5 = extractAIC(model5,k=biccon)[2]
    model5_for = as.formula(paste("Outcome~rBdata+",
                                  paste(colnames(X), collapse= "+")))
    if (TestType=='WaldTest'){
      anova5 = unlist(waldtest(glm(model5_for,data=data_OABX,family="binomial"),model5,test="Chisq"))
      Sta5 = c(anova5["Chisq2"],anova5["Pr(>Chisq)2"])
    }else{
      anova5 = unlist(lrtest(glm(model5_for,data=data_OABX,family="binomial"),model5))
      Sta5 = c(anova5["Chisq2"],anova5["Pr(>Chisq)2"])
    }
  }
  if (is.na(model6$coefficients[length(model6$coefficients)])){
    coef6 = c(NA,NA)
    bic6 = NA
    Sta6 = c(NA,NA)
  }else{
    coef6 = summary(model6)$coefficients[(2+lenX),c(1,2)]
    bic6 = extractAIC(model6,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova6 = unlist(waldtest(model0,model6,test="Chisq"))
      Sta6 = c(anova6["Chisq2"],anova6["Pr(>Chisq)2"])
    }else{
      anova6 = unlist(lrtest(model0,model6))
      Sta6 = c(anova6["Chisq2"],anova6["Pr(>Chisq)2"])
    }
  }
  if (is.na(model7$coefficients[length(model7$coefficients)])){
    coef7= c(NA,NA)
    bic7 = NA
    Sta7 = c(NA,NA)
  }else{
    coef7 = summary(model7)$coefficients[(2+lenX),c(1,2)]
    bic7 = extractAIC(model7,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova7 = unlist(waldtest(model0,model7,test="Chisq"))
      Sta7 = c(anova7["Chisq2"],anova7["Pr(>Chisq)2"])
    }else{
      anova7 = unlist(lrtest(model0,model7))
      Sta7 = c(anova7["Chisq2"],anova7["Pr(>Chisq)2"])
    }
  }
  if (is.na(model8$coefficients[length(model8$coefficients)])){
    coef8 = c(NA,NA)
    bic8 = NA
    Sta8 = c(NA,NA)
  }else{
    coef8 = summary(model8)$coefficients[(2+lenX),c(1,2)]
    bic8 = extractAIC(model8,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova8 = unlist(waldtest(model0,model8,test="Chisq"))
      Sta8 = c(anova8["Chisq2"],anova8["Pr(>Chisq)2"])
    }else{
      anova8 = unlist(lrtest(model0,model8))
      Sta8 = c(anova8["Chisq2"],anova8["Pr(>Chisq)2"])
    }
  }
  if (is.na(model9$coefficients[length(model9$coefficients)])){
    coef9 = c(NA,NA)
    bic9 = NA
    Sta9 = c(NA,NA)
  }else{
    coef9 = summary(model9)$coefficients[(2+lenX),c(1,2)]
    bic9 = extractAIC(model9,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova9 = unlist(waldtest(model0,model9,test="Chisq"))
      Sta9 = c(anova9["Chisq2"],anova9["Pr(>Chisq)2"])
    }else{
      anova9 = unlist(lrtest(model0,model9))
      Sta9 = c(anova9["Chisq2"],anova9["Pr(>Chisq)2"])

    }
  }

  Res=rbind(
    c(coef1,Sta1,bic1),
    c(coef2,Sta2,bic2),
    c(coef3,Sta3,bic3),
    c(coef4,Sta4,bic4),
    c(coef5,Sta5,bic5),
    c(coef6,Sta6,bic6),
    c(coef7,Sta7,bic7),
    c(coef8,Sta8,bic8),
    c(coef9,Sta9,bic9)
  )
  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (TestType=='WaldTest'){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}





.SNP_int_9_nc = function(Outcome,Adata,Bdata,a,b,TestType){
  wholeABData = cbind(Outcome,Adata[,a],Bdata[,b])
  wholeABData = wholeABData[complete.cases(wholeABData),]
  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }

  model1 = glm(Outcome~Adata+Bdata+Adata:Bdata,family="binomial")
  model2 = glm(Outcome~Adata+Adata:Bdata,family="binomial")
  model3 = glm(Outcome~rAdata+rAdata:Bdata,family="binomial")
  model4 = glm(Outcome~Bdata+Adata:Bdata,family="binomial")
  model5 = glm(Outcome~rBdata+Adata:rBdata,family="binomial")
  model6 = glm(Outcome~Adata:Bdata,family="binomial")
  model7 = glm(Outcome~rAdata:Bdata,family="binomial")
  model8 = glm(Outcome~Adata:rBdata,family="binomial")
  model9 = glm(Outcome~rAdata:rBdata,family="binomial")

  biccon = log(length(Outcome))

  model0 = glm(Outcome~1,family="binomial")
  if (dim(summary(model1)$coefficients)[1]<4){
    coef1 = c(NA,NA)
    bic1 = NA
    Sta1 = c(NA,NA)
  }else{
    coef1 = summary(model1)$coefficients[4,c(1,2)]
    bic1 = extractAIC(model1,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova1 = unlist(waldtest(glm(Outcome~Adata+Bdata,family="binomial"),model1,test="Chisq"))
      Sta1 = c(anova1["Chisq2"],anova1["Pr(>Chisq)2"])
    }else{
      anova1 = unlist(lrtest(glm(Outcome~Adata+Bdata,family="binomial"),model1))
      Sta1 = c(anova1["Chisq2"],anova1["Pr(>Chisq)2"])
    }
  }
  if (dim(summary(model2)$coefficients)[1]<3){
    coef2 = c(NA,NA)
    bic2 = NA
    Sta2 = c(NA,NA)
  }else{
    coef2 = summary(model2)$coefficients[3,c(1,2)]
    bic2 = extractAIC(model2,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova2 = unlist(waldtest(glm(Outcome~Adata,family="binomial"),model2,test="Chisq"))
      Sta2 = c(anova2["Chisq2"],anova2["Pr(>Chisq)2"])
    }else{
      anova2 = unlist(lrtest(glm(Outcome~Adata,family="binomial"),model2))
      Sta2 = c(anova2["Chisq2"],anova2["Pr(>Chisq)2"])
    }
  }
  if (dim(summary(model3)$coefficients)[1]<3){
    coef3 = c(NA,NA)
    bic3 = NA
    Sta3 = c(NA,NA)
  }else{
    coef3 = summary(model3)$coefficients[3,c(1,2)]
    bic3 = extractAIC(model3,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova3 = unlist(waldtest(glm(Outcome~rAdata,family="binomial"),model3,test="Chisq"))
      Sta3 = c(anova3["Chisq2"],anova3["Pr(>Chisq)2"])
    }else{
      anova3 = unlist(lrtest(glm(Outcome~rAdata,family="binomial"),model3))
      Sta3 = c(anova3["Chisq2"],anova3["Pr(>Chisq)2"])
    }
  }
  if (dim(summary(model4)$coefficients)[1]<3){
    coef4 = c(NA,NA)
    bic4 = NA
    Sta4 = c(NA,NA)
  }else{
    coef4 = summary(model4)$coefficients[3,c(1,2)]
    bic4 = extractAIC(model4,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova4 = unlist(waldtest(glm(Outcome~Bdata,family="binomial") ,model4,test="Chisq"))
      Sta4 = c(anova4["Chisq2"],anova4["Pr(>Chisq)2"])
    }else{
      anova4 = unlist(lrtest(glm(Outcome~Bdata,family="binomial") ,model4))
      Sta4 = c(anova4["Chisq2"],anova4["Pr(>Chisq)2"])
    }
  }
  if (dim(summary(model5)$coefficients)[1]<3){
    coef5 = c(NA,NA)
    bic5 = NA
    Sta5 = c(NA,NA)
  }else{
    coef5 = summary(model5)$coefficients[3,c(1,2)]
    bic5 = extractAIC(model5,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova5 = unlist(waldtest(glm(Outcome~rBdata,family="binomial"),model5,test="Chisq"))
      Sta5 = c(anova5["Chisq2"],anova5["Pr(>Chisq)2"])
    }else{
      anova5 = unlist(lrtest(glm(Outcome~rBdata,family="binomial"),model5))
      Sta5 = c(anova5["Chisq2"],anova5["Pr(>Chisq)2"])
    }
  }
  if (dim(summary(model6)$coefficients)[1]<2){
    coef6 = c(NA,NA)
    bic6 = NA
    Sta6 = c(NA,NA)
  }else{
    coef6 = summary(model6)$coefficients[2,c(1,2)]
    bic6 = extractAIC(model6,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova6 = unlist(waldtest(model0,model6,test="Chisq"))
      Sta6 = c(anova6["Chisq2"],anova6["Pr(>Chisq)2"])
    }else{
      anova6 = unlist(lrtest(model0,model6))
      Sta6 = c(anova6["Chisq2"],anova6["Pr(>Chisq)2"])
    }
  }
  if (dim(summary(model7)$coefficients)[1]<2){
    coef7= c(NA,NA)
    bic7 = NA
    Sta7 = c(NA,NA)
  }else{
    coef7 = summary(model7)$coefficients[2,c(1,2)]
    bic7 = extractAIC(model7,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova7 = unlist(waldtest(model0,model7,test="Chisq"))
      Sta7 = c(anova7["Chisq2"],anova7["Pr(>Chisq)2"])
    }else{
      anova7 = unlist(lrtest(model0,model7))
      Sta7 = c(anova7["Chisq2"],anova7["Pr(>Chisq)2"])
    }
  }
  if (dim(summary(model8)$coefficients)[1]<2){
    coef8 = c(NA,NA)
    bic8 = NA
    Sta8 = c(NA,NA)
  }else{
    coef8 = summary(model8)$coefficients[2,c(1,2)]
    bic8 = extractAIC(model8,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova8 = unlist(waldtest(model0,model8,test="Chisq"))
      Sta8 = c(anova8["Chisq2"],anova8["Pr(>Chisq)2"])
    }else{
      anova8 = unlist(lrtest(model0,model8))
      Sta8 = c(anova8["Chisq2"],anova8["Pr(>Chisq)2"])
    }
  }
  if (dim(summary(model9)$coefficients)[1]<2){
    coef9 = c(NA,NA)
    bic9 = NA
    Sta9 = c(NA,NA)
  }else{
    coef9 = summary(model9)$coefficients[2,c(1,2)]
    bic9 = extractAIC(model9,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova9 = unlist(waldtest(model0,model9,test="Chisq"))
      Sta9 = c(anova9["Chisq2"],anova9["Pr(>Chisq)2"])
    }else{
      anova9 = unlist(lrtest(model0,model9))
      Sta9 = c(anova9["Chisq2"],anova9["Pr(>Chisq)2"])

    }
  }

  Res=rbind(
    c(coef1,Sta1,bic1),
    c(coef2,Sta2,bic2),
    c(coef3,Sta3,bic3),
    c(coef4,Sta4,bic4),
    c(coef5,Sta5,bic5),
    c(coef6,Sta6,bic6),
    c(coef7,Sta7,bic7),
    c(coef8,Sta8,bic8),
    c(coef9,Sta9,bic9)
  )
  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (TestType=='WaldTest'){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}


.SNP_int_9 = function(Outcome,Adata,Bdata,a,b,X,TestType){
  if (length(X)==0){
    Res = .SNP_int_9_nc(Outcome,Adata,Bdata,a,b,TestType)
  }else{
    Res = .SNP_int_9_c(Outcome,Adata,Bdata,a,b,X,TestType)
  }
  return(Res)
}



###function for each pair to get min(BIC) in 45 models
#DD:Dom-Dom
#DR:Dom-Rec
#RD:Rec-Dom
#RR:Rec-Rec
#AA:Add-Add
.SNP_int_45 = function(Outcome,Domdata,Recdata,Condata,a,b,X,TestType){
  DD = .SNP_int_9(Outcome,Domdata,Domdata,a,b,X,TestType)
  DR = .SNP_int_9(Outcome,Domdata,Recdata,a,b,X,TestType)
  RD = .SNP_int_9(Outcome,Recdata,Domdata,a,b,X,TestType)
  RR = .SNP_int_9(Outcome,Recdata,Recdata,a,b,X,TestType)
  AA = .SNP_int_9(Outcome,Condata,Condata,a,b,X,TestType)
  Bic = c(DD[,5],DR[,5],RD[,5],RR[,5],AA[,5])
  m = which.min(Bic)
  Cp = c(DD[,4],DR[,4],RD[,4],RR[,4],AA[,4])
  Cv = c(DD[,3],DR[,3],RD[,3],RR[,3],AA[,3])
  MinCp = Cp[m]
  MaxC = Cv[m]
  mod = c("DD","DR","RD","RR","AA")[ceiling(m/9)]
  Minm = paste(mod,names(m),sep='_')
  rownames(DD) = paste("DD",rownames(DD),sep='_')
  rownames(DR) = paste("DR",rownames(DR),sep='_')
  rownames(RD) = paste("RD",rownames(RD),sep='_')
  rownames(RR) = paste("RR",rownames(RR),sep='_')
  rownames(AA) = paste("AA",rownames(AA),sep='_')
  return(list(DD=DD,DR=DR,RD=RD,RR=RR,AA=AA,Bic=Bic,SM=Minm,Scv=MaxC,Scp=MinCp))
}


##function for one-pair analysis/pairwise analysis
SIPI = function(Outcome,SNPdata,PairInfo,X,TestType){
  Nsnp = dim(SNPdata)[2]
  sData = setupSNP(SNPdata,1:Nsnp,sep="")
  Domdata = sapply(1:Nsnp, function(x) as.numeric(dominant(sData[,x])))
  Recdata = sapply(1:Nsnp, function(x) as.numeric(recessive(sData[,x])))
  Condata = sapply(1:Nsnp, function(x) as.numeric(additive(sData[,x])))

  Domdata = Domdata-1
  Recdata = Recdata-1
  if (any(PairInfo=="all")){
    allpair = combn(1:Nsnp,2)
    SNPNames = colnames(SNPdata)
    comslist = split(t(allpair),as.factor(1:dim(t(allpair))[1]))
    reslist = sapply(comslist,
                     function(allpair){
                       Eachp = .SNP_int_45(Outcome,Domdata,Recdata,Condata,allpair[1],allpair[2],X,TestType)
                       if (length(Eachp$Scv)==0){
                         resSM = NA
                         resScv = NA
                         resScp = NA
                         resBic = NA
                       }else{
                         resSM = Eachp$SM
                         resScv = Eachp$Scv
                         resScp = Eachp$Scp
                         resBic = min(Eachp$Bic)
                       }
                       res = c(resSM,resScv,resScp,resBic)
                       return(res)
                     })
    resSM = reslist[1,]
    resScv = as.numeric(reslist[2,])
    resScp = as.numeric(reslist[3,])
    resBic = as.numeric(reslist[4,])
    resnames1 = unlist(lapply(allpair[1,], function(m) SNPNames[[m]]))
    resnames2 = unlist(lapply(allpair[2,], function(m) SNPNames[[m]]))
    res = data.frame(resnames1,resnames2,resSM,resScv,resScp)
    if (TestType=="WaldTest"){
      colnames(res) = c("Var1","Var2","Model","Wald_Chisq","Wald_p")
    }else{
      colnames(res) = c("Var1","Var2","Model","LRT_Chisq","LRT_p")
    }
    return(list(selectedModel=res))
  }else{
    SNPNames = colnames(SNPdata)
    a = which(SNPNames==PairInfo[1])
    b = which(SNPNames==PairInfo[2])
    resSM = resSv = resSp = resScv = resScp = resnames1 = resnames2 = c()
    Eachp = .SNP_int_45(Outcome,Domdata,Recdata,Condata,a,b,X,TestType)
    if (length(Eachp$Scv)==0){
      resSM = NA
      resScv = NA
      resScp = NA
      resBic = NA
      res45models = NA
    }else{
      resSM = Eachp$SM
      resScv = Eachp$Scv
      resScp = Eachp$Scp
      resBic = min(Eachp$Bic,na.rm=TRUE)
      res45models = data.frame(rbind(Eachp$DD,Eachp$DR,Eachp$RD,Eachp$RR,Eachp$AA))
      res45models = res45models[with(res45models,order(BIC)),]
      Var1 = rep(PairInfo[1],45)
      Var2 = rep(PairInfo[2],45)
      Model = as.matrix(rownames(res45models))
      res45models = cbind(Var1,Var2,Model,res45models[,c(5,3,4)])
      rownames(res45models) = NULL
    }
    resnames1 = PairInfo[1]
    resnames2 = PairInfo[2]
    res = data.frame(resnames1,resnames2,
                     resSM,resBic,resScv,resScp,stringsAsFactors=FALSE)
    rownames(res) = ''
    if (TestType=="WaldTest"){
      colnames(res) = c("Var1","Var2","Model","BIC","Wald_Chisq","Wald_p")
    }else{
      colnames(res) = c("Var1","Var2","Model","BIC","LRT_Chisq","LRT_p")
    }
    return(list(selectedModel=res,res45Models=res45models))
  }
}



#parallel computing for SIPI
parSIPI = function (Outcome,SNPdata,X,TestType){
  .SIPI.whole = function(x){
    library(SIPI)
    SNPNames = colnames(SNPdata)
    SIPI_unit = SIPI(Outcome,SNPdata,c(SNPNames[x[1]],SNPNames[x[2]]),X,TestType)
    SIPI_unit$selectedModel
    return(SIPI_unit$selectedModel)
  }

  allpair = combn(1:dim(SNPdata)[2],2)
  comslist = split(t(allpair),as.factor(1:dim(t(allpair))[1]))
  num_cores = detectCores()
  cl = makeCluster(num_cores)
  Outcome <<- Outcome
  SNPdata <<- SNPdata
  X <<- X
  TestType <<- TestType
  clusterExport(cl,varlist=c("Outcome","SNPdata","X","TestType"))

  res = parSapply(cl,comslist,.SIPI.whole)
  stopCluster(cl)
  res = data.frame(t(matrix(unlist(res),6)),stringsAsFactors=FALSE)
  if (TestType=="WaldTest"){
    colnames(res) = c("Var1","Var2","Model","BIC","Wald_Chisq","Wald_p")
  }else{
    colnames(res) = c("Var1","Var2","Model","BIC","LRT_Chisq","LRT_p")
  }

  return(res)
}


#Outcome prevalence by the 3-by-3 genotypes of a given SNP pair
Grid3by3 = function(Outcome,SNPdata,PairInfo){
  SNP1 = as.character(SNPdata[,PairInfo[1]])
  SNP2 = as.character(SNPdata[,PairInfo[2]])
  Lev1 = unique(SNP1)
  Lev2 = unique(SNP2)
  Lev1NA = (apply(array(Lev1),1,function(x) length((strsplit(x,""))[[1]])) > 1)
  Lev2NA = (apply(array(Lev2),1,function(x) length((strsplit(x,""))[[1]])) > 1)
  Lev1 = Lev1[Lev1NA]
  Lev2 = Lev2[Lev2NA]
  table3by3 = matrix(rep(0,9),3)
  for (i in 1:length(Lev1)){
    for (j in 1:length(Lev2)){
    selectedN = (SNP1 == Lev1[i] & SNP2 == Lev2[j])
    totalN = sum(selectedN)
    OuptN = sum(Outcome[selectedN] == 1)
    table3by3[i,j] = OuptN/totalN
    }
  }
  rownames(table3by3) = c(paste(PairInfo[1],':Maj/maj',sep=''),
                          paste(PairInfo[1],':Maj/min',sep=''),
                          paste(PairInfo[1],':Min/min',sep=''))
  colnames(table3by3) = c(paste(PairInfo[2],':Maj/maj',sep=''),
                          paste(PairInfo[2],':Maj/min',sep=''),
                          paste(PairInfo[2],':Min/min',sep=''))
  return (table3by3)
}

MAFinfo = function(SNPdata){
  sData = setupSNP(SNPdata,1:dim(SNPdata)[2],sep="")
  snpRes = capture.output(summary(sData))[-1]
  snpInfor = matrix(rep(0,4*dim(SNPdata)[2]),dim(SNPdata)[2])
  for (i in 1:dim(SNPdata)[2]){
    snpRes1 = (strsplit(snpRes[i],' '))[[1]]
    snpRes1 =  snpRes1[snpRes1!=""]
    snpInfor[i,] = snpRes1[-1]
  }
  snpInfor[,2] = 1-(as.numeric(snpInfor[,2])/100)
  snpInfor = as.data.frame(snpInfor[,-3])
  rownames(snpInfor) = colnames(SNPdata)
  colnames(snpInfor) = c('maj/min','MAF','Missing(%)')
  return(snpInfor)
}


