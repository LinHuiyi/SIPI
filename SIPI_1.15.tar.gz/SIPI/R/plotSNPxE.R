GridSNPxE = function(Outcome,SNPdata,Env){

  if (is.null(colnames(SNPdata))){
    SNPName = 'SNP'
  }else{
    SNPName = colnames(SNPdata)
  }
  if (is.null(colnames(Env))){
    EnvName = 'Env'
  }else{
    EnvName = colnames(Env)
  }
  varName = c(SNPName,EnvName)
  wholeData = cbind(as.data.frame(Outcome),
                    as.data.frame(SNPdata),
                    as.data.frame(Env))
  vdata = complete.cases(wholeData)
  wholeData = wholeData[vdata,]
  Outcome =  wholeData[,1]
  SNPdata = wholeData[,2]
  Env = wholeData[,3]

  SNP1 = as.character(SNPdata)
  SNP2 = as.character(Env)
  Lev1 = unique(SNP1)
  Lev2 = sort(unique(SNP2))
  Lev1NA = (apply(array(Lev1),1,function(x) length((strsplit(x,""))[[1]])) > 1)
  Lev1 = Lev1[Lev1NA]

  sData = setupSNP(as.data.frame(SNPdata),1,sep="")
  snpRes = capture.output(summary(sData))[-1]
  snpRes1 = (strsplit(snpRes[1],' '))[[1]]
  snpRes1 =  snpRes1[snpRes1!=""]
  maj_min  = snpRes1[2]
  Lev1_f = .genotype(snpRes1[2])
  if ((sum(SNP1 == Lev1_f[2])==0) &  (sum(SNP1 == Lev1_f[4])>0)){
    Lev1_f = c(Lev1_f[1], Lev1_f[4], Lev1_f[3])
  }

  table3by3 = matrix(rep(0,3*length(Lev2)),3)
  table3by3Freq = matrix(rep(0,3*length(Lev2)),3)
  for (i in 1:3){
    for (j in 1:length(Lev2)){
      selectedN = ((SNP1 == Lev1_f[i]) & (SNP2 == Lev2[j]))
      totalN = sum(selectedN)
      OuptN = sum(Outcome[selectedN] == 1)
      table3by3[i,j] = OuptN / totalN
      if (is.nan(OuptN / totalN)){
        table3by3Freq [i, j] = OuptN / totalN
      }else{
        table3by3Freq [i, j] = totalN
      }

    }
  }

  rownames(table3by3) = c('Maj/maj','Maj/min','Min/min')
  colnames(table3by3) =  Lev2
  rownames(table3by3Freq) = c('Maj/maj','Maj/min','Min/min')
  colnames(table3by3Freq) =  Lev2

  return (list(table3by3=table3by3,table3by3Freq=table3by3Freq,maj_min=maj_min,varName=varName))
}

###
plotSNPxE <- function(x, SNP_info = T, outcome = T, freq = T, legend = T,
                      monochrome = F, scale = "fixed", marginal = T,
                      axis_fs = 1, outcome_fs = 1, freq_fs = 1, lgd_fs = 1){
  RN = row.names(x$table3by3)
  CN = colnames(x$table3by3)
  snp1 <- gl(length(RN),1)
  snp2 <- gl(length(CN),1)
  levels(snp1)[1:length(RN)] <- c("aa", "Aa", "AA")
  levels(snp2)[1:length(CN)] <- CN
  heat_table <- expand.grid("SNP" = rev(snp1), "Env" = (snp2))

  heat_table$color_scale <- c(x$table3by3)
  heat_table$outcome_prop <- round(c(x$table3by3), 2)
  heat_table$outcome_prop[is.nan(heat_table$outcome_prop)] <- 0#"NaN"

  heat_table$freq <- round(c(x$table3by3Freq), 2)
  heat_table$freq[is.nan(heat_table$freq)] <- 0#"NaN"
  heat_table$freq <- paste0("(", heat_table$freq, ")")
  p_33 <- ggplot(heat_table, aes(Env, SNP, z = color_scale)) + geom_tile(aes(fill = color_scale)) +
    theme(panel.background = element_rect(fill = NA),
          axis.ticks = element_blank(), axis.text = element_text(size = 20*axis_fs, color = "black"),
          axis.title = element_text(size = 20*axis_fs), axis.line = element_line(),
          legend.position = "right")+labs(y=x$varName[1], x=x$varName[2])+scale_x_discrete(position = "top")

  p_adj11 <- guides(fill =  guide_colorbar(title = "Outcome \nProportion",
                                           barwidth = 1.5, barheight = 8, ticks = F, nbin = 60,
                                           title.theme = element_text(size = 15*lgd_fs, angle = 0, vjust = 0.9),
                                           label.theme = element_text(size = 15*lgd_fs, angle = 0)))

  if(monochrome == T){
    col_use <- c("white", "grey80", "grey20")
  }else{
    col_use <- c("white", "firebrick1", "firebrick")
  }
  if(scale == "fixed"){
    p_adj1 <- scale_fill_gradientn(colors = col_use, guide = "colorbar", na.value = "transparent",
                                   limits = c(0, 1),
                                   breaks = c(0.1, 0.9), labels = c("Low", "High"))
  }else{
    p_adj1 <- scale_fill_gradientn(colors = col_use, guide = "colorbar", na.value = "transparent",
                                   limits = round(c(min(heat_table$color_scale, na.rm = T) *9/10, max(heat_table$color_scale, na.rm = T) * 11/10), 2),
                                   breaks = round(c(min(heat_table$color_scale, na.rm = T), max(heat_table$color_scale, na.rm = T)), 2),
                                   labels = c("Low", "High") )
  }
  p_33 <- p_33 + p_adj1 + p_adj11

  if(outcome == T & freq == T){
    p_33 <- p_33 + geom_text(aes(label = outcome_prop), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = -0.5) +
      geom_text(aes(label = freq), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.9)
  }else if(outcome == T & freq == F){
    p_33 <- p_33 + geom_text(aes(label = outcome_prop), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = 0)
  }else if(outcome == F & freq == T){
    p_33 <- p_33 + geom_text(aes(label = freq), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.8)
    }


  if(SNP_info == T){
    A <- substr(x$maj_min[1], 1,1)
    a <- substr(x$maj_min[1], 3,3)
    p_33 <- p_33 + scale_y_discrete(breaks = c("AA","Aa","aa"), labels = c(paste0("   ", A,A), paste0("   ", A,a), paste0("   ", a,a)) )
  }else{
    p_33 <- p_33 + scale_y_discrete(breaks = c("AA","Aa","aa"), labels = c("   AA","   Aa","   aa"))
  }

  if((any(is.nan(x$table3by3)) == TRUE) & (outcome == FALSE)){
    warning("Some cells without observations, show outcome proportions to avoid misleading.")
  }


  if(marginal == T){

    cell_size <- x$table3by3Freq
    case_size <- x$table3by3Freq * x$table3by3
    v_mar_Freq <- rowSums(cell_size, na.rm = T)
    h_mar_Freq <- colSums(cell_size, na.rm = T)
    v_mar_op <- rowSums(case_size, na.rm = T) / rowSums(cell_size, na.rm = T)
    h_mar_op <- colSums(case_size, na.rm = T) / colSums(cell_size, na.rm = T)
    mar_df_v <- data.frame(xy = rep("Total", length(v_mar_Freq)), SNP = snp1, Freq1 = paste0("(", rev(v_mar_Freq), ")"),
                           outcome_prop1 = rev(round(v_mar_op, 2)))
    mar_df_h <- data.frame(xy = rep("Total", length(h_mar_Freq)), Env = snp2, Freq2 = paste0("(", h_mar_Freq, ")"),
                           outcome_prop2 = round(h_mar_op, 2) )
    tot_df <- data.frame(x = 1, y = 1, Freq = paste0("(", sum(x$table3by3Freq, na.rm = T), ")"), outcome_prop = round(sum(case_size, na.rm = T)/sum(cell_size, na.rm = T), 2) )
    p_snp1 <- ggplot(mar_df_v, aes(xy, SNP, z = outcome_prop1)) + geom_tile(aes(fill = outcome_prop1)) + scale_x_discrete(position = "top") + labs(x = "") +
      theme(panel.background = element_blank(), axis.ticks = element_blank(), axis.line = element_blank(),
            axis.title.y = element_blank(), legend.position="none", axis.title.x = element_text(size = 20*axis_fs),
            axis.text.x = element_text(size = 20*axis_fs, angle = 0, color = "black"), axis.text.y = element_blank()) + p_adj1
    p_snp2 <- ggplot(mar_df_h, aes(Env, xy, z = outcome_prop2)) + geom_tile(aes(fill = outcome_prop2)) + scale_y_discrete(position = "left", breaks = "Total", labels = "Total") + labs(y = " ") +
      theme(panel.background = element_blank(), axis.ticks = element_blank(), axis.line = element_blank(),
            axis.title.x = element_blank(), legend.position="none", axis.title.y = element_text(size = 20*axis_fs),
            axis.text.y = element_text(size = 20*axis_fs, angle = 0, color = "black"), axis.text.x = element_blank()) + p_adj1
    p_tot <- ggplot(tot_df, aes(x, y, z = outcome_prop)) + geom_tile(aes(fill = outcome_prop)) + theme_void() + theme(legend.position="none") + p_adj1

    if(outcome == T & freq == T){
      p_snp1 <- p_snp1 + geom_text(aes(label = outcome_prop1), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = -0.5) +
        geom_text(aes(label = Freq1), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.9)
      p_snp2 <- p_snp2 + geom_text(aes(label = outcome_prop2), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = -0.5) +
        geom_text(aes(label = Freq2), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.9)
      p_tot <- p_tot + geom_text(aes(label = outcome_prop), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = -0.5) +
        geom_text(aes(label = Freq), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.9)
    }else if(outcome == T & freq == F){
      p_snp1 <- p_snp1 + geom_text(aes(label = outcome_prop1), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = 0)
      p_snp2 <- p_snp2 + geom_text(aes(label = outcome_prop2), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = 0)
      p_tot <- p_tot + geom_text(aes(label = outcome_prop), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = 0)
    }else if(outcome == F & freq == T){
      p_snp1 <- p_snp1 + geom_text(aes(label = Freq1), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.8)
      p_snp2 <- p_snp2 + geom_text(aes(label = Freq2), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.8)
      p_tot <- p_tot + geom_text(aes(label = Freq), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.8)
    }

    if(legend == F){
      p_mar <- ggpubr::ggarrange(p_33, p_snp1, p_snp2, p_tot,
                                 ncol = 2, nrow = 2,
                                 widths = c(5, 1), heights = c(5, 1),
                                 common.legend = TRUE, legend = "none")
    }else{
      p_mar <- ggpubr::ggarrange(p_33, p_snp1, p_snp2, p_tot,
                                 ncol = 2, nrow = 2,
                                 widths = c(5, 1), heights = c(5, 1),
                                 common.legend = TRUE, legend = "right")

    }
    return(p_mar)
  }else{
    if(legend == F){
      p_33 <- p_33 + theme(legend.position = "none")
    }
    return(p_33)
  }
}


