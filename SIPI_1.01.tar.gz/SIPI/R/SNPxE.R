split_str_by_index <- function(target, index) {
  index = sort(index)
  substr(rep(target, length(index) + 1),
         start = c(1, index),
         stop = c(index - 1, nchar(target)))
}

interleave <- function(v1,v2)
{
  ord1 = 2*(1:length(v1)) - 1
  ord2 = 2*(1:length(v2))
  c(v1,v2)[order(c(ord1,ord2))]
}

insert_str <- function(target, insert, index) {
  insert = insert[order(index)]
  index = sort(index)
  paste(interleave(split_str_by_index(target, index), insert), collapse="")
}

ordinal_suffix_of = function (i) {
  j = i %% 10
  k = i %% 100
  if (j == 1 && k != 11) {
    return (paste(i ,"st",sep=""))
  }
  if (j == 2 && k != 12) {
    return (paste(i ,"nd",sep=""))
  }
  if (j == 3 && k != 13) {
    return (paste(i ,"rd",sep=""))
  }
  return (paste(i ,"th",sep=""))
}


SNPxE_9_model_nc=function(Outcome,SNPdata_s,Env,ModelType,SelectCriteria,pair1=FALSE){
  if (is.factor(Env)){
    df = length(levels(Env)) - 1
    dfname =c()
    for (i in 1:df){
      #dfname = c(dfname, paste("SNP:Env(",ordinal_suffix_of(i),")",sep=""))
      dfname = c(dfname, paste("SNP:Env(",i,"vs.","0",")",sep=""))
    }
  }else{
    df = 1
    dfname = "SNP:Env"
  }
  wholeABData = cbind.data.frame(Outcome,SNPdata_s,Env)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  Outcome = wholeABData[,1]
  SNPdata_s = wholeABData[,2]
  Env = wholeABData[,3]
  wholeABData = NULL

  if (sum(SNPdata_s==2)>0){
    rSNPdata_s = abs(2-SNPdata_s)
  }else{
    rSNPdata_s = 1-SNPdata_s
  }
  if (is.factor(Env)){
    Env_n = as.numeric(Env) + 1
    rEnv = (max(Env_n) - Env_n)
    rEnv = factor(rEnv)

    Env = model.matrix(~Env)[,2:(1+df)]
    rEnv = model.matrix(~rEnv)[,2:(1+df)]
  }else{
    rEnv = max(Env) - Env
  }

  SEI = glm(Outcome ~ SNPdata_s+Env+SNPdata_s:Env,family=ModelType)
  SI = glm(Outcome ~ SNPdata_s+SNPdata_s:Env,family=ModelType)
  SI_r = glm(Outcome ~ SNPdata_s+rSNPdata_s:Env,family=ModelType)
  EI = glm(Outcome ~ Env+SNPdata_s:Env,family=ModelType)
  EI_r = glm(Outcome ~ Env + rEnv:SNPdata_s,family=ModelType)
  I = glm(Outcome ~ SNPdata_s:Env,family=ModelType)
  I_or = glm(Outcome ~ SNPdata_s:rEnv,family=ModelType)
  I_ro = glm(Outcome ~ rSNPdata_s:Env,family=ModelType)
  I_rr = glm(Outcome ~ rSNPdata_s:rEnv,family=ModelType)

  no_SEI = glm(Outcome ~ SNPdata_s+Env,family=ModelType)
  no_SI = glm(Outcome ~ SNPdata_s,family=ModelType)
  no_SI_r = glm(Outcome ~ SNPdata_s,family=ModelType)
  no_EI = glm(Outcome ~ Env,family=ModelType)
  no_EI_r = glm(Outcome ~ Env ,family=ModelType)
  no_I = glm(Outcome ~ 1,family=ModelType)

  ao_SEI = unlist(.waldtest(SEI,no_SEI ,test="Chisq"))
  ao_SI = unlist(.waldtest(SI,no_SI,test="Chisq"))
  ao_SI_r = unlist(.waldtest(SI_r,no_SI_r,test="Chisq"))
  ao_EI = unlist(.waldtest(EI,no_EI,test="Chisq"))
  ao_EI_r = unlist(.waldtest(EI_r,no_EI_r,test="Chisq"))
  ao_I = unlist(.waldtest(I,no_I,test="Chisq"))
  ao_I_or = unlist(.waldtest(I_or,no_I,test="Chisq"))
  ao_I_ro = unlist(.waldtest(I_ro,no_I,test="Chisq"))
  ao_I_rr = unlist(.waldtest(I_rr,no_I,test="Chisq"))

  pp = cbind(ao_SEI["Pr(>Chisq)2"],ao_SI["Pr(>Chisq)2"],ao_SI_r["Pr(>Chisq)2"],ao_EI["Pr(>Chisq)2"],
             ao_EI_r["Pr(>Chisq)2"],ao_I["Pr(>Chisq)2"],ao_I_or["Pr(>Chisq)2"],ao_I_ro["Pr(>Chisq)2"],
             ao_I_rr["Pr(>Chisq)2"])

  sig = is.na(pp)

  seip = matrix(tail(coef(summary(SEI))[,4],n=df),df,1)
  sip = matrix(tail(coef(summary(SI))[,4],n=df),df,1)
  sip_r = matrix(tail(coef(summary(SI_r))[,4],n=df),df,1)
  eip = matrix(tail(coef(summary(EI))[,4],n=df),df,1)
  eip_r = matrix(tail(coef(summary(EI_r))[,4],n=df),df,1)
  ip = matrix(tail(coef(summary(I))[,4],n=df),df,1)
  ip_or = matrix(tail(coef(summary(I_or))[,4],n=df),df,1)
  ip_ro = matrix(tail(coef(summary(I_ro))[,4],n=df),df,1)
  ip_rr = matrix(tail(coef(summary(I_rr))[,4],n=df),df,1)

  biccon = log(length(Outcome))
  seibic = extractAIC(SEI,k=biccon)[2]
  sibic = extractAIC(SI,k=biccon)[2]
  sibic_r = extractAIC(SI_r,k=biccon)[2]
  eibic = extractAIC(EI,k=biccon)[2]
  eibic_r = extractAIC(EI_r,k=biccon)[2]
  ibic = extractAIC(I,k=biccon)[2]
  ibic_or = extractAIC(I_or,k=biccon)[2]
  ibic_ro = extractAIC(I_ro,k=biccon)[2]
  ibic_rr = extractAIC(I_rr,k=biccon)[2]
  bic=c(seibic,sibic,sibic_r,eibic,eibic_r,ibic,ibic_or,ibic_ro,ibic_rr)
  bic[sig==TRUE]=NaN
  if (SelectCriteria=='pvalue'){
    modelselect = tail(which(pp==min(pp,na.rm=TRUE)),1)

  }else{
    modelselect = tail(which(bic==min(bic,na.rm=TRUE)),1)
  }

  if (modelselect==1){
    cof = tail(coef(summary(SEI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SEI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SEI))[,2],n=df)
    a0 = cbind('Full_oo',ao_SEI["Chisq2"],ao_SEI["Pr(>Chisq)2"],seibic)
    a1 = cbind('Full_oo',dfname,cof,seip,cof,ORL,ORH)

  }else if(modelselect==2){
    cof = tail(coef(summary(SI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SI))[,2],n=df)
    a0 = cbind('Mint_SNP_oo',ao_SI["Chisq2"],ao_SI["Pr(>Chisq)2"],sibic)
    a1 = cbind('Mint_SNP_oo',dfname,cof,sip,cof,ORL,ORH)

  }else if(modelselect==3){
    cof = tail(coef(summary(SI_r))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SI_r))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SI_r))[,2],n=df)
    a0 = cbind('Mint_SNP_ro',ao_SI_r["Chisq2"],ao_SI_r["Pr(>Chisq)2"],sibic_r)
    a1 = cbind('Mint_SNP_ro',dfname,cof,sip_r,cof,ORL,ORH)

  }else if(modelselect==4){
    cof = tail(coef(summary(EI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(EI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(EI))[,2],n=df)
    a0 = cbind('Mint_Env_oo',ao_EI["Chisq2"],ao_EI["Pr(>Chisq)2"],eibic)
    a1 = cbind('Mint_Env_oo',dfname,cof,eip,cof,ORL,ORH)

  }else if(modelselect==5){
    cof = tail(coef(summary(EI_r))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(EI_r))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(EI_r))[,2],n=df)
    a0 = cbind('Mint_Env_or',ao_EI_r["Chisq2"],ao_EI_r["Pr(>Chisq)2"],eibic_r)
    a1 = cbind('Mint_Env_or',dfname,cof,eip_r,cof,ORL,ORH)

  }else if(modelselect==6){
    cof = tail(coef(summary(I))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I))[,2],n=df)
    a0 = cbind('Int_oo',ao_I["Chisq2"],ao_I["Pr(>Chisq)2"],ibic)
    a1 = cbind('Int_oo',dfname,cof,ip,cof,ORL,ORH)

  }else if(modelselect==7){
    cof = tail(coef(summary(I_or))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_or))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_or))[,2],n=df)
    a0 = cbind('Int_or',ao_I_or["Chisq2"],ao_I_or["Pr(>Chisq)2"],ibic_or)
    a1 = cbind('Int_or',dfname,cof,ip_or,cof,ORL,ORH)

  }else if(modelselect==8){
    cof = tail(coef(summary(I_ro))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_ro))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_ro))[,2],n=df)
    a0 = cbind('Int_ro',ao_I_ro["Chisq2"],ao_I_ro["Pr(>Chisq)2"],ibic_ro)
    a1 = cbind('Int_ro',dfname,cof,ip_ro,cof,ORL,ORH)

  }else{
    cof = tail(coef(summary(I_rr))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_rr))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_rr))[,2],n=df)
    a0 = cbind('Int_rr',ao_I_rr["Chisq2"],ao_I_rr["Pr(>Chisq)2"],ibic_rr)
    a1 = cbind('Int_rr',dfname,cof,ip_rr,cof,ORL,ORH)
  }

  if (pair1){
    cof = tail(coef(summary(SEI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SEI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SEI))[,2],n=df)
    a10 = cbind('Full_oo',ao_SEI["Chisq2"],ao_SEI["Pr(>Chisq)2"],seibic)
    a11 = cbind('Full_oo',dfname,cof,seip,cof,ORL,ORH)
    cof = tail(coef(summary(SI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SI))[,2],n=df)
    a20 = cbind('Mint_SNP_oo',ao_SI["Chisq2"],ao_SI["Pr(>Chisq)2"],sibic)
    a21 = cbind('Mint_SNP_oo',dfname,cof,sip,cof,ORL,ORH)
    cof = tail(coef(summary(SI_r))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SI_r))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SI_r))[,2],n=df)
    a30 = cbind('Mint_SNP_ro',ao_SI_r["Chisq2"],ao_SI_r["Pr(>Chisq)2"],sibic_r)
    a31 = cbind('Mint_SNP_ro',dfname,cof,sip_r,cof,ORL,ORH)
    cof = tail(coef(summary(EI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(EI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(EI))[,2],n=df)
    a40 = cbind('Mint_Env_oo',ao_EI["Chisq2"],ao_EI["Pr(>Chisq)2"],eibic)
    a41 = cbind('Mint_Env_oo',dfname,cof,eip,cof,ORL,ORH)
    cof = tail(coef(summary(EI_r))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(EI_r))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(EI_r))[,2],n=df)
    a50 = cbind('Mint_Env_or',ao_EI_r["Chisq2"],ao_EI_r["Pr(>Chisq)2"],eibic_r)
    a51 = cbind('Mint_Env_or',dfname,cof,eip_r,cof,ORL,ORH)
    cof = tail(coef(summary(I))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I))[,2],n=df)
    a60 = cbind('Int_oo',ao_I["Chisq2"],ao_I["Pr(>Chisq)2"],ibic)
    a61 = cbind('Int_oo',dfname,cof,ip,cof,ORL,ORH)
    cof = tail(coef(summary(I_or))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_or))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_or))[,2],n=df)
    a70 = cbind('Int_or',ao_I_or["Chisq2"],ao_I_or["Pr(>Chisq)2"],ibic_or)
    a71 = cbind('Int_or',dfname,cof,ip_or,cof,ORL,ORH)
    cof = tail(coef(summary(I_ro))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_ro))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_ro))[,2],n=df)
    a80 = cbind('Int_ro',ao_I_ro["Chisq2"],ao_I_ro["Pr(>Chisq)2"],ibic_ro)
    a81 = cbind('Int_ro',dfname,cof,ip_ro,cof,ORL,ORH)
    cof = tail(coef(summary(I_rr))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_rr))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_rr))[,2],n=df)
    a90 = cbind('Int_rr',ao_I_rr["Chisq2"],ao_I_rr["Pr(>Chisq)2"],ibic_rr)
    a91 = cbind('Int_rr',dfname,cof,ip_rr,cof,ORL,ORH)

    a0_all = rbind(a10,a20,a30,a40,a50,a60,a70,a80,a90)
    a1_all = rbind(a11,a21,a31,a41,a51,a61,a71,a81,a91)
    a0_all[sig==TRUE,2:4]=NaN
    a1_all[sig==TRUE,3:7]=NaN
  }else{
    a0_all = NULL
    a1_all = NULL
  }

  return(list(a0=a0,a1=a1,a0_all=a0_all,a1_all=a1_all))
}


SNPxE_9_model_c=function(Outcome,SNPdata_s,Env,X,ModelType,SelectCriteria,pair1=FALSE){
  if (is.factor(Env)){
  df = length(levels(Env)) - 1
  dfname =c()
  for (i in 1:df){
    #dfname = c(dfname, paste("SNP:Env(",ordinal_suffix_of(i),")",sep=""))
    dfname = c(dfname, paste("SNP:Env(",i,"vs.","0",")",sep=""))
  }
  }else{
    df = 1
    dfname = "SNP:Env"
  }
  wholeABData = cbind.data.frame(Outcome,SNPdata_s,Env,X)
  vdata = complete.cases(wholeABData)
  data_OABX = wholeABData[vdata,]
  Outcome = data_OABX[,1]
  SNPdata_s = data_OABX[,2]
  Env = as.data.frame(data_OABX[,3])
  colnames(Env) = "Env_1"

  X =  data_OABX [colnames(X)]
  if (sum(SNPdata_s==2)>0){
    rSNPdata_s = abs(2 - SNPdata_s)
  }else{
    rSNPdata_s = 1 - SNPdata_s
  }
  if (is.factor(Env[,1])){
    Env_n = as.numeric(Env[,1]) + 1
    rEnv = (max(Env_n) - Env_n)
    rEnv = factor(rEnv)
    #rEnv = factor(Env[,1],levels=rev(levels(Env[,1])))
    Env = matrix(model.matrix(~Env[,1])[,2:(1+df)],nrow(Env))
    colnames(Env) = paste0("Env_",seq_len(ncol(Env)))
    rEnv = matrix(model.matrix(~rEnv)[,2:(1+df)],nrow(Env))
    colnames(rEnv) = paste0("rEnv_",seq_len(ncol(rEnv)))
  }else{
    rEnv = as.data.frame(max(Env[,1]) - Env[,1])
    colnames(rEnv) = paste0("rEnv_",seq_len(ncol(rEnv)))
  }

  data_OABX = cbind.data.frame(Outcome,SNPdata_s,Env,X,rSNPdata_s,rEnv)
  X_names =  paste(colnames(X),collapse= "+")
  Env_name = colnames(Env)
  Env_name_p = paste(colnames(Env),collapse= "+")
  rEnv_name = colnames(rEnv)
  rEnv_name_p = paste(colnames(rEnv),collapse= "+")
  inter_oo =  paste("+SNPdata_s:",Env_name,sep="",collapse="")
  inter_ro =  paste("+rSNPdata_s:",Env_name,sep="",collapse="")
  inter_or =  paste("+SNPdata_s:",rEnv_name,sep="",collapse="")
  inter_rr =  paste("+rSNPdata_s:",rEnv_name,sep="",collapse="")

  model1_for = as.formula(paste("Outcome~SNPdata_s+",Env_name_p,"+",
                                X_names,inter_oo))
  SEI = glm(model1_for,data=data_OABX,family=ModelType)
  model1_for = as.formula(paste("Outcome~SNPdata_s+",Env_name_p,"+",
                                X_names))
  no_SEI = glm(model1_for,data=data_OABX,family=ModelType)

  model1_for = as.formula(paste("Outcome~SNPdata_s+",
                                X_names,inter_oo))
  SI = glm(model1_for,data=data_OABX,family=ModelType)
  model1_for = as.formula(paste("Outcome~SNPdata_s+",
                                X_names))
  no_SI = glm(model1_for,data=data_OABX,family=ModelType)

  model1_for = as.formula(paste("Outcome~rSNPdata_s+",
                                X_names,inter_ro))
  SI_r = glm(model1_for,data=data_OABX,family=ModelType)
  model1_for = as.formula(paste("Outcome~rSNPdata_s+",
                                X_names))
  no_SI_r = glm(model1_for,data=data_OABX,family=ModelType)

  model1_for = as.formula(paste("Outcome~",Env_name_p,"+",
                                X_names,inter_oo))
  EI = glm(model1_for,data=data_OABX,family=ModelType)
  model1_for = as.formula(paste("Outcome~",Env_name_p,"+",
                                X_names))
  no_EI = glm(model1_for,data=data_OABX,family=ModelType)

  model1_for = as.formula(paste("Outcome~",Env_name_p,"+",
                                X_names,inter_or))
  EI_r = glm(model1_for,data=data_OABX,family=ModelType)
  model1_for = as.formula(paste("Outcome~",Env_name_p,"+",
                                X_names))
  no_EI_r = glm(model1_for,data=data_OABX,family=ModelType)

  model1_for = as.formula(paste("Outcome~",
                                X_names,inter_oo))
  I = glm(model1_for,data=data_OABX,family=ModelType)
  model1_for = as.formula(paste("Outcome~",
                                X_names))
  no_I = glm(model1_for,data=data_OABX,family=ModelType)

  model1_for = as.formula(paste("Outcome~",
                                X_names,inter_or))
  I_or = glm(model1_for,data=data_OABX,family=ModelType)

  model1_for = as.formula(paste("Outcome~",
                                X_names,inter_ro))
  I_ro = glm(model1_for,data=data_OABX,family=ModelType)

  model1_for = as.formula(paste("Outcome~",
                                X_names,inter_rr))
  I_rr = glm(model1_for,data=data_OABX,family=ModelType)

  ao_SEI = unlist(.waldtest(SEI,no_SEI ,test="Chisq"))
  ao_SI = unlist(.waldtest(SI,no_SI,test="Chisq"))
  ao_SI_r = unlist(.waldtest(SI_r,no_SI_r,test="Chisq"))
  ao_EI = unlist(.waldtest(EI,no_EI,test="Chisq"))
  ao_EI_r = unlist(.waldtest(EI_r,no_EI_r,test="Chisq"))
  ao_I = unlist(.waldtest(I,no_I,test="Chisq"))
  ao_I_or = unlist(.waldtest(I_or,no_I,test="Chisq"))
  ao_I_ro = unlist(.waldtest(I_ro,no_I,test="Chisq"))
  ao_I_rr = unlist(.waldtest(I_rr,no_I,test="Chisq"))

  pp = cbind(ao_SEI["Pr(>Chisq)2"],ao_SI["Pr(>Chisq)2"],ao_SI_r["Pr(>Chisq)2"],
             ao_EI["Pr(>Chisq)2"],ao_EI_r["Pr(>Chisq)2"],
             ao_I["Pr(>Chisq)2"],ao_I_or["Pr(>Chisq)2"],ao_I_ro["Pr(>Chisq)2"],ao_I_rr["Pr(>Chisq)2"])

  sig = is.na(pp)

  seip = matrix(tail(coef(summary(SEI))[,4],n=df),df,1)
  sip = matrix(tail(coef(summary(SI))[,4],n=df),df,1)
  sip_r = matrix(tail(coef(summary(SI_r))[,4],n=df),df,1)
  eip = matrix(tail(coef(summary(EI))[,4],n=df),df,1)
  eip_r = matrix(tail(coef(summary(EI_r))[,4],n=df),df,1)
  ip = matrix(tail(coef(summary(I))[,4],n=df),df,1)
  ip_or = matrix(tail(coef(summary(I_or))[,4],n=df),df,1)
  ip_ro = matrix(tail(coef(summary(I_ro))[,4],n=df),df,1)
  ip_rr = matrix(tail(coef(summary(I_rr))[,4],n=df),df,1)

  biccon = log(length(Outcome))
  seibic = extractAIC(SEI,k=biccon)[2]
  sibic = extractAIC(SI,k=biccon)[2]
  sibic_r = extractAIC(SI_r,k=biccon)[2]
  eibic = extractAIC(EI,k=biccon)[2]
  eibic_r = extractAIC(EI_r,k=biccon)[2]
  ibic = extractAIC(I,k=biccon)[2]
  ibic_or = extractAIC(I_or,k=biccon)[2]
  ibic_ro = extractAIC(I_ro,k=biccon)[2]
  ibic_rr = extractAIC(I_rr,k=biccon)[2]
  bic = c(seibic,sibic,sibic_r,eibic,eibic_r,ibic,ibic_or,ibic_ro,ibic_rr)
  bic[sig==TRUE]=NaN

  if (SelectCriteria=='pvalue'){
    modelselect = tail(which(pp==min(pp,na.rm=TRUE)),1)
  }else{
    modelselect = tail(which(bic==min(bic,na.rm=TRUE)),1)
  }

  if (modelselect==1){
    cof = tail(coef(summary(SEI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SEI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SEI))[,2],n=df)
    a0 = cbind('Full_oo',ao_SEI["Chisq2"],ao_SEI["Pr(>Chisq)2"],seibic)
    a1 = cbind('Full_oo',dfname,cof,seip,cof,ORL,ORH)

  }else if(modelselect==2){
    cof = tail(coef(summary(SI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SI))[,2],n=df)
    a0 = cbind('Mint_SNP_oo',ao_SI["Chisq2"],ao_SI["Pr(>Chisq)2"],sibic)
    a1 = cbind('Mint_SNP_oo',dfname,cof,sip,cof,ORL,ORH)

  }else if(modelselect==3){
    cof = tail(coef(summary(SI_r))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SI_r))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SI_r))[,2],n=df)
    a0 = cbind('Mint_SNP_ro',ao_SI_r["Chisq2"],ao_SI_r["Pr(>Chisq)2"],sibic_r)
    a1 = cbind('Mint_SNP_ro',dfname,cof,sip_r,cof,ORL,ORH)

  }else if(modelselect==4){
    cof = tail(coef(summary(EI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(EI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(EI))[,2],n=df)
    a0 = cbind('Mint_Env_oo',ao_EI["Chisq2"],ao_EI["Pr(>Chisq)2"],eibic)
    a1 = cbind('Mint_Env_oo',dfname,cof,eip,cof,ORL,ORH)

  }else if(modelselect==5){
    cof = tail(coef(summary(EI_r))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(EI_r))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(EI_r))[,2],n=df)
    a0 = cbind('Mint_Env_or',ao_EI_r["Chisq2"],ao_EI_r["Pr(>Chisq)2"],eibic_r)
    a1 = cbind('Mint_Env_or',dfname,cof,eip_r,cof,ORL,ORH)

  }else if(modelselect==6){
    cof = tail(coef(summary(I))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I))[,2],n=df)
    a0 = cbind('Int_oo',ao_I["Chisq2"],ao_I["Pr(>Chisq)2"],ibic)
    a1 = cbind('Int_oo',dfname,cof,ip,cof,ORL,ORH)

  }else if(modelselect==7){
    cof = tail(coef(summary(I_or))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_or))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_or))[,2],n=df)
    a0 = cbind('Int_or',ao_I_or["Chisq2"],ao_I_or["Pr(>Chisq)2"],ibic_or)
    a1 = cbind('Int_or',dfname,cof,ip_or,cof,ORL,ORH)

  }else if(modelselect==8){
    cof = tail(coef(summary(I_ro))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_ro))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_ro))[,2],n=df)
    a0 = cbind('Int_ro',ao_I_ro["Chisq2"],ao_I_ro["Pr(>Chisq)2"],ibic_ro)
    a1 = cbind('Int_ro',dfname,cof,ip_ro,cof,ORL,ORH)

  }else{
    cof = tail(coef(summary(I_rr))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_rr))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_rr))[,2],n=df)
    a0 = cbind('Int_rr',ao_I_rr["Chisq2"],ao_I_rr["Pr(>Chisq)2"],ibic_rr)
    a1 = cbind('Int_rr',dfname,cof,ip_rr,cof,ORL,ORH)

  }

  if (pair1){
    cof = tail(coef(summary(SEI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SEI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SEI))[,2],n=df)
    a10 = cbind('Full_oo',ao_SEI["Chisq2"],ao_SEI["Pr(>Chisq)2"],seibic)
    a11 = cbind('Full_oo',dfname,cof,seip,cof,ORL,ORH)
    cof = tail(coef(summary(SI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SI))[,2],n=df)
    a20 = cbind('Mint_SNP_oo',ao_SI["Chisq2"],ao_SI["Pr(>Chisq)2"],sibic)
    a21 = cbind('Mint_SNP_oo',dfname,cof,sip,cof,ORL,ORH)
    cof = tail(coef(summary(SI_r))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(SI_r))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(SI_r))[,2],n=df)
    a30 = cbind('Mint_SNP_ro',ao_SI_r["Chisq2"],ao_SI_r["Pr(>Chisq)2"],sibic_r)
    a31 = cbind('Mint_SNP_ro',dfname,cof,sip_r,cof,ORL,ORH)
    cof = tail(coef(summary(EI))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(EI))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(EI))[,2],n=df)
    a40 = cbind('Mint_Env_oo',ao_EI["Chisq2"],ao_EI["Pr(>Chisq)2"],eibic)
    a41 = cbind('Mint_Env_oo',dfname,cof,eip,cof,ORL,ORH)
    cof = tail(coef(summary(EI_r))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(EI_r))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(EI_r))[,2],n=df)
    a50 = cbind('Mint_Env_or',ao_EI_r["Chisq2"],ao_EI_r["Pr(>Chisq)2"],eibic_r)
    a51 = cbind('Mint_Env_or',dfname,cof,eip_r,cof,ORL,ORH)
    cof = tail(coef(summary(I))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I))[,2],n=df)
    a60 = cbind('Int_oo',ao_I["Chisq2"],ao_I["Pr(>Chisq)2"],ibic)
    a61 = cbind('Int_oo',dfname,cof,ip,cof,ORL,ORH)
    cof = tail(coef(summary(I_or))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_or))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_or))[,2],n=df)
    a70 = cbind('Int_or',ao_I_or["Chisq2"],ao_I_or["Pr(>Chisq)2"],ibic_or)
    a71 = cbind('Int_or',dfname,cof,ip_or,cof,ORL,ORH)
    cof = tail(coef(summary(I_ro))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_ro))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_ro))[,2],n=df)
    a80 = cbind('Int_ro',ao_I_ro["Chisq2"],ao_I_ro["Pr(>Chisq)2"],ibic_ro)
    a81 = cbind('Int_ro',dfname,cof,ip_ro,cof,ORL,ORH)
    cof = tail(coef(summary(I_rr))[,1],n=df)
    ORL = tail(suppressMessages(confint.default(I_rr))[,1],n=df)
    ORH = tail(suppressMessages(confint.default(I_rr))[,2],n=df)
    a90 = cbind('Int_rr',ao_I_rr["Chisq2"],ao_I_rr["Pr(>Chisq)2"],ibic_rr)
    a91 = cbind('Int_rr',dfname,cof,ip_rr,cof,ORL,ORH)

    a0_all = rbind(a10,a20,a30,a40,a50,a60,a70,a80,a90)
    a1_all = rbind(a11,a21,a31,a41,a51,a61,a71,a81,a91)
    a0_all[sig==TRUE,2:4]=NaN
    a1_all[sig==TRUE,3:7]=NaN
  }else{
    a0_all = NULL
    a1_all = NULL
  }
  return(list(a0=a0,a1=a1,a0_all=a0_all,a1_all=a1_all))
}


SNPxE_27_mode = function(Outcome,Domdata_s,Recdata_s,Condata_s,Env,X,ModelType,SelectCriteria,pair1=FALSE){
  if (is.null(X)){
    Dom = SNPxE_9_model_nc(Outcome,Domdata_s,Env,ModelType,SelectCriteria,pair1)
    Rec = SNPxE_9_model_nc(Outcome,Recdata_s,Env,ModelType,SelectCriteria,pair1)
    Con = SNPxE_9_model_nc(Outcome,Condata_s,Env,ModelType,SelectCriteria,pair1)
  }else{
    Dom = SNPxE_9_model_c(Outcome,Domdata_s,Env,X,ModelType,SelectCriteria,pair1)
    Rec = SNPxE_9_model_c(Outcome,Recdata_s,Env,X,ModelType,SelectCriteria,pair1)
    Con = SNPxE_9_model_c(Outcome,Condata_s,Env,X,ModelType,SelectCriteria,pair1)
  }
  if (SelectCriteria=='pvalue'){
    pp = c(as.numeric(Dom$a0[3]),as.numeric(Rec$a0[3]),as.numeric(Con$a0[3]))
    min_idx = which(pp==min(pp))
  }else{
    bic = c(as.numeric(Dom$a0[4]),as.numeric(Rec$a0[4]),as.numeric(Con$a0[4]))
    min_idx = which(bic==min(bic))
  }

  if (min_idx==1){
    mod = insert_str(Dom$a0[1],c("_DE"),c(length(strsplit(Dom$a0[1],"")[[1]])-2))
    a0 = c(mod,Dom$a0[2:4])
    a1 = cbind(mod,matrix(Dom$a1[,2:7],dim(Dom$a1)[1]))
  }else if (min_idx==2){
    mod = insert_str(Rec$a0[1],c("_RE"),c(length(strsplit(Rec$a0[1],"")[[1]])-2))
    a0= c(mod,Rec$a0[2:4])
    a1 = cbind(mod,matrix(Rec$a1[,2:7],dim(Rec$a1)[1]))
  }else{
    mod = insert_str(Con$a0[1],c("_AE"),c(length(strsplit(Con$a0[1],"")[[1]])-2))
    a0 = c(mod,Con$a0[2:4])
    a1 = cbind(mod,matrix(Con$a1[,2:7],dim(Rec$a1)[1]))
  }
  if (pair1){
    a0_all_1 = Dom$a0_all
    a1_all_1 = Dom$a1_all
    for (i in 1:9){
      a0_all_1[i,1] = insert_str(a0_all_1[i,1],c("_DE"),c(length(strsplit(a0_all_1[i,1],"")[[1]])-2))
    }
    for (i in 1:dim(a1_all_1)[1]){
      a1_all_1[i,1] = insert_str(a1_all_1[i,1],c("_DE"),c(length(strsplit(a1_all_1[i,1],"")[[1]])-2))
    }
    a0_all_2 = Rec$a0_all
    a1_all_2 = Rec$a1_all
    for (i in 1:9){
      a0_all_2[i,1] = insert_str(a0_all_2[i,1],c("_RE"),c(length(strsplit(a0_all_2[i,1],"")[[1]])-2))
    }
    for (i in 1:dim(a1_all_2)[1]){
      a1_all_2[i,1] = insert_str(a1_all_2[i,1],c("_RE"),c(length(strsplit(a1_all_2[i,1],"")[[1]])-2))
    }
    a0_all_3 = Con$a0_all
    a1_all_3 = Con$a1_all
    for (i in 1:9){
      a0_all_3[i,1] = insert_str(a0_all_3[i,1],c("_AE"),c(length(strsplit(a0_all_3[i,1],"")[[1]])-2))
    }
    for (i in 1:dim(a1_all_3)[1]){
      a1_all_3[i,1] = insert_str(a1_all_3[i,1],c("_AE"),c(length(strsplit(a1_all_3[i,1],"")[[1]])-2))
    }
    a0_all = rbind(a0_all_3,a0_all_1,a0_all_2)
    a1_all = rbind(a1_all_3,a1_all_1,a1_all_2)
  }else{
    a0_all = NULL
    a1_all = NULL

  }
  return(list(a0=a0,a1=a1,a0_all=a0_all,a1_all=a1_all))
}


SNPxE = function(Outcome,SNPdata,Env,X=NULL,categXNames=NULL,ModelType="binomial",SelectCriteria='pvalue',OR=FALSE){
  Env_name = names(Env)
  EnvCateg = TRUE
  if (is.null(Env_name)){
    Env_name = 'Env1'
  }
  Env = unlist(Env)
  if (EnvCateg){
    Env = factor(Env)
  }
  X = .X_DataFrame(X,categXNames)
  Nsnp = dim(SNPdata)[2]
  SNPname = colnames(SNPdata)
  sData = setupSNP(SNPdata,1:Nsnp,sep="")
  Domdata = sapply(1:Nsnp, function(x) as.numeric(dominant(sData[,x]))) - 1
  Recdata = sapply(1:Nsnp, function(x) as.numeric(recessive(sData[,x]))) - 1
  Condata = sapply(1:Nsnp, function(x) as.numeric(additive(sData[,x])))

  checkTwo = sapply(1:Nsnp, function(x)length(unique(na.omit(sData[,x]))))
  if (any(checkTwo<3)){
    VectorIntersect <- function(v,z) {
      unlist(lapply(unique(v[v%in%z]), function(x) rep(x,min(sum(v==x),sum(z==x)))))
    }
    is.contained <- function(v,z) {length(VectorIntersect(v,z))==length(v)}
    for (i in which(checkTwo<3)){
      for (j in which(checkTwo==3)){
        if (is.contained(levels(unique(na.omit(sData[,i]))),levels(unique(na.omit(sData[,j])))) ){
          q1 = c(as.character(SNPdata[,j]),as.character(SNPdata[,i]))
          q1f = data.frame(q1)
          q = setupSNP(q1f,1,sep="")
          Domdata[,i] = as.numeric(dominant(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Recdata[,i] = as.numeric(recessive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Condata[,i] = as.numeric(additive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]]
          break
        }
      }
    }
  }

  sData = NULL
  Res = matrix(numeric(0),Nsnp,5)
  Res_coef = list()
  if (Nsnp==1){
     pair1=TRUE
  }else{
    pair1=FALSE
  }
  for (i in 1:Nsnp){
    res27= SNPxE_27_mode(Outcome,Domdata[,i],Recdata[,i],Condata[,i],Env,X,ModelType,SelectCriteria,pair1)
    Res[i,1] = SNPname[i]
    Res[i,2:5] = res27$a0
    Res_coef[[SNPname[i]]] = res27$a1
  }

  if (ModelType=="binomial"){
    Res_df = data.frame(a=as.character(Res[,1]),
                        a1=Env_name,
                        b=as.character(Res[,2]),
                        c=as.numeric(Res[,3]),
                        d=as.numeric(Res[,4]),
                        e=as.numeric(Res[,5]))
    colnames(Res_df) = c('SNP','Env','Pattern','Chisq','Chisq_pvalue','bic')
    coef_df=c()
    for (i in 1:Nsnp){
      coef = Res_coef[[SNPname[i]]]
      coef_df_1 = data.frame(a=as.character(SNPname[i]),
                          a1=Env_name,
                          b=as.character(coef[,1]),
                          b1=as.character(coef[,2]),
                          c=as.numeric(coef[,3]),
                          d=as.numeric(coef[,4]),
                          e=exp(as.numeric(coef[,5])),
                          f=exp(as.numeric(coef[,6])),
                          g=exp(as.numeric(coef[,7])))
      colnames(coef_df_1) = c('SNP','Env','Pattern','Coef_label','Coef','P.value','OR','OR_CI_2.5%','OR_CI_97.5%')
      coef_df = rbind(coef_df,coef_df_1)
    }
  }else{
    Res_df = data.frame(a=as.character(Res[,1]),
                        a1=Env_name,
                        b=as.character(Res[,2]),
                        c=as.numeric(Res[,3]),
                        d=as.numeric(Res[,4]),
                        #e=exp(as.numeric(Res[,5])),
                        f=exp(as.numeric(Res[,6])),
                        g=exp(as.numeric(Res[,7])))
    colnames(Res_df) = c('SNP','Env','Pattern','Coef','P.value','CI_2.5%','CI_97.5%')
  }
  if (Nsnp==1){
    Res_all = matrix(numeric(0),27,5)
    Res_all[,1] = SNPname[i]
    Res_all[,2:5] = res27$a0_all
    if (ModelType=="binomial"){
      Res_df_all = data.frame(a=as.character(Res_all[,1]),
                          a1=Env_name,
                          b=as.character(Res_all[,2]),
                          c=as.numeric(Res_all[,3]),
                          d=as.numeric(Res_all[,4]),
                          e=as.numeric(Res_all[,5]))
      colnames(Res_df_all) = c('SNP','Env','Pattern','Chisq','Chisq_pvalue','bic')
      coef = res27$a1_all
      coef_df_all = data.frame(a=as.character(SNPname[i]),
                             a1=Env_name,
                             b=as.character(coef[,1]),
                             b1=as.character(coef[,2]),
                             c=as.numeric(coef[,3]),
                             d=as.numeric(coef[,4]),
                             e=exp(as.numeric(coef[,5])),
                             f=exp(as.numeric(coef[,6])),
                             g=exp(as.numeric(coef[,7])))
      colnames(coef_df_all) = c('SNP','Env','Pattern','Coef_label','Coef','P.value','OR','OR_CI_2.5%','OR_CI_97.5%')
      }else{
      Res_df_all = data.frame(a=as.character(Res_all[,1]),
                              a1=Env_name,
                              b=as.character(Res_all[,2]),
                              c=as.numeric(Res_all[,3]),
                              d=as.numeric(Res_all[,4]),
                             #e=exp(as.numeric(Res[,5])),
                              f=exp(as.numeric(Res_all[,6])),
                              g=exp(as.numeric(Res_all[,7])),
                              h=as.numeric(Res_all[,8]))
      colnames(Res_df_all) = c('SNP','Env','Pattern','Coef','P.value','CI_2.5%','CI_97.5%','BIC')
      }
    if (OR){
      return(list(Res_df=Res_df,Coef_df=coef_df,Res_df_all=Res_df_all,Coef_df_all=coef_df_all))
    }else{
      return(list(Res_df=Res_df,Res_df_all=Res_df_all))
    }
  }else{
    if (OR){
      return(list(Res_df=Res_df,Coef_df=coef_df))
    }else{
      return(list(Res_df=Res_df))
    }
  }
}






