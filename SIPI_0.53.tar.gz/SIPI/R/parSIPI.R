
.SNP_int_9_1 = function(Outcome,Adata,Bdata,X,ZIM,TestType,ModelType){
  if (length(X)==0){
    if (ZIM){
      return(.SNP_int_9_zeroinfl_nc_1(Outcome,Adata,Bdata,TestType,ModelType))
    }
    else{
      return(.SNP_int_9_nc_1(Outcome,Adata,Bdata,TestType,ModelType))
    }
  }else{
    if (ZIM){
      return(.SNP_int_9_zeroinfl_1(Outcome,Adata,Bdata,X,TestType,ModelType))
    }else{
      return(.SNP_int_9_c_1(Outcome,Adata,Bdata,X,TestType,ModelType))
    }
  }
}


.SNP_int_45_r = function(Outcome,Domdata,Recdata,Condata,a,b,X,ZIM,TestType,ModelType){
  DD = .SNP_int_9_1(Outcome,Domdata[,a],Domdata[,b],X,ZIM,TestType,ModelType)
  DR = .SNP_int_9_1(Outcome,Domdata[,a],Recdata[,b],X,ZIM,TestType,ModelType)
  RD = .SNP_int_9_1(Outcome,Recdata[,a],Domdata[,b],X,ZIM,TestType,ModelType)
  RR = .SNP_int_9_1(Outcome,Recdata[,a],Recdata[,b],X,ZIM,TestType,ModelType)
  AA = .SNP_int_9_1(Outcome,Condata[,a],Condata[,b],X,ZIM,TestType,ModelType)
  Bic = c(DD[,5],DR[,5],RD[,5],RR[,5],AA[,5])
  if (all(is.na(Bic))){
    MinCp = MaxC = Minm = NA
  }else{
  m = which.min(Bic)
  mod = c("DD","DR","RD","RR","AA")[ceiling(m/9)]
  Minm = paste(mod,names(m),sep='_')
  MinCp = c(DD[,4],DR[,4],RD[,4],RR[,4],AA[,4])[m]
  MaxC = c(DD[,3],DR[,3],RD[,3],RR[,3],AA[,3])[m]
  }
  return(list(Bic=Bic,SM=Minm,Scv=MaxC,Scp=MinCp))
}


##function for one-pair analysis/pairwise analysis
.SIPI_r = function(Outcome,Domdata,Recdata,Condata,PairInfo,X,ZIM,TestType,ModelType,matrix_idx){
  Eachp = .SNP_int_45_r(Outcome,Domdata,Recdata,Condata,PairInfo[1],PairInfo[2],X,ZIM,TestType,ModelType)
  if (length(Eachp$Scv)==0){
    return(data.frame(NA,NA,NA,stringsAsFactors=FALSE))
  }else{
    return(data.frame(Eachp$SM,as.numeric(Eachp$Scv),as.numeric(Eachp$Scp),stringsAsFactors=FALSE))
  }
}


#parallel computing for SIPI
parSIPI = function (Outcome,SNPdata,PairInfo,X=NULL,categXNames=NULL,ZIM=FALSE,TestType="WaldTest",ModelType="binomial",core_ratio=0.9){
  X = .X_DataFrame(X,categXNames)
  .SIPI.whole = function(x){
    library(SIPI)
    return(.SIPI_r(Outcome,Domdata,Recdata,Condata,c(x[1],x[2]),X,ZIM,TestType,ModelType,matrix_idx))
  }
  SNPNames = colnames(SNPdata)
  if (any(PairInfo=="all")){
    allpair = combn(1:dim(SNPdata)[2],2)
    matrix_idx = 1
    SNPnames = t(combn(SNPNames,2))
  }else{
    SNPnames = as.matrix(PairInfo)
    allpair = .pairIndex(SNPNames, SNPnames)
    matrix_idx = 3
  }

  Nsnp = dim(SNPdata)[2]
  sData = setupSNP(SNPdata,1:Nsnp,sep="")
  Domdata = sapply(1:Nsnp, function(x) as.numeric(dominant(sData[,x]))) - 1
  Recdata = sapply(1:Nsnp, function(x) as.numeric(recessive(sData[,x]))) - 1
  Condata = sapply(1:Nsnp, function(x) as.numeric(additive(sData[,x])))
  sData = NULL

  comslist = split(t(allpair),as.factor(1:dim(t(allpair))[1]))
  num_cores = detectCores()
  num_cores = as.integer(num_cores * core_ratio)
  cl = makeCluster(num_cores)
  Outcome <<- Outcome
  Domdata <<- Domdata
  Recdata <<- Recdata
  Condata <<- Condata
  X <<- X
  TestType <<- TestType
  ModelType <<- ModelType
  matrix_idx <<- matrix_idx
  package <<- library(SIPI)
  clusterExport(cl,varlist=c("Outcome","Domdata","Recdata","Condata","X","TestType","ModelType","matrix_idx","package"))

  res = parSapply(cl,comslist,.SIPI.whole)
  stopCluster(cl)
  res = data.frame(t(matrix(unlist(res),3)),stringsAsFactors=FALSE)
  res[,2] = as.numeric(res[,2])
  res[,3] = as.numeric(res[,3])
  res = cbind(SNPnames, res)
  if (TestType=="WaldTest"){
    colnames(res) = c("Var1","Var2","Model","Wald_Chisq","Wald_p")
  }else{
    colnames(res) = c("Var1","Var2","Model","LRT_Chisq","LRT_p")
  }

  return(res)
}

