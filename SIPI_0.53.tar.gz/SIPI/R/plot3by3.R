### function plot3by3
# require:
#       SIPI
#       ggplot2
#

### roxgeny2 documentation

#' Heatmap plot of outcome proportions by genotype combinations
#'
#' Create a heatmap plot of outcome proportions by the 3-by-3 genotype combinations for a given SNP pair.
#'
#' This function creates a heatmap plot based on the output of \code{\link{Grid3by3}}, which generates outcome proportions by genotype combinations of a given SNP pair.
#'
#'
#' @param x List object output from function \code{Grid3by3}.
#' @param SNP_info Put SNP information(SNP name and major/minor allele) on plot. Default is \code{TRUE}.
#' @param outcome Include outcome proportions in each cell of plot. Default is \code{TRUE}. When no observations is in the given cell, 'NaN' will be shown. If there is no observation and \code{outcome=FALSE}, a warning will be shown.
#' @param legend Include legend. Default is \code{TRUE}.
#' @param monochrome Output monochrome plot. Default is \code{FALSE}.
#' @param scale A character string specifying the colour gradient scale type. \code{"fixed"} will lend color to heatmap with fixed color gradient scale from 0 to 1, \code{"sliding"} will lend color to heatmap with sliding gradient scale between minimum and maximum outcome proportion. Default is \code{"fixed"}.
#' @param axis_fs Axis font size. Adjusted both axis title font size and axis label font size. Number greater than 1 will enlarge the font size, less than 1 will reduce the font size. Default is \code{1}.
#' @param outcome_fs Outcome font size. Number greater than 1 will enlarge the font size, less than 1 will reduce the font size. Default is \code{1}.
#' @param lgd_fs Legend font size. Number greater than 1 will enlarge the font size, less than 1 will reduce the font size. Default is \code{1}.
#' @return A heatmap plot of outcome proportions, which is a \code{\link[ggplot2]{ggplot}} object.
#' @seealso \code{\link{Grid3by3}}
#' @references H. Wickham. ggplot2: Elegant Graphics for Data Analysis. Springer-Verlag New York, 2009.
#' @examples
#' x = Grid3by3(simData$D, SNPdata, c('SNP1', 'SNP2'))
#' plot3by3(x, SNP_info = F, outcome = F, legend = T, scale = "fixed", monochrome = T, lgd_fs = 1.2)
#'
#' x = Grid3by3(simData$D, SNPdata, c('SNP4', 'SNP6'))
#' plot3by3(x, scale = "sliding", axis_fs = 1.2, outcome_fs = 0.9)
plot3by3 <- function(x, SNP_info = T, outcome = T, legend = T, monochrome = F, scale = "fixed", axis_fs = 1, outcome_fs = 1, lgd_fs = 1){
    as <- axis_fs
    os <- outcome_fs
    ls <- lgd_fs

    snp1 <- gl(3,1)
    snp2 <- gl(3,1)
    levels(snp1)[1:3] <- c("aa", "Aa", "AA")
    levels(snp2)[1:3] <- c("BB", "Bb", "bb")
    heat_table <- expand.grid("SNP1" = rev(snp1), "SNP2" =(snp2))

    heat_table$color_scale <- c(x$table3by3)
    heat_table$text1 <- round(c(x$table3by3), 2)

    heat_table$text1[is.nan(heat_table$text1)] <- "NaN"

    p <- ggplot(heat_table, aes(SNP2, SNP1, z = color_scale)) + geom_tile(aes(fill = color_scale)) +
        theme(panel.background = element_rect(fill = NA),
              axis.ticks = element_blank(), axis.text = element_text(size = 20*as, color = "black"),
              axis.title = element_text(size = 25*as), axis.line = element_line(),
              legend.position = "right")
    if(monochrome == T){
        if(legend == "fixed"){
            p <- p + scale_fill_gradientn(colors = c("white", "grey80", "grey20"), guide = "colorbar", na.value = "transparent",
                                          limits = c(0,1),
                                          breaks = c(0.1, 0.9), labels = c("", "")) +
                guides(fill =  guide_colorbar(title = "Outcome \nProportion ", title.position = "top",
                                              barwidth = 4, barheight = 10, ticks = F, nbin = 100,
                                              title.theme = element_text(size = 15*ls, angle = 0),
                                              label.theme = element_text(size = 15*ls, angle = 0)))
        }else{
            p <- p + scale_fill_gradientn(colors = c("white", "grey80", "grey20"), guide = "colorbar", na.value = "transparent",
                                          limits = round(c(min(heat_table$color_scale, na.rm = T)-0.1, max(heat_table$color_scale, na.rm = T)+0.1), 2),
                                          breaks = round(c(min(heat_table$color_scale, na.rm = T), max(heat_table$color_scale, na.rm = T)), 2),
                                          labels = round(c(min(heat_table$color_scale, na.rm = T), max(heat_table$color_scale, na.rm = T)), 2) ) +
                guides(fill =  guide_colorbar(title = "Outcome \nProportion ", title.position = "top",
                                              barwidth = 4, barheight = 10, ticks = F, nbin = 100,
                                              title.theme = element_text(size = 15*ls, angle = 0),
                                              label.theme = element_text(size = 15*ls, angle = 0)))
        }
    }else{
        if(legend == "fixed"){
            p <- p + scale_fill_gradientn(colors = c("royalblue", "white", "firebrick"), guide = "colorbar", na.value = "transparent",
                                          limits = c(0,1),
                                          breaks = c(0.1, 0.9), labels = c("", "")) +
                guides(fill =  guide_colorbar(title = "Outcome \nProportion ", title.position = "top",
                                              barwidth = 4, barheight = 10, ticks = F, nbin = 100,
                                              title.theme = element_text(size = 15*ls, angle = 0),
                                              label.theme = element_text(size = 15*ls, angle = 0)))
        }else{
            p <- p + scale_fill_gradientn(colors = c("royalblue", "white", "firebrick"), guide = "colorbar", na.value = "transparent",
                                          limits = round(c(min(heat_table$color_scale, na.rm = T)-0.1, max(heat_table$color_scale, na.rm = T)+0.1), 2),
                                          breaks = round(c(min(heat_table$color_scale, na.rm = T), max(heat_table$color_scale, na.rm = T)), 2),
                                          labels = round(c(min(heat_table$color_scale, na.rm = T), max(heat_table$color_scale, na.rm = T)), 2) ) +
                guides(fill =  guide_colorbar(title = "Outcome \nProportion ", title.position = "top",
                                              barwidth = 4, barheight = 10, ticks = F, nbin = 100,
                                              title.theme = element_text(size = 15*ls, angle = 0),
                                              label.theme = element_text(size = 15*ls, angle = 0)))
        }
    }
    if(outcome == T){
        p <- p + geom_text(aes(label =  text1), na.rm = T, size = 8*os, fontface = "bold")
    }
    if(SNP_info == T){
        A <- substr(x$maj_min[1,], 1,1)
        a <- substr(x$maj_min[1,], 3,3)
        B <- substr(x$maj_min[2,], 1,1)
        b <- substr(x$maj_min[2,], 3,3)
        p <- p + scale_x_discrete(breaks = c("BB","Bb","bb"), labels = c(paste0(B,B), paste0(B,b), paste0(b,b)) ) +
            scale_y_discrete(breaks = c("AA","Aa","aa"), labels = c(paste0(A,A), paste0(A,a), paste0(a,a)) ) +
            labs(x = rownames(x$maj_min)[2], y = rownames(x$maj_min)[1])
    }else{
        p <- p + scale_x_discrete(breaks = c("BB","Bb","bb"), labels = c("BB","Bb","bb")) +
            scale_y_discrete(breaks = c("AA","Aa","aa"), labels = c("AA","Aa","aa"))
    }
    if(legend == F){
        p <- p + theme(legend.position = "none")
    }
    if((any(is.nan(x$table3by3)) == TRUE) & (outcome == FALSE)){
        warning("Some cells without observations, show outcome proportions to avoid misleading.")
        return(p)
    }else{
        return(p)
    }
}
