
SNPmain= function(Outcome,SNPdata,SNPlist,X=NULL,categXNames=NULL,ModelType="binomial"){
  if (any(SNPlist=="all")){
    SNPdata = SNPdata
  }else{
    SNPdata = SNPdata[SNPlist]
    }
  #if (length(X)==0|length(categXNames)==0|is.factor(X)){
  if (is.null(X)){
    return(SNP_main_effect_nc(Outcome,SNPdata,ModelType))
  }else{

    return(SNP_main_effect_c(Outcome,SNPdata,X,categXNames,ModelType))
  }

}


SNP_main_effect_c = function(Outcome,SNPdata,X,categXNames,ModelType){
  Nsnp = dim(SNPdata)[2]
  X = .X_DataFrame(X,categXNames)
  X = data.frame(X)
  #wholeData = cbind(Outcome,SNPdata,X)
  #vdata = complete.cases(wholeData)
  #wholeData = wholeData[vdata,]
  #Outcome = wholeData[,1]
  #SNPdata = wholeData[,c(2:(Nsnp+1))]
  #X = wholeData[,c((Nsnp+2):dim(wholeData)[2])]
  SNPname = colnames(SNPdata)

  sData = setupSNP(SNPdata,1:Nsnp,sep="")
  Domdata = sapply(1:Nsnp, function(x) as.numeric(dominant(sData[,x]))) - 1
  Recdata = sapply(1:Nsnp, function(x) as.numeric(recessive(sData[,x]))) - 1
  Condata = sapply(1:Nsnp, function(x) as.numeric(additive(sData[,x])))

  checkTwo = sapply(1:Nsnp, function(x)length(unique(na.omit(sData[,x]))))
  if (any(checkTwo<3)){
    VectorIntersect <- function(v,z) {
      unlist(lapply(unique(v[v%in%z]), function(x) rep(x,min(sum(v==x),sum(z==x)))))
    }
    is.contained <- function(v,z) {length(VectorIntersect(v,z))==length(v)}
    for (i in which(checkTwo<3)){
      for (j in which(checkTwo==3)){
        if (is.contained(levels(unique(na.omit(sData[,i]))),levels(unique(na.omit(sData[,j])))) ){
          q1 = c(as.character(SNPdata[,j]),as.character(SNPdata[,i]))
          q1f = data.frame(q1)
          q = setupSNP(q1f,1,sep="")
          Domdata[,i] = as.numeric(dominant(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Recdata[,i] = as.numeric(recessive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Condata[,i] = as.numeric(additive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]]
          break
        }
      }
    }
  }

  sData = NULL

  X_names =  paste(colnames(X), collapse= "+")
  data_D = cbind(Outcome,Domdata,X)
  colnames(data_D) = c('Outcome',SNPname,colnames(X))
  data_R = cbind(Outcome,Recdata,X)
  colnames(data_R) = c('Outcome',SNPname,colnames(X))
  data_C = cbind(Outcome,Condata,X)
  colnames(data_C) = c('Outcome',SNPname,colnames(X))

  Res = matrix(numeric(0),Nsnp,7)
  for (i in 1:Nsnp){
    model1_for = as.formula(paste("Outcome~",SNPname[i],'+',
                                  X_names))
    model_D = glm(model1_for,data=data_D,family=ModelType)
    model_R = glm(model1_for,data=data_R,family=ModelType)
    model_C = glm(model1_for,data=data_C,family=ModelType)
    dp = coef(summary(model_D))[,4][2]
    rp = coef(summary(model_R))[,4][2]
    cp = coef(summary(model_C))[,4][2]
    drcp = c(dp,rp,cp)
    drcp[is.na(drcp)] = Inf

    minp_idx = which(drcp==min(drcp))[1]
    Res[i,1] = SNPname[i]
    Res[i,2] = c('Dom','Rec','Add')[minp_idx]
    Res[i,4] = c(dp,rp,cp)[minp_idx]
    if (minp_idx==1){
      Res[i,3] = coef(summary(model_D))[,1][2]
      Res[i,5] = Res[i,3]
      ORLH = suppressMessages(confint.default(model_D))[2,]
      Res[i,6] = ORLH[1]
      Res[i,7] = ORLH[2]
    }else if(minp_idx==2) {
      Res[i,3] = coef(summary(model_R))[,1][2]
      Res[i,5] = Res[i,3]
      ORLH = suppressMessages(confint.default(model_R))[2,]
      Res[i,6] = ORLH[1]
      Res[i,7] = ORLH[2]

    }else{
      Res[i,3] = coef(summary(model_C))[,1][2]
      Res[i,5] = Res[i,3]
      ORLH = suppressMessages(confint.default(model_C))[2,]
      Res[i,6] = ORLH[1]
      Res[i,7] = ORLH[2]
    }
  }

  if (ModelType=="binomial"){
    Res_df = data.frame(a=as.character(Res[,1]),
                        b=as.character(Res[,2]),
                        c=as.numeric(Res[,3]),
                        d=as.numeric(Res[,4]),
                        e=exp(as.numeric(Res[,5])),
                        f=exp(as.numeric(Res[,6])),
                        g=exp(as.numeric(Res[,7])))

    colnames(Res_df) = c('SNP','Mode','Main.effect','P.value','OR','OR_CI_2.5%','OR_CI_97.5%')
  }else{
    Res_df = data.frame(a=as.character(Res[,1]),
                        b=as.character(Res[,2]),
                        c=as.numeric(Res[,3]),
                        d=as.numeric(Res[,4]),
                        #e=as.numeric(Res[,5]),
                        f=as.numeric(Res[,6]),
                        g=as.numeric(Res[,7]))

    colnames(Res_df) = c('SNP','Mode','Main.effect','P.value','CI_2.5%','CI_97.5%')

    }

  return(Res_df)
}


SNP_main_effect_nc = function(Outcome,SNPdata,ModelType){
  Nsnp = dim(SNPdata)[2]
  SNPname = colnames(SNPdata)
  sData = setupSNP(SNPdata,1:Nsnp,sep="")
  Domdata = sapply(1:Nsnp, function(x) as.numeric(dominant(sData[,x]))) - 1
  Recdata = sapply(1:Nsnp, function(x) as.numeric(recessive(sData[,x]))) - 1
  Condata = sapply(1:Nsnp, function(x) as.numeric(additive(sData[,x])))

  checkTwo = sapply(1:Nsnp, function(x)length(unique(na.omit(sData[,x]))))
  if (any(checkTwo<3)){
    VectorIntersect <- function(v,z) {
      unlist(lapply(unique(v[v%in%z]), function(x) rep(x,min(sum(v==x),sum(z==x)))))
    }
    is.contained <- function(v,z) {length(VectorIntersect(v,z))==length(v)}
    for (i in which(checkTwo<3)){
      for (j in which(checkTwo==3)){
        if (is.contained(levels(unique(na.omit(sData[,i]))),levels(unique(na.omit(sData[,j])))) ){
          q1 = c(as.character(SNPdata[,j]),as.character(SNPdata[,i]))
          q1f = data.frame(q1)
          q = setupSNP(q1f,1,sep="")
          Domdata[,i] = as.numeric(dominant(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Recdata[,i] = as.numeric(recessive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Condata[,i] = as.numeric(additive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]]
          break
        }
      }
    }
  }

  sData = NULL

  Res = matrix(numeric(0),Nsnp,7)
  for (i in 1:Nsnp){

    model_D = glm(Outcome~Domdata[,i],family=ModelType)
    model_R = glm(Outcome~Recdata[,i],family=ModelType)
    model_C = glm(Outcome~Condata[,i],family=ModelType)

    dp = coef(summary(model_D))[,4][2]
    rp = coef(summary(model_R))[,4][2]
    cp = coef(summary(model_C))[,4][2]
    drcp = c(dp,rp,cp)
    drcp[is.na(drcp)] = Inf

    minp_idx = which(drcp==min(drcp))[1]
    Res[i,1] = SNPname[i]
    Res[i,2] = c('Dom','Rec','Add')[minp_idx]
    Res[i,4] = c(dp,rp,cp)[minp_idx]
    if (minp_idx==1){
      Res[i,3] = coef(summary(model_D))[,1][2]
      Res[i,5] = Res[i,3]
      ORLH = suppressMessages(confint.default(model_D))[2,]
      Res[i,6] = ORLH[1]
      Res[i,7] = ORLH[2]
    }else if(minp_idx==2) {
      Res[i,3] = coef(summary(model_R))[,1][2]
      Res[i,5] = Res[i,3]
      ORLH = suppressMessages(confint.default(model_R))[2,]
      Res[i,6] = ORLH[1]
      Res[i,7] = ORLH[2]

    }else{
      Res[i,3] = coef(summary(model_C))[,1][2]
      Res[i,5] = Res[i,3]
      ORLH = suppressMessages(confint.default(model_C))[2,]
      Res[i,6] = ORLH[1]
      Res[i,7] = ORLH[2]
    }
  }
  if (ModelType=="binomial"){
    Res_df = data.frame(a=as.character(Res[,1]),
                        b=as.character(Res[,2]),
                        c=as.numeric(Res[,3]),
                        d=as.numeric(Res[,4]),
                        e=exp(as.numeric(Res[,5])),
                        f=exp(as.numeric(Res[,6])),
                        g=exp(as.numeric(Res[,7])))

    colnames(Res_df) = c('SNP','Mode','Main.effect','P.value','OR','OR_CI_2.5%','OR_CI_97.5%')
  }else{
    Res_df = data.frame(a=as.character(Res[,1]),
                        b=as.character(Res[,2]),
                        c=as.numeric(Res[,3]),
                        d=as.numeric(Res[,4]),
                        #e=as.numeric(Res[,5]),
                        f=as.numeric(Res[,6]),
                        g=as.numeric(Res[,7]))

    colnames(Res_df) = c('SNP','Mode','Main.effect','P.value','CI_2.5%','CI_97.5%')

  }

  return(Res_df)
}




