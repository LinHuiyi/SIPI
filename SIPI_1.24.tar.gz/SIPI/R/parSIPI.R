
.SNP_int_9_1 = function(Outcome,Adata,Bdata,X,ZIM,TestType,ModelType){
  if (length(X)==0){
    if (ZIM){
      return(.SNP_int_9_zeroinfl_nc_1(Outcome,Adata,Bdata,TestType,ModelType))
    }
    else{
      return(.SNP_int_9_nc_1(Outcome,Adata,Bdata,TestType,ModelType))
    }
  }else{
    if (ZIM){
      return(.SNP_int_9_zeroinfl_1(Outcome,Adata,Bdata,X,TestType,ModelType))
    }else{
      return(.SNP_int_9_c_1(Outcome,Adata,Bdata,X,TestType,ModelType))
    }
  }
}


.SNP_int_45_r = function(Outcome,Domdata,Recdata,Condata,a,b,X,ZIM,TestType,ModelType){
  DD = .SNP_int_9_1(Outcome,Domdata[,a],Domdata[,b],X,ZIM,TestType,ModelType)
  DR = .SNP_int_9_1(Outcome,Domdata[,a],Recdata[,b],X,ZIM,TestType,ModelType)
  RD = .SNP_int_9_1(Outcome,Recdata[,a],Domdata[,b],X,ZIM,TestType,ModelType)
  RR = .SNP_int_9_1(Outcome,Recdata[,a],Recdata[,b],X,ZIM,TestType,ModelType)
  AA = .SNP_int_9_1(Outcome,Condata[,a],Condata[,b],X,ZIM,TestType,ModelType)
  Bic = c(DD[,5],DR[,5],RD[,5],RR[,5],AA[,5])
  if (all(is.na(Bic))){
    MinCp = MaxC = Minm = NA
  }else{
  m = which.min(Bic)
  mod = c("DD","DR","RD","RR","AA")[ceiling(m/9)]
  Minm = paste(mod,names(m),sep='_')
  MinCp = c(DD[,4],DR[,4],RD[,4],RR[,4],AA[,4])[m]
  MaxC = c(DD[,3],DR[,3],RD[,3],RR[,3],AA[,3])[m]
  minB = c(DD[,1],DR[,1],RD[,1],RR[,1],AA[,1])[m]
  minS= c(DD[,2],DR[,2],RD[,2],RR[,2],AA[,2])[m]

  }
  return(list(Bic=Bic,SM=Minm,Scv=MaxC,Scp=MinCp,minB=minB,minS=minS))
}


##function for one-pair analysis/pairwise analysis
.SIPI_r = function(Outcome,Domdata,Recdata,Condata,PairInfo,X,ZIM,TestType,ModelType,matrix_idx){
  Eachp = .SNP_int_45_r(Outcome,Domdata,Recdata,Condata,PairInfo[1],PairInfo[2],X,ZIM,TestType,ModelType)
  if (length(Eachp$Scv)==0){
    return(data.frame(NA,NA,NA,NA,NA,stringsAsFactors=FALSE))
  }else{
    return(data.frame(Eachp$SM,as.numeric(Eachp$Scv),as.numeric(Eachp$Scp),Eachp$minB,Eachp$minS,stringsAsFactors=FALSE))
  }
}


#parallel computing for SIPI
parSIPI = function (Outcome,SNPdata,PairInfo,X=NULL,categXNames=NULL,ZIM=FALSE,TestType="WaldTest",ModelType="binomial",core_ratio=0.9,OR=FALSE){
  X = .X_DataFrame(X,categXNames)
  .SIPI.whole = function(x){
    library(SIPI)
    return(.SIPI_r(Outcome,Domdata,Recdata,Condata,c(x[1],x[2]),X,ZIM,TestType,ModelType,matrix_idx))
  }
  SNPNames = colnames(SNPdata)
  if (is.list(PairInfo)){
    PairInfo = as.matrix(expand.grid(PairInfo[[1]], PairInfo[[2]]))
  }
  if (any(PairInfo=="all")){
    allpair = combn(1:dim(SNPdata)[2],2)
    matrix_idx = 1
    SNPnames = t(combn(SNPNames,2))
  }else if (is.null(dim(PairInfo))){
    PairInfo = matrix(PairInfo,1,2)
    SNPnames = as.matrix(PairInfo)
    allpair = .pairIndex(SNPNames, SNPnames)
    matrix_idx = 3
  }
  else{
    SNPnames = as.matrix(PairInfo)
    allpair = .pairIndex(SNPNames, SNPnames)
    matrix_idx = 3
  }

  Nsnp = dim(SNPdata)[2]
  sData = setupSNP(SNPdata,1:Nsnp,sep="")
  Domdata = sapply(1:Nsnp, function(x) as.numeric(dominant(sData[,x]))) - 1
  Recdata = sapply(1:Nsnp, function(x) as.numeric(recessive(sData[,x]))) - 1
  Condata = sapply(1:Nsnp, function(x) as.numeric(additive(sData[,x])))

  checkTwo = sapply(1:Nsnp, function(x)length(unique(na.omit(sData[,x]))))
  if (any(checkTwo<3)){
    VectorIntersect <- function(v,z) {
      unlist(lapply(unique(v[v%in%z]), function(x) rep(x,min(sum(v==x),sum(z==x)))))
    }
    is.contained <- function(v,z) {length(VectorIntersect(v,z))==length(v)}
    for (i in which(checkTwo<3)){
      for (j in which(checkTwo==3)){
        if (is.contained(levels(unique(na.omit(sData[,i]))),levels(unique(na.omit(sData[,j])))) ){
          q1 = c(as.character(SNPdata[,j]),as.character(SNPdata[,i]))
          q1f = data.frame(q1)
          q = setupSNP(q1f,1,sep="")
          Domdata[,i] = as.numeric(dominant(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Recdata[,i] = as.numeric(recessive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Condata[,i] = as.numeric(additive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]]
          break
        }
      }
    }
  }

  sData = NULL

  comslist = split(t(allpair),as.factor(1:dim(t(allpair))[1]))
  num_cores = detectCores()
  num_cores = as.integer(num_cores * core_ratio)
  cl = makeCluster(num_cores)
  Outcome <<- Outcome
  Domdata <<- Domdata
  Recdata <<- Recdata
  Condata <<- Condata
  X <<- X
  TestType <<- TestType
  ModelType <<- ModelType
  matrix_idx <<- matrix_idx
  package <<- library(SIPI)
  clusterExport(cl,varlist=c("Outcome","Domdata","Recdata","Condata","X","TestType","ModelType","matrix_idx","package"))

  res = parSapply(cl,comslist,.SIPI.whole)
  stopCluster(cl)
  res = data.frame(t(matrix(unlist(res),5)),stringsAsFactors=FALSE)
  res[,2] = as.numeric(res[,2])
  res[,3] = as.numeric(res[,3])
  res[,4] = as.numeric(res[,4])
  res[,5] = as.numeric(res[,5])
  if (ModelType=="binomial"){
    res = cbind(SNPnames, res[,c(1,2,3)])
    if (TestType=="WaldTest"){
      colnames(res) = c("Var1","Var2","Pattern","Wald_Chisq","Wald_p")
    }else{
      colnames(res) = c("Var1","Var2","Pattern","LRT_Chisq","LRT_p")
    }
    res = as.matrix(res)
    if (OR==TRUE){
      if (matrix_idx==1){
        #OR = OddsRatioEst_unit_forall(Outcome,SNPdata,res[,1],res[,2],res[,3])
        #OR = OddsRatioEst_unit_pair_cal(Outcome,SNPdata,res[,1],res[,2],res[,3])
        OR = OddsRatioEst_unit_pair_cal_ALL(Outcome,SNPdata,res[,1],res[,2],res[,3],X)
      }else{
        #OR = OddsRatioEst_unit(Outcome,SNPdata,res[,1],res[,2],res[,3])
        #OR = OddsRatioEst_unit_pair_cal(Outcome,SNPdata,res[,1],res[,2],res[,3])
        OR = OddsRatioEst_unit_pair_cal_ALL(Outcome,SNPdata,res[,1],res[,2],res[,3],X)
      }
      return(list(selectedModel=res,OR=OR))
    }else{
      return(list(selectedModel=res))
    }
  }else{##Gaussian
    res = cbind(SNPnames, res)
    if (TestType=="WaldTest"){
      colnames(res) = c("Var1","Var2","Pattern","Wald_Chisq","Wald_p","Est.","Std.Er")
    }else{
      colnames(res) = c("Var1","Var2","Pattern","LRT_Chisq","LRT_p","Est.","Std.Er")
    }
    return(list(selectedModel=res))
  }

}

