###function for 9 patterns
#with covariate
.SNP_int_9_zeroinfl_c = function(Outcome,Adata,Bdata,X,TestType,ModelType){
  X = data.frame(X)
  wholeABData = cbind(Outcome,Adata,Bdata,X)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }

  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  X = wholeABData[,4:dim(wholeABData)[2]]
  X = data.frame(X)

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  data_OAB = data.frame(Outcome=Outcome,Adata=Adata,Bdata=Bdata,
                        rAdata=rAdata,rBdata=rBdata)
  data_OABX = cbind(data_OAB,X)

  biccon = log(length(Outcome))
  lenX = dim(X)[2]

  X_names =  paste(colnames(X), collapse= "+")

  model1_for = as.formula(paste("Outcome~Adata+Bdata+Adata:Bdata+",
                                X_names,"|Adata+Bdata+Adata:Bdata+", X_names))
  model1 = zeroinfl(model1_for,data=data_OABX,dist=ModelType)

  model2_for = as.formula(paste("Outcome~Adata+Adata:Bdata+",
                                X_names,"|Adata+Adata:Bdata+",X_names))
  model2 = zeroinfl(model2_for,data=data_OABX,dist=ModelType)

  model3_for = as.formula(paste("Outcome~rAdata+rAdata:Bdata+",
                                X_names,"|rAdata+rAdata:Bdata+",X_names))
  model3 = zeroinfl(model3_for,data=data_OABX,dist=ModelType)

  model4_for = as.formula(paste("Outcome~Bdata+Adata:Bdata+",
                                X_names,"|Bdata+Adata:Bdata+",X_names))
  model4 = zeroinfl(model4_for,data=data_OABX,dist=ModelType)

  model5_for = as.formula(paste("Outcome~rBdata+Adata:rBdata+",
                                X_names,"|rBdata+Adata:rBdata+",X_names))
  model5 = zeroinfl(model5_for,data=data_OABX,dist=ModelType)

  model6_for = as.formula(paste("Outcome~Adata:Bdata+",
                                X_names,"|Adata:Bdata+",X_names))
  model6 = zeroinfl(model6_for,data=data_OABX,dist=ModelType)

  model7_for = as.formula(paste("Outcome~rAdata:Bdata+",
                                X_names,"|rAdata:Bdata+",X_names))
  model7 = zeroinfl(model7_for,data=data_OABX,dist=ModelType)

  model8_for = as.formula(paste("Outcome~Adata:rBdata+",
                                X_names,"|Adata:rBdata+",X_names))
  model8 = zeroinfl(model8_for,data=data_OABX,dist=ModelType)

  model9_for = as.formula(paste("Outcome~rAdata:rBdata+",
                                X_names,"|rAdata:rBdata+",X_names))
  model9 = zeroinfl(model9_for,data=data_OABX,dist=ModelType)

  model0_for = as.formula(paste("Outcome~",
                                X_names,"|",X_names))
  model0 = zeroinfl(model0_for,data=data_OABX,dist=ModelType)

  Res = matrix(numeric(0),9,5)

  if (is.na(model1$coefficients$count[length(model1$coefficients$count)])){
    Res[1,] = NA
  }else{
    coeff = summary(model1)$coefficients$count[,c(1,2)]
    Res[1,1:2] = coeff[dim(coeff)[1] - 1, ]
    Res[1,5] = extractAIC(model1,k=biccon)[2]
    model1_for = as.formula(paste("Outcome~Adata+Bdata+",
                                  X_names,"|Adata+Bdata+",X_names))
    if (is.waldtest){
      modelc = zeroinfl(model1_for,data=data_OABX,dist=ModelType)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
    }else{
      modelc = zeroinfl(model1_for,data=data_OABX,dist=ModelType)
      anova = unlist(.lrtest(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (is.na(model2$coefficients$count[length(model2$coefficients$count)])){
    Res[2,] = NA
  }else{
    coeff = summary(model2)$coefficients$count[,c(1,2)]
    Res[2,1:2] = coeff[dim(coeff)[1] - 1]
    Res[2,5] = extractAIC(model2,k=biccon)[2]
    model2_for = as.formula(paste("Outcome~Adata+",
                                  X_names,"|Adata+",X_names))
    if (is.waldtest){
      modelc = zeroinfl(model2_for,data=data_OABX,dist=ModelType)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
    }else{
      modelc = zeroinfl(model2_for,data=data_OABX,dist=ModelType)
      anova = unlist(.lrtest(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (is.na(model3$coefficients$count[length(model3$coefficients$count)])){
    Res[3,] = NA
  }else{
    coeff = summary(model3)$coefficients$count[,c(1,2)]
    Res[3,1:2] = coeff[dim(coeff)[1] - 1]
    Res[3,5] = extractAIC(model3,k=biccon)[2]
    model3_for = as.formula(paste("Outcome~rAdata+",
                                  X_names,"|rAdata+",X_names))
    if (is.waldtest){
      modelc = zeroinfl(model3_for,data=data_OABX,dist=ModelType)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
    }else{
      modelc = zeroinfl(model3_for,data=data_OABX,dist=ModelType)
      anova = unlist(.lrtest(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (is.na(model4$coefficients$count[length(model4$coefficients$count)])){
    Res[4,] = NA
  }else{
    coeff = summary(model4)$coefficients$count[,c(1,2)]
    Res[4,1:2] = coeff[dim(coeff)[1] - 1]
    Res[4,5] = extractAIC(model4,k=biccon)[2]
    model4_for = as.formula(paste("Outcome~Bdata+",
                                  X_names,"|Bdata+",X_names))
    if (is.waldtest){
      modelc = zeroinfl(model4_for,data=data_OABX,dist=ModelType)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
    }else{
      modelc = zeroinfl(model4_for,data=data_OABX,dist=ModelType)
      anova = unlist(.lrtest(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (is.na(model5$coefficients$count[length(model5$coefficients$count)])){
    Res[5,] = NA
  }else{
    coeff = summary(model5)$coefficients$count[,c(1,2)]
    Res[5,1:2] = coeff[dim(coeff)[1] - 1]
    Res[5,5] = extractAIC(model5,k=biccon)[2]
    model5_for = as.formula(paste("Outcome~rBdata+",
                                  X_names,"|rBdata+",X_names))
    if (is.waldtest){
      modelc = zeroinfl(model5_for,data=data_OABX,dist=ModelType)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
    }else{
      modelc = zeroinfl(model5_for,data=data_OABX,dist=ModelType)
      anova = unlist(.lrtest(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (is.na(model6$coefficients$count[length(model6$coefficients$count)])){
    Res[6,] = NA
  }else{
    coeff = summary(model6)$coefficients$count[,c(1,2)]
    Res[6,1:2] = coeff[dim(coeff)[1] - 1]
    Res[6,5] = extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model6,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model6))
    }
    Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (is.na(model7$coefficients$count[length(model7$coefficients$count)])){
    Res[7,] = NA
  }else{
    coeff = summary(model7)$coefficients$count[,c(1,2)]
    Res[7,1:2] = coeff[dim(coeff)[1] - 1]
    Res[7,5] = extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model7,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model7))
    }
    Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (is.na(model8$coefficients$count[length(model8$coefficients$count)])){
    Res[8,] = NA
  }else{
    coeff = summary(model8)$coefficients$count[,c(1,2)]
    Res[8,1:2] = coeff[dim(coeff)[1] - 1]
    Res[8,5] = extractAIC(model8,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova = unlist(.waldtest(model0,model8,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model8))
    }
    Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (is.na(model9$coefficients$count[length(model9$coefficients$count)])){
    Res[9,] = NA
  }else{
    coeff = summary(model9)$coefficients$count[,c(1,2)]
    Res[9,1:2] = coeff[dim(coeff)[1] - 1]
    Res[9,5] = extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model9,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model9))
    }
    Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }

  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}


#without covariate
.SNP_int_9_zeroinfl_nc = function(Outcome,Adata,Bdata,TestType,ModelType){
  wholeABData = cbind(Outcome,Adata,Bdata)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }
  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  wholeABData = NULL

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }

  model1 = zeroinfl(Outcome~Adata+Bdata+Adata:Bdata|Adata+Bdata+Adata:Bdata,dist=ModelType)
  model2 = zeroinfl(Outcome~Adata+Adata:Bdata|Adata+Adata:Bdata,dist=ModelType)
  model3 = zeroinfl(Outcome~rAdata+rAdata:Bdata|rAdata+rAdata:Bdata,dist=ModelType)
  model4 = zeroinfl(Outcome~Bdata+Adata:Bdata|Bdata+Adata:Bdata,dist=ModelType)
  model5 = zeroinfl(Outcome~rBdata+Adata:rBdata|rBdata+Adata:rBdata,dist=ModelType)
  model6 = zeroinfl(Outcome~Adata:Bdata|Adata:Bdata,dist=ModelType)
  model7 = zeroinfl(Outcome~rAdata:Bdata|rAdata:Bdata,dist=ModelType)
  model8 = zeroinfl(Outcome~Adata:rBdata|Adata:rBdata,dist=ModelType)
  model9 = zeroinfl(Outcome~rAdata:rBdata|rAdata:rBdata,dist=ModelType)

  biccon = log(length(Outcome))

  model0 = zeroinfl(Outcome~1|1,dist=ModelType)
  Res = matrix(numeric(0),9,5)
  if (dim(summary(model2)$coefficients$count)[1]<4){
    Res[1,] = NA
  }else{
    Res[1,1:2] = summary(model1)$coefficients$count[4,c(1,2)]
    Res[1,5] = extractAIC(model1,k=biccon)[2]
    if (is.waldtest){
      modelc = zeroinfl(Outcome~Adata+Bdata|Adata+Bdata,dist=ModelType)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
    }else{
      modelc = zeroinfl(Outcome~Adata+Bdata|Adata+Bdata,dist=ModelType)
      anova = unlist(.lrtest(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (dim(summary(model2)$coefficients$count)[1]<3){
    Res[2,] = NA
  }else{
    Res[2,1:2] = summary(model2)$coefficients$count[3,c(1,2)]
    Res[2,5] = extractAIC(model2,k=biccon)[2]
    if (is.waldtest){
      modelc = zeroinfl(Outcome~Adata|Adata,dist=ModelType)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
    }else{
      modelc = zeroinfl(Outcome~Adata|Adata,dist=ModelType)
      anova = unlist(.lrtest(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (dim(summary(model3)$coefficients$count)[1]<3){
    Res[3,] = NA
  }else{
    Res[3,1:2] = summary(model3)$coefficients$count[3,c(1,2)]
    Res[3,5] = extractAIC(model3,k=biccon)[2]
    if (is.waldtest){
      modelc = zeroinfl(Outcome~rAdata|rAdata,dist=ModelType)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
    }else{
      modelc = zeroinfl(Outcome~rAdata|rAdata,dist=ModelType)
      anova = unlist(.lrtest(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (dim(summary(model4)$coefficients$count)[1]<3){
    Res[4,] = NA
  }else{
    Res[4,1:2] = summary(model4)$coefficients$count[3,c(1,2)]
    Res[4,5] = extractAIC(model4,k=biccon)[2]

    if (is.waldtest){
      modelc = zeroinfl(Outcome~Bdata|Bdata,dist=ModelType)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
    }else{
      modelc = zeroinfl(Outcome~Bdata|Bdata,dist=ModelType)
      anova = unlist(.lrtest(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (dim(summary(model5)$coefficients$count)[1]<3){
    Res[5,] = NA
  }else{
    Res[5,1:2] = summary(model5)$coefficients$count[3,c(1,2)]
    Res[5,5] = extractAIC(model5,k=biccon)[2]
    if (is.waldtest){
      modelc = zeroinfl(Outcome~rBdata|rBdata,dist=ModelType)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
    }else{
      modelc = zeroinfl(Outcome~rBdata|rBdata,dist=ModelType)
      anova = unlist(.lrtest(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (dim(summary(model6)$coefficients$count)[1]<2){
    Res[6,] = NA
  }else{
    Res[6,1:2] = summary(model6)$coefficients$count[2,c(1,2)]
    Res[6,5] = extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model6,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model6))
    }
    Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (dim(summary(model7)$coefficients$count)[1]<2){
    Res[7,] = NA
  }else{
    Res[7,1:2] = summary(model7)$coefficients$count[2,c(1,2)]
    Res[7,5] = extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model7,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model7))
    }
    Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (dim(summary(model8)$coefficients$count)[1]<2){
    Res[8,] = NA
  }else{
    Res[8,1:2] = summary(model8)$coefficients$count[2,c(1,2)]
    Res[8,5] = extractAIC(model8,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model8,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model8))
    }
    Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (dim(summary(model9)$coefficients$count)[1]<2){
    Res[9,] = NA
  }else{
    Res[9,1:2] = summary(model9)$coefficients$count[2,c(1,2)]
    Res[9,5] = extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model9,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model9))
    }
    Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }

  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}

#############
# with covariate (for par)
.SNP_int_9_zeroinfl_c_1 = function(Outcome,Adata,Bdata,X,TestType,ModelType){
  X = data.frame(X)
  wholeABData = cbind(Outcome,Adata,Bdata,X)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }

  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  X = wholeABData[,4:dim(wholeABData)[2]]
  X = data.frame(X)
  wholeABData = NULL

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  data_OAB = data.frame(Outcome=Outcome,Adata=Adata,Bdata=Bdata,
                        rAdata=rAdata,rBdata=rBdata)
  data_OABX = cbind(data_OAB,X)

  data_OAB = NULL

  biccon = log(length(Outcome))
  lenX = dim(X)[2]

  X_names =  paste(colnames(X), collapse= "+")
  rm(Outcome,Adata,Bdata,rAdata,rBdata,X,data_OAB)

  model1_for = as.formula(paste("Outcome~Adata+Bdata+Adata:Bdata+",
                                X_names,"|Adata+Bdata+Adata:Bdata+", X_names))
  model1 = zeroinfl(model1_for,data=data_OABX,dist=ModelType)

  model2_for = as.formula(paste("Outcome~Adata+Adata:Bdata+",
                                X_names,"|Adata+Adata:Bdata+",X_names))
  model2 = zeroinfl(model2_for,data=data_OABX,dist=ModelType)

  model3_for = as.formula(paste("Outcome~rAdata+rAdata:Bdata+",
                                X_names,"|rAdata+rAdata:Bdata+",X_names))
  model3 = zeroinfl(model3_for,data=data_OABX,dist=ModelType)

  model4_for = as.formula(paste("Outcome~Bdata+Adata:Bdata+",
                                X_names,"|Bdata+Adata:Bdata+",X_names))
  model4 = zeroinfl(model4_for,data=data_OABX,dist=ModelType)

  model5_for = as.formula(paste("Outcome~rBdata+Adata:rBdata+",
                                X_names,"|rBdata+Adata:rBdata+",X_names))
  model5 = zeroinfl(model5_for,data=data_OABX,dist=ModelType)

  model6_for = as.formula(paste("Outcome~Adata:Bdata+",
                                X_names,"|Adata:Bdata+",X_names))
  model6 = zeroinfl(model6_for,data=data_OABX,dist=ModelType)

  model7_for = as.formula(paste("Outcome~rAdata:Bdata+",
                                X_names,"|rAdata:Bdata+",X_names))
  model7 = zeroinfl(model7_for,data=data_OABX,dist=ModelType)

  model8_for = as.formula(paste("Outcome~Adata:rBdata+",
                                X_names,"|Adata:rBdata+",X_names))
  model8 = zeroinfl(model8_for,data=data_OABX,dist=ModelType)

  model9_for = as.formula(paste("Outcome~rAdata:rBdata+",
                                X_names,"|rAdata:rBdata+",X_names))
  model9 = zeroinfl(model9_for,data=data_OABX,dist=ModelType)

  model0_for = as.formula(paste("Outcome~",
                                X_names,"|",X_names))
  model0 = zeroinfl(model0_for,data=data_OABX,dist=ModelType)


  Res = matrix(numeric(0),9,5)

  if (is.na(model1$coefficients$count[length(model1$coefficients$count)])){
    Res[1,] = NA
  }else{
    Res[1,5] = extractAIC(model1,k=biccon)[2]
    model1_for = as.formula(paste("Outcome~Adata+Bdata+",
                                  X_names,"|Adata+Bdata+",X_names))
    if (is.waldtest){
      modelc = zeroinfl(model1_for,data=data_OABX,dist=ModelType)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
    }else{
      modelc = zeroinfl(model1_for,data=data_OABX,dist=ModelType)
      anova = unlist(.lrtest(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (is.na(model2$coefficients$count[length(model2$coefficients$count)])){
    Res[2,] = NA
  }else{
    Res[2,5] = extractAIC(model2,k=biccon)[2]
    model2_for = as.formula(paste("Outcome~Adata+",
                                  X_names,"|Adata+",X_names))
    if (is.waldtest){
      modelc = zeroinfl(model2_for,data=data_OABX,dist=ModelType)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
    }else{
      modelc = zeroinfl(model2_for,data=data_OABX,dist=ModelType)
      anova = unlist(.lrtest(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (is.na(model3$coefficients$count[length(model3$coefficients$count)])){
    Res[3,] = NA
  }else{
    Res[3,5] = extractAIC(model3,k=biccon)[2]
    model3_for = as.formula(paste("Outcome~rAdata+",
                                  X_names,"|rAdata+",X_names))
    if (is.waldtest){
      modelc = zeroinfl(model3_for,data=data_OABX,dist=ModelType)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
    }else{
      modelc = zeroinfl(model3_for,data=data_OABX,dist=ModelType)
      anova = unlist(.lrtest(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (is.na(model4$coefficients$count[length(model4$coefficients$count)])){
    Res[4,] = NA
  }else{
    Res[4,5] = extractAIC(model4,k=biccon)[2]
    model4_for = as.formula(paste("Outcome~Bdata+",
                                  X_names,"|Bdata+",X_names))
    if (is.waldtest){
      modelc = zeroinfl(model4_for,data=data_OABX,dist=ModelType)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
    }else{
      modelc = zeroinfl(model4_for,data=data_OABX,dist=ModelType)
      anova = unlist(.lrtest(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (is.na(model5$coefficients$count[length(model5$coefficients$count)])){
    Res[5,] = NA
  }else{
    Res[5,5] = extractAIC(model5,k=biccon)[2]
    model5_for = as.formula(paste("Outcome~rBdata+",
                                  X_names,"|rBdata+",X_names))
    if (is.waldtest){
      modelc = zeroinfl(model5_for,data=data_OABX,dist=ModelType)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
    }else{
      modelc = zeroinfl(model5_for,data=data_OABX,dist=ModelType)
      anova = unlist(.lrtest(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (is.na(model6$coefficients$count[length(model6$coefficients$count)])){
    Res[6,] = NA
  }else{
    Res[6,5] = extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model6,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model6))
    }
    Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (is.na(model7$coefficients$count[length(model7$coefficients$count)])){
    Res[7,] = NA
  }else{
    Res[7,5] = extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model7,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model7))
    }
    Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (is.na(model8$coefficients$count[length(model8$coefficients$count)])){
    Res[8,] = NA
  }else{
    Res[8,5] = extractAIC(model8,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova = unlist(.waldtest(model0,model8,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model8))
    }
    Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (is.na(model9$coefficients$count[length(model9$coefficients$count)])){
    Res[9,] = NA
  }else{
    Res[9,5] = extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model9,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model9))
    }
    Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }

  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}

#without covariate (for par)
.SNP_int_9_zeroinfl_nc_1 = function(Outcome,Adata,Bdata,TestType,ModelType){
  if (TestType=='WaldTest'){
    wholeABData = cbind(Outcome,Adata,Bdata)
    vdata = complete.cases(wholeABData)
    wholeABData = wholeABData[vdata,]
    min_sample = length(names(wholeABData)) + 3
    if (sum(vdata)<min_sample){
      Res = matrix(rep(NA,45),9,5)
      rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
      return(Res)
    }

    Outcome = wholeABData[,1]
    Adata = wholeABData[,2]
    Bdata = wholeABData[,3]
    if (sum(Adata==2)>0){
      rAdata = abs(2-Adata)
      rBdata = abs(2-Bdata)
    }else{
      rAdata = 1-Adata
      rBdata = 1-Bdata
    }

    model1 = zeroinfl(Outcome~Adata+Bdata+Adata:Bdata|Adata+Bdata+Adata:Bdata,dist=ModelType)
    model2 = zeroinfl(Outcome~Adata+Adata:Bdata|Adata+Adata:Bdata,dist=ModelType)
    model3 = zeroinfl(Outcome~rAdata+rAdata:Bdata|rAdata+rAdata:Bdata,dist=ModelType)
    model4 = zeroinfl(Outcome~Bdata+Adata:Bdata|Bdata+Adata:Bdata,dist=ModelType)
    model5 = zeroinfl(Outcome~rBdata+Adata:rBdata|rBdata+Adata:rBdata,dist=ModelType)
    model6 = zeroinfl(Outcome~Adata:Bdata|Adata:Bdata,dist=ModelType)
    model7 = zeroinfl(Outcome~rAdata:Bdata|rAdata:Bdata,dist=ModelType)
    model8 = zeroinfl(Outcome~Adata:rBdata|Adata:rBdata,dist=ModelType)
    model9 = zeroinfl(Outcome~rAdata:rBdata|rAdata:rBdata,dist=ModelType)

    biccon = log(length(Outcome))
    model0 = zeroinfl(Outcome~1|1,dist=ModelType)


    Res = matrix(numeric(0),9,5)
    if (dim(summary(model1)$coefficients$count)[1]<4){
      Res[1,] = NA
    }else{
      Res[1,5] = extractAIC(model1,k=biccon)[2]
      modelc = zeroinfl(Outcome~Adata+Bdata|Adata+Bdata,dist=ModelType)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
      Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[1,]=NA}
    }
    if (dim(summary(model2)$coefficients$count)[1]<3){
      Res[2,] = NA
    }else{
      Res[2,5] = extractAIC(model2,k=biccon)[2]
      modelc = zeroinfl(Outcome~Adata|Adata,dist=ModelType)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
      Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[2,]=NA}
    }
    if (dim(summary(model3)$coefficients$count)[1]<3){
      Res[3,] = NA
    }else{
      Res[3,5] = extractAIC(model3,k=biccon)[2]
      modelc = zeroinfl(Outcome~rAdata|rAdata,dist=ModelType)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
      Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[3,]=NA}
    }
    if (dim(summary(model4)$coefficients$count)[1]<3){
      Res[4,] = NA
    }else{
      Res[4,5] = extractAIC(model4,k=biccon)[2]
      modelc = zeroinfl(Outcome~Bdata|Bdata,dist=ModelType)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
      Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[4,]=NA}
    }
    if (dim(summary(model5)$coefficients$count)[1]<3){
      Res[5,] = NA
    }else{
      Res[5,5] = extractAIC(model5,k=biccon)[2]
      modelc = zeroinfl(Outcome~rBdata|rBdata,dist=ModelType)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
      Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[5,]=NA}
    }
    if (dim(summary(model6)$coefficients$count)[1]<2){
      Res[6,] = NA
    }else{
      Res[6,5] = extractAIC(model6,k=biccon)[2]
      anova = unlist(.waldtest(model0,model6,test="Chisq"))
      Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[6,]=NA}
    }
    if (dim(summary(model7)$coefficients$count)[1]<2){
      Res[7,] = NA
    }else{
      Res[7,5] = extractAIC(model7,k=biccon)[2]
      anova = unlist(.waldtest(model0,model7,test="Chisq"))
      Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[7,]=NA}
    }
    if (dim(summary(model8)$coefficients$count)[1]<2){
      Res[8,] = NA
    }else{
      Res[8,5] = extractAIC(model8,k=biccon)[2]
      anova = unlist(.waldtest(model0,model8,test="Chisq"))
      Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[8,]=NA}
    }
    if (dim(summary(model9)$coefficients$count)[1]<2){
      Res[9,] = NA
    }else{
      Res[9,5] = extractAIC(model9,k=biccon)[2]
      anova = unlist(.waldtest(model0,model9,test="Chisq"))
      Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[9,]=NA}
    }
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    wholeABData = cbind(Outcome,Adata,Bdata)
    vdata = complete.cases(wholeABData)
    wholeABData = wholeABData[vdata,]
    min_sample = length(names(wholeABData)) + 3
    if (sum(vdata)<min_sample){
      Res = matrix(rep(NA,45),9,5)
      rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
      return(Res)
    }
    Outcome = wholeABData[,1]
    Adata = wholeABData[,2]
    Bdata = wholeABData[,3]
    wholeABData = NULL

    if (sum(Adata==2)>0){
      rAdata = abs(2-Adata)
      rBdata = abs(2-Bdata)
    }else{
      rAdata = 1-Adata
      rBdata = 1-Bdata
    }

    model1 = zeroinfl(Outcome~Adata+Bdata+Adata:Bdata|Adata+Bdata+Adata:Bdata,dist=ModelType)
    model2 = zeroinfl(Outcome~Adata+Adata:Bdata|Adata+Adata:Bdata,dist=ModelType)
    model3 = zeroinfl(Outcome~rAdata+rAdata:Bdata|rAdata+rAdata:Bdata,dist=ModelType)
    model4 = zeroinfl(Outcome~Bdata+Adata:Bdata|Bdata+Adata:Bdata,dist=ModelType)
    model5 = zeroinfl(Outcome~rBdata+Adata:rBdata|rBdata+Adata:rBdata,dist=ModelType)
    model6 = zeroinfl(Outcome~Adata:Bdata|Adata:Bdata,dist=ModelType)
    model7 = zeroinfl(Outcome~rAdata:Bdata|rAdata:Bdata,dist=ModelType)
    model8 = zeroinfl(Outcome~Adata:rBdata|Adata:rBdata,dist=ModelType)
    model9 = zeroinfl(Outcome~rAdata:rBdata|rAdata:rBdata,dist=ModelType)

    biccon = log(length(Outcome))
    model0 = zeroinfl(Outcome~1|1,dist=ModelType)

    Res = matrix(0,9,5)
    if (dim(summary(model1)$coefficients$count)[1]<4){
      Res[1,] = NA
    }else{
      Res[1,5] = extractAIC(model1,k=biccon)[2]
      modelc = zeroinfl(Outcome~Adata+Bdata|Adata+Bdata,dist=ModelType)
      anova = unlist(.lrtest(modelc,model1))
      Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[1,]=NA}
    }
    if (dim(summary(model2)$coefficients$count)[1]<3){
      Res[2,] = NA
    }else{
      Res[2,5] = extractAIC(model2,k=biccon)[2]
      modelc = zeroinfl(Outcome~Adata|Adata,dist=ModelType)
      anova = unlist(.lrtest(modelc,model2))
      Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[2,]=NA}
    }
    if (dim(summary(model3)$coefficients$count)[1]<3){
      Res[3,] = NA
    }else{
      Res[3,5] = extractAIC(model3,k=biccon)[2]
      modelc = zeroinfl(Outcome~rAdata|rAdata,dist=ModelType)
      anova = unlist(.lrtest(modelc,model3))
      Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[3,]=NA}
    }
    if (dim(summary(model4)$coefficients$count)[1]<3){
      Res[4,] = NA
    }else{
      Res[4,5] = extractAIC(model4,k=biccon)[2]
      modelc = zeroinfl(Outcome~Bdata|Bdata,dist=ModelType)
      anova = unlist(.lrtest(modelc,model4))
      Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[4,]=NA}
    }
    if (dim(summary(model5)$coefficients$count)[1]<3){
      Res[5,] = NA
    }else{
      Res[5,5] = extractAIC(model5,k=biccon)[2]
      modelc = zeroinfl(Outcome~rBdata|rBdata,dist=ModelType)
      anova = unlist(.lrtest(modelc,model5))
      Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[5,]=NA}
    }
    if (dim(summary(model6)$coefficients$count)[1]<2){
      Res[6,] = NA
    }else{
      Res[6,5] = extractAIC(model6,k=biccon)[2]
      anova = unlist(.lrtest(model0,model6))
      Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[6,]=NA}
    }
    if (dim(summary(model7)$coefficients$count)[1]<2){
      Res[7,] = NA
    }else{
      Res[7,5] = extractAIC(model7,k=biccon)[2]
      anova = unlist(.lrtest(model0,model7))
      Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[7,]=NA}
    }
    if (dim(summary(model8)$coefficients$count)[1]<2){
      Res[8,] = NA
    }else{
      Res[8,5] = extractAIC(model8,k=biccon)[2]
      anova = unlist(.lrtest(model0,model8))
      Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[8,]=NA}
    }
    if (dim(summary(model9)$coefficients$count)[1]<2){
      Res[9,] = NA
    }else{
      Res[9,5] = extractAIC(model9,k=biccon)[2]
      anova = unlist(.lrtest(model0,model9))
      Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[9,]=NA}
    }
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}
####################

