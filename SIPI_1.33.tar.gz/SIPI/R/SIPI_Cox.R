################
#SNP Interaction Pattern Identifier (SIPI)
.SNP_Cox_int_9 = function(Time,event,Adata,Bdata,X,ZIM,TestType,ModelType){
  if (length(X)==0){
    if (ZIM){
      return(.SNP_int_9_zeroinfl_nc(Outcome,Adata,Bdata,TestType,ModelType))
    }
    else{
      return(.SNP_Cox_int_9_nc(Time,event,Adata,Bdata,TestType))
    }
  }else{
    if (ZIM){
      return(.SNP_int_9_zeroinfl_c(Outcome,Adata,Bdata,X,TestType,ModelType))
    }else{
      return(.SNP_Cox_int_9_c(Time,event,Adata,Bdata,X,TestType))
    }
  }
}


###function for each pair to get min(BIC) in 45 models
#DD:Dom-Dom
#DR:Dom-Rec
#RD:Rec-Dom
#RR:Rec-Rec
#AA:Add-Add
.SNP_Cox_int_45 = function(Time,event,Domdata,Recdata,Condata,a,b,X,ZIM,TestType){
  DD = .SNP_Cox_int_9(Time,event,Domdata[,a],Domdata[,b],X,ZIM,TestType)
  DR = .SNP_Cox_int_9(Time,event,Domdata[,a],Recdata[,b],X,ZIM,TestType)
  RD = .SNP_Cox_int_9(Time,event,Recdata[,a],Domdata[,b],X,ZIM,TestType)
  RR = .SNP_Cox_int_9(Time,event,Recdata[,a],Recdata[,b],X,ZIM,TestType)
  AA = .SNP_Cox_int_9(Time,event,Condata[,a],Condata[,b],X,ZIM,TestType)
  Bic = c(DD[,5],DR[,5],RD[,5],RR[,5],AA[,5])
  if (all(is.na(Bic))){
    MinCp = MaxC = Minm = NA
  }else{
    m = which.min(Bic)
    Cp = c(DD[,4],DR[,4],RD[,4],RR[,4],AA[,4])
    Cv = c(DD[,3],DR[,3],RD[,3],RR[,3],AA[,3])
    MinCp = Cp[m]
    MaxC = Cv[m]
    minB = c(DD[,1],DR[,1],RD[,1],RR[,1],AA[,1])[m]
    minS = c(DD[,2],DR[,2],RD[,2],RR[,2],AA[,2])[m]
    mod = c("DD","DR","RD","RR","AA")[ceiling(m/9)]
    Minm = paste(mod,names(m),sep='_')
  }

  rownames(DD) = paste("DD",rownames(DD),sep='_')
  rownames(DR) = paste("DR",rownames(DR),sep='_')
  rownames(RD) = paste("RD",rownames(RD),sep='_')
  rownames(RR) = paste("RR",rownames(RR),sep='_')
  rownames(AA) = paste("AA",rownames(AA),sep='_')
  return(list(DD=DD,DR=DR,RD=RD,RR=RR,AA=AA,Bic=Bic,SM=Minm,Scv=MaxC,Scp=MinCp,minB=minB,minS=minS))
}

##
.X_DataFrame = function(X, categXNames){
  if (length(X)==0|length(categXNames)==0|is.factor(X)){
    return(X)
  }else if (is.vector(X)){
    X = factor(X)
    return(X)
  }else if(length(categXNames)==1){
    X[,categXNames] = factor(X[,categXNames])
    return(X)
  }else{
    X[,categXNames]=lapply(X[,categXNames],factor)
    return(X)
  }

}


##function for one-pair analysis/pairwise analysis
SIPI_Cox = function(Time,event,SNPdata,PairInfo,X=NULL,categXNames=NULL,ZIM=FALSE,TestType="WaldTest"){
  X = .X_DataFrame(X,categXNames)
  Nsnp = dim(SNPdata)[2]
  sData = setupSNP(SNPdata,1:Nsnp,sep="")
  Domdata = sapply(1:Nsnp, function(x) as.numeric(dominant(sData[,x]))) - 1
  Recdata = sapply(1:Nsnp, function(x) as.numeric(recessive(sData[,x]))) - 1
  Condata = sapply(1:Nsnp, function(x) as.numeric(additive(sData[,x])))

  checkTwo = sapply(1:Nsnp, function(x)length(unique(na.omit(sData[,x]))))
  if (any(checkTwo<3)){
    VectorIntersect <- function(v,z) {
      unlist(lapply(unique(v[v%in%z]), function(x) rep(x,min(sum(v==x),sum(z==x)))))
    }
    is.contained <- function(v,z) {length(VectorIntersect(v,z))==length(v)}
    for (i in which(checkTwo<3)){
      for (j in which(checkTwo==3)){
        if (is.contained(levels(unique(na.omit(sData[,i]))),levels(unique(na.omit(sData[,j])))) ){
          q1 = c(as.character(SNPdata[,j]),as.character(SNPdata[,i]))
          q1f = data.frame(q1)
          q = setupSNP(q1f,1,sep="")
          Domdata[,i] = as.numeric(dominant(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Recdata[,i] = as.numeric(recessive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Condata[,i] = as.numeric(additive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]]
          break
        }
      }
    }
  }

  sData = NULL
  if (is.list(PairInfo)){
    PairInfo = as.matrix(expand.grid(PairInfo[[1]], PairInfo[[2]]))
  }
  if (any(PairInfo=="all")){
    matrix_idx = 1
  }else if (is.null(dim(PairInfo))){
    matrix_idx = 2
  }else{
    matrix_idx = 3
  }

  if (matrix_idx != 2){
    SNPNames = colnames(SNPdata)
    if (matrix_idx == 1){
      allpair = combn(1:Nsnp,2)
    }else{
      PairInfo = as.matrix(PairInfo)
      allpair = .pairIndex(SNPNames, PairInfo)
    }
    comslist = split(t(allpair),as.factor(1:dim(t(allpair))[1]))
    reslist = sapply(comslist,
                     function(allpair){
                       Eachp = .SNP_Cox_int_45_r(Time,event,Domdata,Recdata,Condata,allpair[1],allpair[2],X,ZIM,TestType)
                       if (length(Eachp$Scv)==0){
                         return(c(NA,NA,NA,NA,NA,NA))
                       }else{
                         return(c(Eachp$SM,Eachp$Scv,Eachp$Scp,min(Eachp$Bic),Eachp$minB,Eachp$minS))
                       }

                     })

    res = data.frame(unlist(lapply(allpair[1,], function(m) SNPNames[[m]])),
                     unlist(lapply(allpair[2,], function(m) SNPNames[[m]])),
                     reslist[1,],
                     as.numeric(reslist[2,]),
                     as.numeric(reslist[3,]),stringsAsFactors=FALSE)

    if (TestType=="WaldTest"){
      colnames(res) = c("Var1","Var2","Pattern","Wald_Chisq","Wald_p")
    }else{
      colnames(res) = c("Var1","Var2","Pattern","LRT_Chisq","LRT_p")
    }

    return(list(selectedModel=res))



  }else{
    SNPNames = colnames(SNPdata)
    a = which(SNPNames==PairInfo[1])
    b = which(SNPNames==PairInfo[2])
    resSM = resSv = resSp = resScv = resScp = resnames1 = resnames2 = resbeta = resbeta = c()
    Eachp = .SNP_Cox_int_45(Time,event,Domdata,Recdata,Condata,a,b,X,ZIM=FALSE,TestType)
    if (length(Eachp$Scv)==0 | is.na(Eachp$Scv)){
      resSM = NA
      resScv = NA
      resScp = NA
      resBic = NA
      resbeta = NA
      resstd =  NA
      res45models = NA
    }else{
      resSM = Eachp$SM
      resScv = Eachp$Scv
      resScp = Eachp$Scp
      resBic = min(Eachp$Bic,na.rm=TRUE)
      resbeta = Eachp$minB
      resstd =  Eachp$minS
      res45models = data.frame(rbind(Eachp$DD,Eachp$DR,Eachp$RD,Eachp$RR,Eachp$AA))
      res45models = res45models[with(res45models,order(BIC)),]
      Var1 = rep(PairInfo[1],45)
      Var2 = rep(PairInfo[2],45)
      Pattern = as.matrix(rownames(res45models))

      res45models_G = cbind(Var1,Var2,Pattern,res45models[,c(5,3,4,1,2)])
      rownames(res45models_G) = NULL

      res45models = cbind(Var1,Var2,Pattern,res45models[,c(5,3,4)])
      rownames(res45models) = NULL
    }
    resnames1 = PairInfo[1]
    resnames2 = PairInfo[2]

    res = data.frame(resnames1,resnames2,
                     resSM,resBic,resScv,resScp,stringsAsFactors=FALSE)
    rownames(res) = ''
    if (TestType=="WaldTest"){
      colnames(res) = c("Var1","Var2","Pattern","BIC","Wald_Chisq","Wald_p")
    }else{
      colnames(res) = c("Var1","Var2","Pattern","BIC","LRT_Chisq","LRT_p")
    }
    return(list(selectedModel=res,res45Models=res45models))

  }
}


