###function for each pair to get min(BIC) in 9 models
#AA:Add-Add
.SNP_int_45_mini = function(Outcome,Domdata,Recdata,Condata,a,b,X,ZIM,TestType,ModelType){
  AA = .SNP_int_9(Outcome,Condata[,a],Condata[,b],X,ZIM,TestType,ModelType)
  Bic = AA[,5]
  if (all(is.na(Bic))){
    MinCp = MaxC = Minm = NA
  }else{
  m = which.min(Bic)
  Cp = AA[,4]
  Cv = AA[,3]
  MinCp = Cp[m]
  MaxC = Cv[m]
  minB = AA[m,1]
  minS = AA[m,2]
  mod = "AA"
  Minm = paste(mod,names(m),sep='_')
  }
  rownames(AA) = paste("AA",rownames(AA),sep='_')
  return(list(AA=AA,Bic=Bic,SM=Minm,Scv=MaxC,Scp=MinCp,minB=minB,minS=minS))
}

##function for one-pair analysis/pairwise analysis
AA9int = function(Outcome,SNPdata,PairInfo,X=NULL,categXNames=NULL,ZIM=FALSE,TestType="WaldTest",ModelType="binomial",OR=FALSE){
  X = .X_DataFrame(X,categXNames)
  Nsnp = dim(SNPdata)[2]
  sData = setupSNP(SNPdata,1:Nsnp,sep="")
  Domdata = sapply(1:Nsnp, function(x) as.numeric(dominant(sData[,x]))) - 1
  Recdata = sapply(1:Nsnp, function(x) as.numeric(recessive(sData[,x]))) - 1
  Condata = sapply(1:Nsnp, function(x) as.numeric(additive(sData[,x])))

  checkTwo = sapply(1:Nsnp, function(x)length(unique(na.omit(sData[,x]))))
  if (any(checkTwo<3)){
    VectorIntersect <- function(v,z) {
      unlist(lapply(unique(v[v%in%z]), function(x) rep(x,min(sum(v==x),sum(z==x)))))
    }
    is.contained <- function(v,z) {length(VectorIntersect(v,z))==length(v)}
    for (i in which(checkTwo<3)){
      for (j in which(checkTwo==3)){
        if (is.contained(levels(unique(na.omit(sData[,i]))),levels(unique(na.omit(sData[,j])))) ){
          q1 = c(as.character(SNPdata[,j]),as.character(SNPdata[,i]))
          q1f = data.frame(q1)
          q = setupSNP(q1f,1,sep="")
          Domdata[,i] = as.numeric(dominant(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Recdata[,i] = as.numeric(recessive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Condata[,i] = as.numeric(additive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]]
          break
        }
      }
    }
  }


  sData = NULL
  if (is.list(PairInfo)){
    PairInfo = as.matrix(expand.grid(PairInfo[[1]], PairInfo[[2]]))
  }
  if (any(PairInfo=="all")){
    matrix_idx = 1
  }else if (is.null(dim(PairInfo))){
    matrix_idx = 2
  }else{
    matrix_idx = 3
  }

  if (matrix_idx != 2){
    SNPNames = colnames(SNPdata)
    if (matrix_idx == 1){
      allpair = combn(1:Nsnp,2)
    }else{
      PairInfo = as.matrix(PairInfo)
      allpair = .pairIndex(SNPNames, PairInfo)
    }
    comslist = split(t(allpair),as.factor(1:dim(t(allpair))[1]))
    reslist = sapply(comslist,
                     function(allpair){
                       Eachp = .SNP_int_45_mini(Outcome,Domdata,Recdata,Condata,allpair[1],allpair[2],X,ZIM,TestType,ModelType)
                       if (length(Eachp$Scv)==0){
                         return(c(NA,NA,NA,NA,NA,NA))
                       }else{
                         return(c(Eachp$SM,Eachp$Scv,Eachp$Scp,min(Eachp$Bic),Eachp$minB,Eachp$minS))
                       }

                     })
    if (ModelType=="binomial"){
      res = data.frame(unlist(lapply(allpair[1,], function(m) SNPNames[[m]])),
                       unlist(lapply(allpair[2,], function(m) SNPNames[[m]])),
                       reslist[1,],
                       as.numeric(reslist[2,]),
                       as.numeric(reslist[3,]),stringsAsFactors=FALSE)

      if (TestType=="WaldTest"){
        colnames(res) = c("Var1","Var2","Pattern","Wald_Chisq","Wald_p")
      }else{
        colnames(res) = c("Var1","Var2","Pattern","LRT_Chisq","LRT_p")
      }


      if (OR==TRUE){
        if (matrix_idx==1){
          #OR = OddsRatioEst_unit_forall(Outcome,SNPdata,res[,1],res[,2],res[,3])
          #OR = OddsRatioEst_unit_pair_cal(Outcome,SNPdata,res[,1],res[,2],res[,3])
          OR = OddsRatioEst_unit_pair_cal_ALL(Outcome,SNPdata,res[,1],res[,2],res[,3],X)
        }else{
          #OR = OddsRatioEst_unit(Outcome,SNPdata,res[,1],res[,2],res[,3])
          #OR = OddsRatioEst_unit_pair_cal(Outcome,SNPdata,res[,1],res[,2],res[,3])
          OR = OddsRatioEst_unit_pair_cal_ALL(Outcome,SNPdata,res[,1],res[,2],res[,3],X)
        }
        return(list(selectedModel=res, OR=OR))
      }else{
        return(list(selectedModel=res))
      }
    }else{##Guassian##
      res = data.frame(unlist(lapply(allpair[1,], function(m) SNPNames[[m]])),
                       unlist(lapply(allpair[2,], function(m) SNPNames[[m]])),
                       reslist[1,],
                       as.numeric(reslist[2,]),
                       as.numeric(reslist[3,]),
                       as.numeric(reslist[5,]),
                       as.numeric(reslist[6,]),stringsAsFactors=FALSE)

      if (TestType=="WaldTest"){
        colnames(res) = c("Var1","Var2","Pattern","Wald_Chisq","Wald_p","Est.","Std.Er")
      }else{
        colnames(res) = c("Var1","Var2","Pattern","LRT_Chisq","LRT_p","Est.","Std.Er")
      }
      return(list(selectedModel=res))
    }

  }else{
    SNPNames = colnames(SNPdata)
    a = which(SNPNames==PairInfo[1])
    b = which(SNPNames==PairInfo[2])
    resSM = resSv = resSp = resScv = resScp = resnames1 = resnames2 = resbeta = resstd = c()
    Eachp = .SNP_int_45_mini(Outcome,Domdata,Recdata,Condata,a,b,X,ZIM,TestType,ModelType)
    if (length(Eachp$Scv)==0| is.na(Eachp$Scv)){
      resSM = NA
      resScv = NA
      resScp = NA
      resBic = NA
      resbeta = NA
      resstd =  NA
      res45models = NA
    }else{
      resSM = Eachp$SM
      resScv = Eachp$Scv
      resScp = Eachp$Scp
      resBic = min(Eachp$Bic,na.rm=TRUE)
      resbeta = Eachp$minB
      resstd =  Eachp$minS
      res9models = data.frame(Eachp$AA)
      res9models = res9models[with(res9models,order(BIC)),]
      Var1 = rep(PairInfo[1],9)
      Var2 = rep(PairInfo[2],9)
      Pattern = as.matrix(rownames(res9models))

      res9models_G = cbind(Var1,Var2,Pattern,res9models[,c(5,3,4,1,2)])
      rownames(res9models_G) = NULL

      res9models = cbind(Var1,Var2,Pattern,res9models[,c(5,3,4)])
      rownames(res9models) = NULL

    }
    resnames1 = PairInfo[1]
    resnames2 = PairInfo[2]

    if (ModelType=="binomial"){
      res = data.frame(resnames1,resnames2,
                       resSM,resBic,resScv,resScp,
                       stringsAsFactors=FALSE)
      rownames(res) = ''
      if (TestType=="WaldTest"){
        colnames(res) = c("Var1","Var2","Pattern","BIC","Wald_Chisq","Wald_p")
      }else{
        colnames(res) = c("Var1","Var2","Pattern","BIC","LRT_Chisq","LRT_p")
      }
      if (OR==TRUE){
        #OR = OddsRatioEst(Outcome,SNPdata,PairInfo)
        OR = OddsRatioEst_unit_pair_cal_ALL(Outcome,SNPdata,res[,1],res[,2],res[,3],X)
        return(list(selectedModel=res,res9Models=res9models,OR=OR))
      }else{
        return(list(selectedModel=res,res9Models=res9models))
      }
    }else{##Guassian##
      res = data.frame(resnames1,resnames2,
                       resSM,resBic,resScv,resScp,resbeta,resstd,stringsAsFactors=FALSE)
      rownames(res) = ''
      if (TestType=="WaldTest"){
        colnames(res) = c("Var1","Var2","Pattern","BIC","Wald_Chisq","Wald_p","Est.","Std.Er")
      }else{
        colnames(res) = c("Var1","Var2","Pattern","BIC","LRT_Chisq","LRT_p","Est.","Std.Er")
      }
      return(list(selectedModel=res,res9Models=res9models_G))
    }

  }
}


##function for one-pair analysis/pairwise analysis
.SIPI_mini_r = function(Outcome,Domdata,Recdata,Condata,PairInfo,X,ZIM,TestType,ModelType,matrix_idx){
  Eachp = .SNP_int_45_mini(Outcome,Domdata,Recdata,Condata,PairInfo[1],PairInfo[2],X,ZIM,TestType,ModelType)
  if (length(Eachp$Scv)==0){
    return(data.frame(NA,NA,NA,NA,NA,stringsAsFactors=FALSE))
  }else{
    return(data.frame(Eachp$SM,as.numeric(Eachp$Scv),as.numeric(Eachp$Scp),Eachp$minB,Eachp$minS,stringsAsFactors=FALSE))
  }
}

#parallel computing for SIPI
parAA9int = function (Outcome,SNPdata,PairInfo,X=NULL,categXNames=NULL,ZIM=FALSE,TestType="WaldTest",ModelType="binomial",core_ratio=0.9,OR=FALSE){
  X = .X_DataFrame(X,categXNames)
  .SIPI.whole = function(x){
    library(SIPI)
    return(.SIPI_mini_r(Outcome,Domdata,Recdata,Condata,c(x[1],x[2]),X,ZIM,TestType,ModelType,matrix_idx))
  }
  SNPNames = colnames(SNPdata)
  if (is.list(PairInfo)){
    PairInfo = as.matrix(expand.grid(PairInfo[[1]], PairInfo[[2]]))
  }
  if (any(PairInfo=="all")){
    allpair = combn(1:dim(SNPdata)[2],2)
    matrix_idx = 1
    SNPnames = t(combn(SNPNames,2))
  }else if (is.null(dim(PairInfo))){
    PairInfo = matrix(PairInfo,1,2)
    SNPnames = as.matrix(PairInfo)
    allpair = .pairIndex(SNPNames, SNPnames)
    matrix_idx = 3
  }else{
    SNPnames = as.matrix(PairInfo)
    allpair = .pairIndex(SNPNames, SNPnames)
    matrix_idx = 3
  }

  Nsnp = dim(SNPdata)[2]
  sData = setupSNP(SNPdata,1:Nsnp,sep="")
  Domdata = sapply(1:Nsnp, function(x) as.numeric(dominant(sData[,x]))) - 1
  Recdata = sapply(1:Nsnp, function(x) as.numeric(recessive(sData[,x]))) - 1
  Condata = sapply(1:Nsnp, function(x) as.numeric(additive(sData[,x])))

  checkTwo = sapply(1:Nsnp, function(x)length(unique(na.omit(sData[,x]))))
  if (any(checkTwo<3)){
    VectorIntersect <- function(v,z) {
      unlist(lapply(unique(v[v%in%z]), function(x) rep(x,min(sum(v==x),sum(z==x)))))
    }
    is.contained <- function(v,z) {length(VectorIntersect(v,z))==length(v)}
    for (i in which(checkTwo<3)){
      for (j in which(checkTwo==3)){
        if (is.contained(levels(unique(na.omit(sData[,i]))),levels(unique(na.omit(sData[,j])))) ){
          q1 = c(as.character(SNPdata[,j]),as.character(SNPdata[,i]))
          q1f = data.frame(q1)
          q = setupSNP(q1f,1,sep="")
          Domdata[,i] = as.numeric(dominant(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Recdata[,i] = as.numeric(recessive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Condata[,i] = as.numeric(additive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]]
          break
        }
      }
    }
  }


  sData = NULL

  comslist = split(t(allpair),as.factor(1:dim(t(allpair))[1]))
  num_cores = detectCores()
  num_cores = as.integer(num_cores * core_ratio)
  cl = makeCluster(num_cores)
  Outcome <<- Outcome
  Domdata <<- Domdata
  Recdata <<- Recdata
  Condata <<- Condata
  X <<- X
  TestType <<- TestType
  ModelType <<- ModelType
  matrix_idx <<- matrix_idx
  package <<- library(SIPI)
  clusterExport(cl,varlist=c("Outcome","Domdata","Recdata","Condata","X","TestType","ModelType","matrix_idx","package"))

  res = parSapply(cl,comslist,.SIPI.whole)
  stopCluster(cl)
  res = data.frame(t(matrix(unlist(res),5)),stringsAsFactors=FALSE)
  res[,2] = as.numeric(res[,2])
  res[,3] = as.numeric(res[,3])
  res[,4] = as.numeric(res[,4])
  res[,5] = as.numeric(res[,5])

  if (ModelType=="binomial"){
    res = cbind(SNPnames, res[,c(1,2,3)])
    if (TestType=="WaldTest"){
      colnames(res) = c("Var1","Var2","Pattern","Wald_Chisq","Wald_p")
    }else{
      colnames(res) = c("Var1","Var2","Pattern","LRT_Chisq","LRT_p")
    }
    if (OR==TRUE){
      if (matrix_idx==1){
        #OR = OddsRatioEst_unit_forall(Outcome,SNPdata,res[,1],res[,2],res[,3])
        #OR = OddsRatioEst_unit_pair_cal(Outcome,SNPdata,res[,1],res[,2],res[,3])
        OR = OddsRatioEst_unit_pair_cal_ALL(Outcome,SNPdata,res[,1],res[,2],res[,3],X)
      }else{
        #OR = OddsRatioEst_unit(Outcome,SNPdata,res[,1],res[,2],res[,3])
        #OR = OddsRatioEst_unit_pair_cal(Outcome,SNPdata,res[,1],res[,2],res[,3])
        OR = OddsRatioEst_unit_pair_cal_ALL(Outcome,SNPdata,res[,1],res[,2],res[,3],X)
      }
      return(list(selectedModel=res,OR=OR))
    }else{
      return(res)
    }
  }else{##Gaussian##
    res = cbind(SNPnames, res)
    if (TestType=="WaldTest"){
      colnames(res) = c("Var1","Var2","Pattern","Wald_Chisq","Wald_p","Est.","Std.Er")
    }else{
      colnames(res) = c("Var1","Var2","Pattern","LRT_Chisq","LRT_p","Est.","Std.Er")
    }
    return(res)
  }


}

