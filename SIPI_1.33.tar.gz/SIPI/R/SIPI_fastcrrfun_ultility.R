library(fastcmprsk)
library(MASS)

extract_cox_data <- function(f, data_used) {
  surv_terms <- all.vars(f[[2]])
  time <- data_used[[surv_terms[1]]]
  status <- data_used[[surv_terms[2]]]

  rhs_formula <- reformulate(attr(terms(f), "term.labels"))

  cov_matrix <- model.matrix(rhs_formula, data_used)[, -1, drop = FALSE]
  if (ncol(cov_matrix) == 0) {
    cov_matrix <- model.matrix(rhs_formula, data_used)[, 1, drop = FALSE]
  }
  df <- data.frame(
    time = time,
    status = status,
    as.data.frame(cov_matrix)
  )
  list(
    time = time,
    status = status,
    cov = as.data.frame(cov_matrix),
    df=df
  )
}

fastCrr_to_coxph_like <- function(fit_fcrr, formula, data, status_vec, failcode = 1) {
  beta <- fit_fcrr$coef
  var  <- fit_fcrr$var

  # 用原公式右側重建設計矩陣欄名
  rhs_formula <- reformulate(attr(terms(formula), "term.labels"))
  mm <- model.matrix(rhs_formula, data = data)

  # 拿掉 intercept（如果有）
  if ("(Intercept)" %in% colnames(mm)) {
    mm <- mm[, colnames(mm) != "(Intercept)", drop = FALSE]
  }

  coef_names <- colnames(mm)

  # 補上 beta names
  if (is.null(names(beta))) {
    if (length(beta) == length(coef_names)) {
      names(beta) <- coef_names
    } else {
      names(beta) <- paste0("V", seq_along(beta))
    }
  }

  # 補上 var dimnames
  if (!is.null(var)) {
    if (is.null(dimnames(var))) {
      if (nrow(var) == length(names(beta))) {
        dimnames(var) <- list(names(beta), names(beta))
      }
    }
    se <- sqrt(diag(var))
    z  <- beta / se
    p  <- 2 * pnorm(-abs(z))
  } else {
    var <- matrix(NA_real_, length(beta), length(beta))
    dimnames(var) <- list(names(beta), names(beta))
    se <- rep(NA_real_, length(beta))
    z  <- rep(NA_real_, length(beta))
    p  <- rep(NA_real_, length(beta))
  }

  loglik_null <- fit_fcrr$logLik.null
  loglik_fit  <- fit_fcrr$logLik

  fit_like <- list(
    coefficients = beta,
    var = var,
    loglik = c(loglik_null, loglik_fit),
    n = nrow(data),
    d = sum(status_vec == failcode, na.rm = TRUE),
    call = match.call(),
    method = "Fine-Gray (fastcmprsk::fastCrr)",
    coefficients2 = data.frame(
      coef = beta,
      `exp(coef)` = exp(beta),
      `se(coef)` = se,
      z = z,
      p = p,
      check.names = FALSE
    ),
    converged = isTRUE(fit_fcrr$converged),
    iter = fit_fcrr$iter,
    raw_fit = fit_fcrr
  )

  rownames(fit_like$coefficients2) <- names(beta)

  class(fit_like) <- "coxph"
  return(fit_like)
}

fastcrr_r <- function(formula,
                      data,
                      failcode = 1,
                      cencode = 0,
                      eps = 1e-06,
                      max.iter = 1000,
                      getBreslowJumps = FALSE,
                      standardize = FALSE,
                      variance = TRUE,
                      var.control = fastcmprsk::varianceControl(B = 100, useMultipleCores = TRUE),
                      returnDataFrame = FALSE,
                      ...) {

  data_res <- extract_cox_data(formula, data)

  rhs_labels <- attr(terms(formula), "term.labels")
  rhs_txt <- if (length(rhs_labels) == 0) "1" else paste(rhs_labels, collapse = " + ")

  lhs_txt <- sprintf(
    "fastcmprsk::Crisk(%s, %s, cencode = %s, failcode = %s)",
    names(data_res$time)[1] %||% all.vars(formula[[2]])[1],
    names(data_res$status)[1] %||% all.vars(formula[[2]])[2],
    cencode,
    failcode
  )

  fg_formula <- as.formula(paste(lhs_txt, "~", rhs_txt), env = environment(formula))

  model <- fastcmprsk::fastCrr(
    formula = fg_formula,
    data = data,
    eps = eps,
    max.iter = max.iter,
    getBreslowJumps = getBreslowJumps,
    standardize = standardize,
    variance = variance,
    var.control = var.control,
    returnDataFrame = returnDataFrame
  )

  res <- fastCrr_to_coxph_like(
    fit_fcrr = model,
    formula = formula,
    data = data,
    status_vec = data_res$status,
    failcode = failcode
  )

  return(res)
}

#`%||%` <- function(x, y) if (!is.null(x)) x else y

BIC_crr <- function(fit_like) {
  if (is.null(fit_like$loglik) || all(is.na(fit_like$loglik))) {
    stop("No loglik information")
  }

  loglik <- tail(fit_like$loglik, 1)
  n <- fit_like$n
  k <- length(fit_like$coefficients)


  BIC_value <- -2 * loglik + k * log(fit_like$d)

  out <- list(
    BIC = BIC_value,
    loglik = loglik,
    n = n,
    k = k,
    method = fit_like$method
  )

  class(out) <- "BIC_crr_like"
  return(BIC_value)
}

lrtest_crr <- function(fit_reduced, fit_full) {
  if (is.null(fit_full$loglik) || is.null(fit_reduced$loglik)) {
    stop("No loglik information")
  }

  loglik_full <- tail(fit_full$loglik, 1)
  loglik_reduced <- tail(fit_reduced$loglik, 1)

  k_full <- length(fit_full$coefficients)
  k_reduced <- length(fit_reduced$coefficients)

  LR <- 2 * (loglik_full - loglik_reduced)
  df_diff <- k_full - k_reduced
  p_value <- pchisq(LR, df = df_diff, lower.tail = FALSE)

  table <- data.frame(
    Model = c("Reduced", "Full"),
    Df = c(k_reduced, k_full),
    LogLik = c(loglik_reduced, loglik_full),
    Chisq = c(NA, LR),
    `Pr(>Chisq)` = c(NA, p_value),
    check.names = FALSE
  )

  attr(table, "heading") <- paste(
    "Likelihood ratio test for Fine-Gray (fastcmprsk::fastCrr)",
    "\nModel 1: Reduced",
    "\nModel 2: Full"
  )
  class(table) <- c("anova", "data.frame")

  return(table)
}

waldtest_crr <- function(fit_reduced, fit_full, test_n = NULL) {
  if (is.null(fit_full$coefficients) || is.null(fit_full$var))
    stop("Check fit_full")
  if (is.null(fit_reduced$coefficients))
    stop("Check fit_reduced")

  coef_full <- fit_full$coefficients
  coef_reduced <- fit_reduced$coefficients

  new_params <- setdiff(names(coef_full), names(coef_reduced))
  if (length(new_params) == 0) {
    stop("No new parameters to test")
  }

  beta_new <- coef_full[new_params]
  var_full <- fit_full$var
  var_new <- var_full[new_params, new_params, drop = FALSE]

  W <- as.numeric(t(beta_new) %*% ginv(var_new) %*% beta_new)
  df <- length(beta_new)
  p_value <- pchisq(W, df = df, lower.tail = FALSE)

  table <- data.frame(
    Model = c("Reduced", "Full"),
    Df = c(length(coef_reduced), length(coef_full)),
    Chisq = c(NA, W),
    `Pr(>Chisq)` = c(NA, p_value),
    check.names = FALSE
  )

  attr(table, "heading") <- paste(
    "Wald test (Chisq) for Fine-Gray (fastcmprsk::fastCrr)",
    "\nModel 1: Reduced",
    "\nModel 2: Full"
  )
  class(table) <- c("anova", "data.frame")

  return(table)
}

waldtest_single_crr <- function(fit_like, test_n = NULL) {
  if (is.null(fit_like$coefficients) || is.null(fit_like$var)) {
    stop("Check fit_like")
  }

  beta <- fit_like$coefficients
  var_beta <- fit_like$var

  W <- as.numeric(t(beta) %*% ginv(var_beta) %*% beta)
  df <- length(beta)
  p_value <- pchisq(W, df = df, lower.tail = FALSE)

  table <- data.frame(
    Model = "Full",
    Df = df,
    Chisq2 = W,
    `Pr(>Chisq)2` = p_value,
    check.names = FALSE
  )

  attr(table, "heading") <- paste0(
    "Wald test (Chisq) for Fine-Gray model (fastcmprsk::fastCrr)\n",
    "H0: all coefficients = 0"
  )
  class(table) <- c("anova", "data.frame")

  return(table)
}
