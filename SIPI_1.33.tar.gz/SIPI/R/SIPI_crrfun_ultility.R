
extract_cox_data = function(f, data_used) {

  surv_terms <- all.vars(f[[2]])   # time, status
  time <- data_used[[surv_terms[1]]]
  status <- data_used[[surv_terms[2]]]

  rhs_formula <- reformulate(attr(terms(f), "term.labels"))

  cov_matrix <- model.matrix(rhs_formula, data_used)[, -1, drop = FALSE]
  if (dim(cov_matrix)[2]==0){
    cov_matrix <- model.matrix(rhs_formula, data_used)[, 1, drop = FALSE]
    }

  list(
    time = time,
    status = status,
    cov = as.data.frame(cov_matrix)
  )
}

crr_to_coxph_like = function(fit_crr, data, covariates) {
  beta <- fit_crr$coef
  var <- fit_crr$var
  se <- sqrt(diag(var))
  z <- beta / se
  p <- 2 * pnorm(-abs(z))

  if (is.null(dimnames(var))) {
    dimnames(var) <- list(names(beta), names(beta))
  }

  fit_like <- list(
    coefficients = beta,
    var = var,
    loglik = c(NA, fit_crr$loglik),
    n = nrow(data),
    d = sum(data$event==1), ##1:events of interest
    call = match.call(),
    method = "Fine-Gray (cmprsk::crr)",
    coefficients2 = data.frame(
      coef = beta,
      exp_coef = exp(beta),
      se_coef = se,
      z = z,
      p = p,
      row.names = names(beta)
    )
  )

  class(fit_like) <- "coxph"
  return(fit_like)
}

BIC_crr = function(fit_like) {
  if (is.null(fit_like$loglik) || all(is.na(fit_like$loglik))) {
    stop("No loglik Information")
  }

  loglik <- tail(fit_like$loglik, 1)
  n <- fit_like$n
  k <- length(fit_like$coefficients)
  BIC_value <- -2 * loglik + k * log(fit_like$d) #n: standard BIC/d: BIC-CR

  out <- list(
    BIC = BIC_value,
    loglik = loglik,
    n = n,
    k = k,
    method = fit_like$method
  )

  class(out) <- "BIC_crr_like"
  return(BIC_value)
}

lrtest_crr = function(fit_reduced, fit_full) {
  if (is.null(fit_full$loglik) || is.null(fit_reduced$loglik)) {
    stop("No loglik Information")
  }

  loglik_full <- tail(fit_full$loglik, 1)
  loglik_reduced <- tail(fit_reduced$loglik, 1)

  k_full <- length(fit_full$coefficients)
  k_reduced <- length(fit_reduced$coefficients)

  LR <- 2 * (loglik_full - loglik_reduced)
  df_diff <- k_full - k_reduced
  p_value <- pchisq(LR, df = df_diff, lower.tail = FALSE)

  table <- data.frame(
    Model = c("Reduced", "Full"),
    Df = c(k_reduced, k_full),
    LogLik = c(loglik_reduced, loglik_full),
    Chisq = c(NA, LR),
    `Pr(>Chisq)` = c(NA, p_value),
    check.names = FALSE
  )

  attr(table, "heading") <- paste(
    "Likelihood ratio test for Fine-Gray (cmprsk::crr)",
    "\nModel 1: Reduced",
    "\nModel 2: Full"
  )
  class(table) <- c("anova", "data.frame")

  return(table)
}

waldtest_crr = function(fit_reduced, fit_full,test_n) {

  if (is.null(fit_full$coefficients) || is.null(fit_full$var))
    stop("Check")
  if (is.null(fit_reduced$coefficients))
    stop("Check")


  coef_full <- fit_full$coefficients
  coef_reduced <- fit_reduced$coefficients

  new_params <- setdiff(names(coef_full), names(coef_reduced))
  if (length(new_params) == 0) {
    stop("Check")
  }

  beta_new <- coef_full[new_params]
  var_full <- fit_full$var
  var_new <- var_full[new_params, new_params, drop = FALSE]

  W <- as.numeric(t(beta_new) %*% ginv(var_new) %*% beta_new)
  df <- length(beta_new)
  p_value <- pchisq(W, df = df, lower.tail = FALSE)

  table <- data.frame(
    Model = c("Reduced", "Full"),
    Df = c(length(coef_reduced), length(coef_full)),
    Chisq = c(NA, W),
    `Pr(>Chisq)` = c(NA, p_value),
    check.names = FALSE
  )

  attr(table, "heading") <- paste(
    "Wald test (Chisq) for Fine-Gray (cmprsk::crr)",
    "\nModel 1: Reduced",
    "\nModel 2: Full"
  )
  class(table) <- c("anova", "data.frame")

  return(table)
}

waldtest_single_crr = function(fit_like,test_n) {

  if (is.null(fit_like$coefficients) || is.null(fit_like$var)) {
    stop("Check")
  }

  beta <- fit_like$coefficients
  var_beta <- fit_like$var

  W <- as.numeric(t(beta) %*% ginv(var_beta) %*% beta)
  df <- length(beta)
  p_value <- pchisq(W, df = df, lower.tail = FALSE)

  table <- data.frame(
    Model = "Full",
    Df = df,
    Chisq2 = W,
    `Pr(>Chisq)2` = p_value,
    check.names = FALSE
  )

  attr(table, "heading") <- paste0(
    "Wald test (Chisq) for Fine-Gray model (cmprsk::crr)\n",
    "H0: all coefficients = 0"
  )
  class(table) <- c("anova", "data.frame")

  return(table)
}

crr_r = function(formula, data,...){

  data_res = extract_cox_data(formula,data)
  model = crr(data_res$time,data_res$status,data_res$cov)
  res = crr_to_coxph_like(model, data, data_res$cov)

  return(res)
}


crr = function (ftime, fstatus, cov1, cov2, tf, cengroup, failcode = 1,cencode = 0, subset, na.action = na.omit, gtol = 1e-06, maxiter = 10, init, variance = TRUE){
  call <- match.call()
  cov1.name <- deparse(substitute(cov1))
  cov1.vars <- cov2.vars <- NULL
  if (!missing(cov1)) {
    cov1.vars <- colnames(as.matrix(cov1))
  }
  cov2.name <- deparse(substitute(cov2))
  if (!missing(cov2)) {
    cov2.vars <- colnames(as.matrix(cov2))
  }
  d <- data.frame(ftime = ftime, fstatus = fstatus, cengroup = if (missing(cengroup))
    rep(1, length(fstatus))
    else cengroup)
  if (!missing(cov1)) {
    cov1 <- as.matrix(cov1)
    nc1 <- ncol(cov1)
    d <- cbind(d, cov1)
  }
  else {
    nc1 <- 0
  }
  if (!missing(cov2)) {
    cov2 <- as.matrix(cov2)
    nc2 <- ncol(cov2)
    d <- cbind(d, cov2)
  }
  else {
    nc2 <- 0
  }
  if (!missing(subset))
    d <- d[subset, ]
  tmp <- nrow(d)
  d <- na.action(d)
  nmis <- 0
  if (nrow(d) != tmp) {
    nmis <- tmp - nrow(d)
    cat(format(nmis), "cases omitted due to missing values\n")
  }
  d <- d[order(d$ftime), ]
  ftime <- d$ftime
  cenind <- ifelse(d$fstatus == cencode, 1, 0)
  fstatus <- ifelse(d$fstatus == failcode, 1, 2 * (1 - cenind))
  ucg <- sort(unique.default(d$cengroup))
  cengroup <- match(d$cengroup, ucg)
  ncg <- length(ucg)
  uuu <- matrix(0, nrow = ncg, ncol = length(ftime))
  for (k in 1:ncg) {
    u <- do.call("survfit", list(formula = Surv(ftime, cenind) ~
                                   1, data = data.frame(ftime, cenind, cengroup), subset = cengroup ==
                                   k))
    u <- approx(c(min(0, u$time) - 10 * .Machine$double.eps,
                  c(u$time, max(u$time) * (1 + 10 * .Machine$double.eps))),
                c(1, u$surv, 0), xout = ftime * (1 - 100 * .Machine$double.eps),
                method = "constant", f = 0, rule = 2)
    uuu[k, 1:length(u$y)] <- u$y
  }
  uft <- sort(unique(ftime[fstatus == 1]))
  ndf <- length(uft)
  if (nc2 == 0) {
    cov1 <- as.matrix(d[, (1:nc1) + 3])
    np <- nc1
    npt <- 0
    cov2 <- 0
    tfs <- 0
  }
  else if (nc1 == 0) {
    cov2 <- as.matrix(d[, (1:nc2) + 3 + nc1])
    npt <- np <- nc2
    cov1 <- 0
    tfs <- tf(uft)
  }
  else {
    cov1 <- as.matrix(d[, (1:nc1) + 3])
    cov2 <- as.matrix(d[, (1:nc2) + 3 + nc1])
    npt <- nc2
    np <- nc1 + nc2
    tfs <- tf(uft)
  }
  if (missing(init))
    b <- rep(0, np)
  else b <- init
  stepf <- 0.5
  for (ll in 0:maxiter) {
    z <- .Fortran("crrfsv", as.double(ftime), as.integer(fstatus),
                  as.integer(length(ftime)), as.double(cov1), as.integer(np -
                                                                           npt), as.integer(np), as.double(cov2), as.integer(npt),
                  as.double(tfs), as.integer(ndf), as.double(uuu),
                  as.integer(ncg), as.integer(cengroup), as.double(b),
                  double(1), double(np), double(np * np), double(np),
                  double(np), double(np * np), PACKAGE = "cmprsk")[15:17]
    if (max(abs(z[[2]]) * pmax(abs(b), 1)) < max(abs(z[[1]]),
                                                 1) * gtol) {
      converge <- TRUE
      break
    }
    if (ll == maxiter) {
      converge <- FALSE
      break
    }
    h <- z[[3]]
    dim(h) <- c(np, np)
    sc <- -ginv(h) %*% z[[2]]###  ##solve(h, z[[2]])
    bn <- b + sc
    fbn <- .Fortran("crrf", as.double(ftime), as.integer(fstatus),
                    as.integer(length(ftime)), as.double(cov1), as.integer(np -
                                                                             npt), as.integer(np), as.double(cov2), as.integer(npt),
                    as.double(tfs), as.integer(ndf), as.double(uuu),
                    as.integer(ncg), as.integer(cengroup), as.double(bn),
                    double(1), double(np), PACKAGE = "cmprsk")[[15]]
    i <- 0
    while (is.na(fbn) || fbn > z[[1]] + (1e-04) * sum(sc *
                                                      z[[2]])) {
      i <- i + 1
      sc <- sc * stepf
      bn <- b + sc
      fbn <- .Fortran("crrf", as.double(ftime), as.integer(fstatus),
                      as.integer(length(ftime)), as.double(cov1), as.integer(np -
                                                                               npt), as.integer(np), as.double(cov2), as.integer(npt),
                      as.double(tfs), as.integer(ndf), as.double(uuu),
                      as.integer(ncg), as.integer(cengroup), as.double(bn),
                      double(1), double(np), PACKAGE = "cmprsk")[[15]]
      if (i > 20)
        break
    }
    if (i > 20) {
      converge <- FALSE
      break
    }
    b <- c(bn)
  }
  if (variance) {
    v <- .Fortran("crrvv", as.double(ftime), as.integer(fstatus),
                  as.integer(length(ftime)), as.double(cov1), as.integer(np -
                                                                           npt), as.integer(np), as.double(cov2), as.integer(npt),
                  as.double(tfs), as.integer(ndf), as.double(uuu),
                  as.integer(ncg), as.integer(cengroup), as.double(b),
                  double(np * np), double(np * np), double(np * np),
                  double(length(ftime) * (np + 1)), double(np), double(np *
                                                                         ncg), double(2 * np), double(ncg * np), integer(ncg),
                  double(ncg * np), double(ncg), PACKAGE = "cmprsk")[15:16]
    dim(v[[2]]) <- dim(v[[1]]) <- c(np, np)
    h0 <- v[[1]]
    h <- ginv(v[[1]])###solve(v[[1]])
    v <- h %*% v[[2]] %*% t(h)
    r <- .Fortran("crrsr", as.double(ftime), as.integer(fstatus),
                  as.integer(length(ftime)), as.double(cov1), as.integer(np -
                                                                           npt), as.integer(np), as.double(cov2), as.integer(npt),
                  as.double(tfs), as.integer(ndf), as.double(uuu),
                  as.integer(ncg), as.integer(cengroup), as.double(b),
                  double(ndf * np), double(np), double(np), PACKAGE = "cmprsk")[[15]]
    r <- t(matrix(r, nrow = np))
  }
  else {
    v <- h <- h0 <- matrix(NA, np, np)
    r <- NULL
  }
  nobs <- length(ftime)
  b0 <- rep(0, length(b))
  fb0 <- .Fortran("crrf", as.double(ftime), as.integer(fstatus),
                  as.integer(length(ftime)), as.double(cov1), as.integer(np -
                                                                           npt), as.integer(np), as.double(cov2), as.integer(npt),
                  as.double(tfs), as.integer(ndf), as.double(uuu), as.integer(ncg),
                  as.integer(cengroup), as.double(b0), double(1), double(np),
                  PACKAGE = "cmprsk")[[15]]
  bj <- .Fortran("crrfit", as.double(ftime), as.integer(fstatus),
                 as.integer(length(ftime)), as.double(cov1), as.integer(np -
                                                                          npt), as.integer(np), as.double(cov2), as.integer(npt),
                 as.double(tfs), as.integer(ndf), as.double(uuu), as.integer(ncg),
                 as.integer(cengroup), as.double(b), double(ndf), double(np),
                 PACKAGE = "cmprsk")[[15]]
  if (nc1 > 0) {
    x1 <- paste(cov1.name, 1:nc1, sep = "")
    if (is.null(cov1.vars))
      cov1.vars <- x1
    else cov1.vars <- ifelse(cov1.vars == "", x1, cov1.vars)
  }
  if (nc2 > 0) {
    x1 <- paste(cov2.name, 1:nc2, sep = "")
    if (is.null(cov2.vars))
      cov2.vars <- x1
    else cov2.vars <- ifelse(cov2.vars == "", x1, cov2.vars)
    x1 <- paste("tf", 1:nc2, sep = "")
    x2 <- colnames(tfs)
    if (!is.null(x2))
      x1 <- ifelse(x2 == "", x1, x2)
    cov2.vars <- paste(cov2.vars, x1, sep = "*")
  }
  names(b) <- c(cov1.vars, cov2.vars)
  z <- list(coef = b, loglik = -z[[1]], score = -z[[2]], inf = h0,
            var = v, res = r, uftime = uft, bfitj = bj, tfs = as.matrix(tfs),
            converged = converge, call = call, n = nobs, n.missing = nmis,
            loglik.null = -fb0, invinf = h)
  class(z) <- "crr"
  z
}
