# edited 17jul26

##############################################################################
### PRS SCORE AND PERFORMANCE METRICS OF PRS SCORE
GIRS_RR3x3=function(Data,PairList,outcomeName,XNames=NULL,categXNames=NULL,idName=NULL,imputeScore="No"){

  ScoreType="RR3x3"
  
  if(is.null(idName)){
    id=(1:dim(Data)[1])
  }else {id=Data[,idName]}
  
  if(length(XNames)==0 | is.null(XNames)){
    X=NULL
  }else{
    X=Data[,XNames]
  }
  
  outcome=Data[,outcomeName]
  snplist=unique(c(as.character(PairList[,1]),as.character(PairList[,2])))
  num_pr=dim(PairList)[1]
  
  snpdata=Data[,snplist]
  snpdata[snpdata=="--"]=NA  
  snpdata[snpdata==""]=NA 
  
  score_res=PRS_int_wt=list(NA);k=1
  PRS_int_res=matrix(NA,ncol=num_pr,nrow=dim(Data)[1],byrow=T)
  
  for(j in 1:num_pr){ 
    snp1=snpdata[,paste0(PairList[j,1])]
    snp2=snpdata[,paste0(PairList[j,2])]
    if (imputeScore=="Yes"){score_res=risk_prevalence_IMPUT(snp1,snp2,outcome,ScoreType)   ## call function
    }else if (imputeScore=="No"){score_res=risk_prevalence_NOIMPUT(snp1,snp2,outcome,ScoreType)}   ## call function
    PRS_int_res[,j]=score_res[[1]]
    PRS_int_wt[[k]]=cbind.data.frame(Pair=paste0(PairList[j,1],"_",PairList[j,2]),score_res[[2]])   
    k=k+1
  }
  
  PRS_int_res1=data.frame(apply(PRS_int_res,2,as.numeric))
  dt_score=as.data.frame(outcome)
  names(dt_score)="outcome"
  dt_score[,paste0("Score_wt_",ScoreType)]=sc_risk=rowSums(PRS_int_res1,na.rm = F)
  dt_score[,paste0("Score_stan_wt_",ScoreType)]=(sc_risk-mean(sc_risk,na.rm=T))/sd(sc_risk,na.rm = T)
  
  res1=risk_performance_logit(sc_risk,X,categXNames,outcome,ScoreType,num_pr)   ## call function
  PRS_int_wt1=do.call("rbind",PRS_int_wt)
  
  names(PRS_int_res1)=paste0(as.character(PairList[,1]),"_",as.character(PairList[,2]),"_",ScoreType)
  dt_score1=cbind.data.frame(id,dt_score,PRS_int_res1)
  return(list(GIRSresult=res1,GIRSdata=dt_score1,GIRSweight=PRS_int_wt1))
  
}   # END of function GIRS_RR3x3

##############################################################################
#### PRS VALIDATION SCORE AND PERFORMANCE METRICS OF PRS VALIDATION SCORE USING WEIGHTS FROM PART-2
GIRS_RR3x3_VAL=function(Data,PairList,outcomeName,XNames=NULL,categXNames=NULL,idName=NULL,GIRSweight_VAL){
  
  ScoreType="RR3x3"
  
  if(is.null(idName)){
    id=(1:dim(Data)[1])
  }else {id=Data[,idName]}
  
  if(length(XNames)==0 | is.null(XNames)){
    X=NULL
  }else{
    X=Data[,XNames]
  }
  
  outcome=Data[,outcomeName]
  snplist=unique(c(as.character(PairList[,1]),as.character(PairList[,2])))
  num_pr=dim(PairList)[1]
  
  snpdata=Data[,snplist]
  snpdata[snpdata=="--"]=NA  
  snpdata[snpdata==""]=NA 
  
  score_res=list(NA);k=1
  PRS_int_res=matrix(NA,ncol=num_pr,nrow=dim(Data)[1],byrow=T)
  
  for(j in 1:num_pr){ 
    d_out=GIRSweight_VAL[which(GIRSweight_VAL$Pair==paste0(PairList[j,1],"_",PairList[j,2])),]
    
    snp1=snpdata[,paste0(PairList[j,1])];var1=ifelse(is.na(snp1),"_",as.character(snp1))
    snp2=snpdata[,paste0(PairList[j,2])];var2=ifelse(is.na(snp2),"_",as.character(snp2))
    pair1=data.frame(pair=paste0(var1,var2))
    risk_g=cbind.data.frame(pair_grp=as.character(d_out$pair_geno),risk_sc=as.character(d_out[,paste0("wt_",ScoreType)]))
    score_res=merge(pair1,risk_g,by.x="pair",by.y="pair_grp",all.x=T)
    score_res1=score_res[match(pair1$pair,score_res$pair,nomatch = 0),]
    PRS_int_res[,j]=score_res1[,2]
  }
  
  PRS_int_res1=data.frame(apply(PRS_int_res,2,as.numeric))
  dt_score=as.data.frame(outcome)
  names(dt_score)="outcome"
  dt_score[,paste0("Score_wt_",ScoreType)]=sc_risk=rowSums(PRS_int_res1,na.rm = F)
  dt_score[,paste0("Score_stan_wt_",ScoreType)]=(sc_risk-mean(sc_risk,na.rm=T))/sd(sc_risk,na.rm = T)
  
  res1=risk_performance_logit(sc_risk,X,categXNames,outcome,ScoreType,num_pr)   ## call function
  
  names(PRS_int_res1)=paste0(as.character(PairList[,1]),"_",as.character(PairList[,2]),"_",ScoreType)
  dt_score1=cbind.data.frame(id,dt_score,PRS_int_res1)
  return(list(GIRS_VALresult=res1,GIRS_VALdata=dt_score1))
  
}   # END of function GIRS_RR3x3_VAL

##################################### Other functions used in the above functions #######


##############################################################################
### GENERATION OF RR3x3 FOR EACH SNP PAIR WITH NO IMPUTATION
risk_prevalence_NOIMPUT=function(snp1,snp2,outcome,ScoreType){ 
  
  out_tot_pr=round(table(outcome)/sum(table(outcome)),4)[2]
  r1a=inheritance_A(snp1)[[1]]                                                      ## call function
  r1b=inheritance_A(snp1)[[2]]
  var1=r1b$snp_add_o;geno_1=r1a$geno_all
  r2a=inheritance_A(snp2)[[1]]
  r2b=inheritance_A(snp2)[[2]]
  var2=r2b$snp_add_o;geno_2=r2a$geno_all
  geno=c(as.character(geno_1),as.character(geno_2))
  out_tot_pr=round(table(outcome)/sum(table(outcome)),4)[2]
  pair1=ifelse(var1==0 & var2==0,"00",ifelse(var1==0 & var2==1,"01", ifelse(var1==0 & var2==2,"02",
              ifelse(var1==1 & var2==0,"10",ifelse(var1==1 & var2==1,"11",ifelse(var1==1 & var2==2,"12",
              ifelse(var1==2 & var2==0,"20",ifelse(var1==2 & var2==1,"21",ifelse(var1==2 & var2==2,"22",NA)))))))))
  pair1_tot=cbind.data.frame(table(pair1));colnames(pair1_tot)=c("pair","total")
  
  t1=as.matrix(table(pair1,outcome))
  t1=rbind(t1, margin.table(t1,2))
  t1=cbind(t1, margin.table(t1,1))
  l=length(t1[,1])
  tot=t1[,3]
  n=tot[l]
  out_per_1=round(t1[,2]/t1[,3],3)
  out_per=out_per_1[-which(names(out_per_1)=="")]
  tot_1=tot[-which(names(tot)=="")]
  
  d_out=cbind.data.frame(pair=names(out_per),out_per,tot_1)  
  g_1=unlist(strsplit(geno[1],"_"))
  g_2=unlist(strsplit(geno[2],"_"))
  r_n=d_out$pair
  r_geno=ifelse(r_n=="00",paste0(g_1[3],g_2[3]),ifelse(r_n=="01",paste0(g_1[3],g_2[2]),ifelse(r_n=="02",paste0(g_1[3],g_2[1]),
         ifelse(r_n=="10",paste0(g_1[2],g_2[3]),ifelse(r_n=="11",paste0(g_1[2],g_2[2]),ifelse(r_n=="12",paste0(g_1[2],g_2[1]),
         ifelse(r_n=="20",paste0(g_1[1],g_2[3]),ifelse(r_n=="21",paste0(g_1[1],g_2[2]),ifelse(r_n=="22",paste0(g_1[1],g_2[1]),
         ifelse(r_n=="0_",paste0(g_1[3],"_"),ifelse(r_n=="1_",paste0(g_1[2],"_"),ifelse(r_n=="2_",paste0(g_1[1],"_"),
         ifelse(r_n=="_0",paste0("_",g_2[3]),ifelse(r_n=="_1",paste0("_",g_2[2]),ifelse(r_n=="_2",paste0("_",g_2[1]),NA)))))))))))))))
  d_out$r_geno=r_geno
  d_out$p_geno=paste0(d_out$r_geno,"|",d_out$pair)
  colnames(d_out)=c("pair","out_pr","total","r_geno","p_geno")
  
  ## scores start
  
  if(ScoreType=="RR3x3"){
    sc_wt=round(d_out$out_pr/out_tot_pr,4)
    d_out[,paste0("wt_",ScoreType)]=round(sc_wt,3)
  }
  d_score_wt=cbind.data.frame(d_out$pair,d_out$r_geno,d_out$p_geno,d_out[,paste0("wt_",ScoreType)],d_out$total,d_out$out_pr)
  names(d_score_wt)=c("Score_pair","pair_geno","pair_geno_g",paste0("wt_",ScoreType),"total","out_pr")
  
  ########
  risk_g=d_score_wt[,paste0("wt_",ScoreType)]
  names(risk_g)=as.character(d_score_wt$Score_pair)
  risk_pair=ifelse(pair1=="00",risk_g[paste0("00")],ifelse(pair1=="01",risk_g[paste0("01")],ifelse(pair1=="02",risk_g[paste0("02")],
            ifelse(pair1=="10",risk_g[paste0("10")],ifelse(pair1=="11",risk_g[paste0("11")],ifelse(pair1=="12",risk_g[paste0("12")],
            ifelse(pair1=="20",risk_g[paste0("20")],ifelse(pair1=="21",risk_g[paste0("21")],ifelse(pair1=="22",risk_g[paste0("22")],NA)))))))))
  
  return(list(risk_pair,d_score_wt))
  
  
}   ##END OF risk_prevalence_NOIMPUT


##############################################################################
### GENERATION OF SCORE-RR,RP (BINARY OUTCOME) FOR EACH SNP PAIR WITH IMPUTATION
risk_prevalence_IMPUT=function(snp1,snp2,outcome,ScoreType){ 
  
  out_tot_pr=round(table(outcome)/sum(table(outcome)),4)[2]
  r1a=inheritance_A(snp1)[[1]]
  r1b=inheritance_A(snp1)[[2]]
  var1=r1b$snp_add_o;geno_1=r1a$geno_all
  r2a=inheritance_A(snp2)[[1]]
  r2b=inheritance_A(snp2)[[2]]
  var2=r2b$snp_add_o;geno_2=r2a$geno_all
  geno=c(as.character(geno_1),as.character(geno_2))
  pair1=ifelse(var1==0 & var2==0,"00",ifelse(var1==0 & var2==1,"01", ifelse(var1==0 & var2==2,"02",
                                                                            ifelse(var1==1 & var2==0,"10",ifelse(var1==1 & var2==1,"11",ifelse(var1==1 & var2==2,"12",
                                                                                                                                               ifelse(var1==2 & var2==0,"20",ifelse(var1==2 & var2==1,"21",ifelse(var1==2 & var2==2,"22",NA)))))))))
  pair1_2=ifelse(var1==0 & is.na(var2),"0_",ifelse(var1==1 & is.na(var2),"1_",ifelse(var1==2 & is.na(var2),"2_",
                                                                                     ifelse(is.na(var1) & var2==0,"_0",ifelse(is.na(var1) & var2==1,"_1",ifelse(is.na(var1) & var2==2,"_2",
                                                                                                                                                                ifelse(var1==0 & var2==0,"00",ifelse(var1==1 & var2==0,"10",ifelse(var1==2 & var2==0,"20",
                                                                                                                                                                                                                                   ifelse(var1==0 & var2==1,"01",ifelse(var1==1 & var2==1,"11",ifelse(var1==2 & var2==1,"21",
                                                                                                                                                                                                                                                                                                      ifelse(var1==0 & var2==2,"02",ifelse(var1==1 & var2==2,"12",ifelse(var1==2 & var2==2,"22",NA)))))))))))))))
  
  pair1_3=cbind.data.frame(table(pair1_2));colnames(pair1_3)=c("pair","total")
  
  
  t1=as.matrix(table(pair1,outcome))
  t1=rbind(t1, margin.table(t1,2))
  t1=cbind(t1, margin.table(t1,1))
  l=length(t1[,1])
  tot=t1[,3]
  n=tot[l]
  out_per_1=out_per=round(t1[,2]/t1[,3],4)
  pair1_1=pair1
  
  t_var1=as.matrix(table(var1,outcome))
  t_var1=cbind(t_var1, margin.table(t_var1,1))
  ot_pr_var1=round(t_var1[,2]/t_var1[,3],4)
  names(ot_pr_var1)=row.names(t_var1)=paste0(row.names(t_var1),"_")  #c("0_","1_","2_")
  
  t_var2=as.matrix(table(var2,outcome))
  t_var2=cbind(t_var2, margin.table(t_var2,1))
  ot_pr_var2=round(t_var2[,2]/t_var2[,3],4)
  names(ot_pr_var2)=row.names(t_var2)=paste0("_",row.names(t_var2))
  
  out_per_1=c(out_per,ot_pr_var1,ot_pr_var2)
  
  ind_var1=which(is.na(var2) & !is.na(var1))
  ind_var2=which(is.na(var1) & !is.na(var2))
  if (length(ind_var1)>0){
    for(k in 0:2){
      ind=which(is.na(var2) & var1==k)
      pair1_1[ind]=paste0(k,"_")
    }
  }
  if (length(ind_var2)>0){
    for(k in 0:2){   ## check
      ind=which(is.na(var1) & var2==k)
      pair1_1[ind]=paste0("_",k)
    }
  }
  out_per1_1=out_per_1[-which(names(out_per_1)=="")]
  
  out_per1_2=cbind.data.frame(pair=names(out_per1_1),out_per1_1)
  d_out=merge(out_per1_2,pair1_3,by="pair",all.y=T)
  
  g_1=unlist(strsplit(geno[1],"_"))
  g_2=unlist(strsplit(geno[2],"_"))
  r_n=d_out$pair
  r_geno=ifelse(r_n=="00",paste0(g_1[3],g_2[3]),ifelse(r_n=="01",paste0(g_1[3],g_2[2]),ifelse(r_n=="02",paste0(g_1[3],g_2[1]),
                                                                                              ifelse(r_n=="10",paste0(g_1[2],g_2[3]),ifelse(r_n=="11",paste0(g_1[2],g_2[2]),ifelse(r_n=="12",paste0(g_1[2],g_2[1]),
                                                                                                                                                                                   ifelse(r_n=="20",paste0(g_1[1],g_2[3]),ifelse(r_n=="21",paste0(g_1[1],g_2[2]),ifelse(r_n=="22",paste0(g_1[1],g_2[1]),
                                                                                                                                                                                                                                                                        ifelse(r_n=="0_",paste0(g_1[3],"_"),ifelse(r_n=="1_",paste0(g_1[2],"_"),ifelse(r_n=="2_",paste0(g_1[1],"_"),
                                                                                                                                                                                                                                                                                                                                                       ifelse(r_n=="_0",paste0("_",g_2[3]),ifelse(r_n=="_1",paste0("_",g_2[2]),ifelse(r_n=="_2",paste0("_",g_2[1]),NA)))))))))))))))
  d_out$r_geno=r_geno
  d_out$p_geno=paste0(d_out$r_geno,"|",d_out$pair)
  colnames(d_out)=c("pair","out_pr","total","r_geno","p_geno")
  
  ## scores start
  
  if(ScoreType=="RR3x3"){
    sc_wt=round(d_out$out_pr/out_tot_pr,4)
    d_out[,paste0("wt_",ScoreType)]=round(sc_wt,3)
  }
  d_score_wt=cbind.data.frame(d_out$pair,d_out$r_geno,d_out$p_geno,d_out[,paste0("wt_",ScoreType)],d_out$total,d_out$out_pr)
  names(d_score_wt)=c("Score_pair","pair_geno","pair_geno_g",paste0("wt_",ScoreType),"total","out_pr")
  
  ########
  risk_g=d_score_wt[,paste0("wt_",ScoreType)]
  names(risk_g)=as.character(d_score_wt$Score_pair)
  risk_pair=ifelse(pair1_2=="00",risk_g[paste0("00")],ifelse(pair1_2=="01",risk_g[paste0("01")],ifelse(pair1_2=="02",risk_g[paste0("02")],
                                                                                                       ifelse(pair1_2=="10",risk_g[paste0("10")],ifelse(pair1_2=="11",risk_g[paste0("11")],ifelse(pair1_2=="12",risk_g[paste0("12")],
                                                                                                                                                                                                  ifelse(pair1_2=="20",risk_g[paste0("20")],ifelse(pair1_2=="21",risk_g[paste0("21")],ifelse(pair1_2=="22",risk_g[paste0("22")],
                                                                                                                                                                                                                                                                                             ifelse(pair1_2=="0_",risk_g[paste0("0_")],ifelse(pair1_2=="1_",risk_g[paste0("1_")],ifelse(pair1_2=="2_",risk_g[paste0("2_")],
                                                                                                                                                                                                                                                                                                                                                                                        ifelse(pair1_2=="_0",risk_g[paste0("_0")],ifelse(pair1_2=="_1",risk_g[paste0("_1")],ifelse(pair1_2=="_2",risk_g[paste0("_2")],NA)))))))))))))))
  
  return(list(risk_pair,d_score_wt))
  
  
}    ##END OF risk_prevalence_IMPUT

##############################################################################
### Performance of logistic model
risk_performance_logit=function(sc_risk,X,categXNames=NULL,outcome,ScoreType,num_pr){
  
  sc_stan_risk=(sc_risk-mean(sc_risk,na.rm=T))/sd(sc_risk,na.rm = T)
  dt_score=cbind.data.frame(outcome,sc_risk,sc_stan_risk)
  colnames(dt_score)=c("outcome",paste0("Score_wt_",ScoreType),paste0("Score_stan_wt_",ScoreType))
  
  ## performance
  if (is.null(X)){
    dt_out1=cbind.data.frame(dt_score[,c('outcome',paste0("Score_stan_wt_",ScoreType))])
    fit1=glm(outcome~.,family="binomial",data=na.omit(dt_out1))
    t1=round((confint(fit1)),2)
    N_fit_stan=nobs(fit1)
    
    dt_out2=cbind.data.frame(dt_score[,c('outcome',paste0("Score_wt_",ScoreType))])
    fit2=glm(outcome~.,family="binomial",data=na.omit(dt_out2))
    t2=round((confint(fit2)),2)
    N_fit=nobs(fit2)
  }else {
    if (is.null(categXNames)){
      x_all=X
    }else {
      x_cat=data.frame(X[,as.character(categXNames)])
      x_cat1=data.frame(apply(x_cat,1,as.factor))
      colnames(x_cat1)=colnames(X)[(names(X) %in% as.character(categXNames))]
      x_ncat=data.frame(X[,!(names(X) %in% as.character(categXNames))])
      colnames(x_ncat)=colnames(X)[!(names(X) %in% as.character(categXNames))]
      x_all=cbind.data.frame(x_ncat,x_cat1)
    }
    
    dt_out1=cbind.data.frame(dt_score[,c('outcome',paste0("Score_stan_wt_",ScoreType))],x_all)
    fit1=glm(outcome~.,family="binomial",data=na.omit(dt_out1))
    t1=round((confint(fit1)),2)
    N_fit_stan=nobs(fit1)
    
    dt_out2=cbind.data.frame(dt_score[,c('outcome',paste0("Score_wt_",ScoreType))],x_all)
    fit2=glm(outcome~.,family="binomial",data=na.omit(dt_out2))
    t2=round((confint(fit2)),2)
    N_fit=nobs(fit2)
  }
  
  N_PRS=sum(!is.na(dt_score[,paste0("Score_wt_",ScoreType)]))
  res=data.frame(1:7)
  t=as.numeric(round((table(outcome)/sum(table(outcome))*100),2))[2]
  res[,paste0("Statistics")]=rbind("Outcome%","#SNPpairs", "N_PRS|N_Model","Mean|SD","Min|Max","OR(95% CI)","Pvalue")
  res[,paste0("Standardized Score ",ScoreType)]=rbind(paste0(t,"%"),num_pr,
                                                       paste0(N_PRS,"|",N_fit_stan),
                                                       paste0(round(mean(dt_score[,paste0("Score_stan_wt_",ScoreType)],na.rm=T),2),"|",
                                                              round(sd(dt_score[,paste0("Score_stan_wt_",ScoreType)],na.rm=T),2)),
                                                       paste0(round(min(dt_score[,paste0("Score_stan_wt_",ScoreType)],na.rm=T),3),"|",
                                                              round(max(dt_score[,paste0("Score_stan_wt_",ScoreType)],na.rm=T),3)),
                                                       paste0(round(exp(coef(summary(fit1))[2,1]),2),"(",round(exp(t1[2,1]),2),"-",round(exp(t1[2,2]),2),")"),
                                                       signif(coef(summary(fit1))[2,4], digits = 5))
  
  res[,paste0("Non-Standardized Score ",ScoreType)]=rbind(paste0(t,"%"),num_pr,paste0(N_PRS,"|",N_fit),
                                                           paste0(round(mean(dt_score[,paste0("Score_wt_",ScoreType)],na.rm=T),2),"|",
                                                                  round(sd(dt_score[,paste0("Score_wt_",ScoreType)],na.rm=T),2)),
                                                           paste0(round(min(dt_score[,paste0("Score_wt_",ScoreType)],na.rm=T),3),"|",
                                                                  round(max(dt_score[,paste0("Score_wt_",ScoreType)],na.rm=T),3)),
                                                           paste0(round(exp(coef(summary(fit2))[2,1]),2),"(",round(exp(t2[2,1]),2),"-",round(exp(t2[2,2]),2),")"),
                                                           signif(coef(summary(fit2))[2,4], digits = 5))
  
  acc_sc_stan=accuracy_score(dt_score[,paste0("Score_stan_wt_",ScoreType)],dt_score$outcome)
  acc_sc=accuracy_score(dt_score[,paste0("Score_wt_",ScoreType)],dt_score$outcome)
  acc_sc_all=cbind.data.frame("AUC",paste0(acc_sc_stan,"%"),paste0(acc_sc,"%"))
  colnames(acc_sc_all)=c(paste0("Statistics"),paste0("Standardized Score ",ScoreType),paste0("Non-Standardized Score ",ScoreType))
  rownames(acc_sc_all)=NULL
  
  res_out=rbind.data.frame(as.matrix(res[,-1]),as.matrix(acc_sc_all))
  return(res_out)
}  ##END OF risk_performance_logit

##############################################################################
### GENERATING accuracy for each score
accuracy_score=function(score,outcome){
  if (!require(pROC)) install.packages('pROC', repos = "http://cran.us.r-project.org")
  if (!require(caret)) install.packages('caret', repos = "http://cran.us.r-project.org")
  library(caret)
  library(pROC)
  
  auc_sc=0
  glm_prob=score
  outcome=outcome
  mat_pred=cbind.data.frame(measure=rownames(as.matrix(summary(glm_prob))),value=as.matrix(summary(glm_prob)))
  
  roc_obj=roc(outcome, glm_prob)
  auc_sc=round(auc(roc_obj)*100,2)
  return(auc_sc)
}  ##END OF accuracy_score


# to-edit- needs to be checked
##############################################################################
### GENERATING ADDITIVE FORM FOR EACH SNP
inheritance_A=function(snp_i,geno,snp_nam=NULL){
  #snp_i[which(snp_i=="--")]=NA  #sisnt work
  if (!require(stringr)) install.packages('stringr')
  library(stringr)
  
  freq_snp=table(snp_i)/length(snp_i)
  
  if((length(freq_snp)==4) || (nchar(names(freq_snp))[1]==0) || (str_detect(names(freq_snp)[1], "^[:alpha:]+$")==FALSE)){
    freq_snp1=freq_snp[2:length(freq_snp)]
  }else {freq_snp1=freq_snp}
  
  freq_snp_order=freq_snp1[order(freq_snp1)]
  geno_order=names(freq_snp_order)
  geno_order_a=strsplit(geno_order,"")
  
  num_geno=length(geno_order)
  nmiss=round((1-sum(freq_snp_order))*100,1)
  
  if(length(geno_order)==3){
    # geno_1=geno_order_a[[1]]
    # geno_2=geno_order_a[[2]]
    # geno_3=geno_order_a[[3]]
    g_1=geno_order_a[[1]]
    if(paste0(g_1[1])==paste0(g_1[2])){
      geno_1=g_1
      g_2=geno_order_a[[2]]
      if(paste0(g_2[1])==paste0(g_2[2])){
        geno_2=geno_order_a[[3]]
        geno_3=geno_order_a[[2]]
      }else{
        geno_2=geno_order_a[[2]]
        geno_3=geno_order_a[[3]]
      }
    }else{
      geno_1=geno_order_a[[2]]
      g_2=geno_order_a[[1]]
      if(paste0(g_2[1])==paste0(g_2[2])){
        geno_2=geno_order_a[[3]]
        geno_3=geno_order_a[[1]]
      }else{
        geno_2=geno_order_a[[1]]
        geno_3=geno_order_a[[3]]
      }
    }
  }else if(length(geno_order)==2){
    g_1=geno_order_a[[1]]
    if(paste0(g_1[1])==paste0(g_1[2])){
      geno_1=g_1
      g_2=geno_order_a[[2]]
      if(paste0(g_2[1])==paste0(g_2[2])){
        geno_2=geno_order_a[[2]]
        geno_3="_"
      }else{
        geno_2="_"
        geno_3=geno_order_a[[2]]
      }
    }else{
      geno_1="_"
      g_2=geno_order_a[[1]]
      if(paste0(g_2[1])==paste0(g_2[2])){
        geno_2=geno_order_a[[1]]
        geno_3=geno_order_a[[2]]
      }else{
        geno_2=geno_order_a[[2]]
        geno_3=geno_order_a[[1]]
      }
    }
  }
  
  if(length(geno_order)==1){   
    geno_index=which(geno %in% geno_order[1])
    if (geno_index %in% c(1)) {geno_min=geno_order[1];geno_major=geno_hetero="_"}
    if (geno_index %in% c(2,3)) {geno_hetero=geno_order[1];geno_min=geno_major="_"}
    if (geno_index %in% c(4)) {geno_major=geno_order[1];geno_min=geno_hetero="_"}
  }else if(length(geno_order) %in% c(3,2)){
  geno_min=ifelse(geno_1[1]==geno_1[2],paste0(geno_1,collapse = ""),NA)
  #will freq(major geno) always greater than freq(heterozygote) Ans : No
  geno_major=ifelse(geno_2[1]==geno_2[2],ifelse(is.na(geno_2),NA,paste0(geno_2,collapse =  "")),  ## change here
                    ifelse(is.na(geno_3),NA,paste0(geno_3,collapse =  "")))
  geno_hetero=ifelse(geno_2[1]==geno_2[2],ifelse(is.na(geno_3),NA,paste0(geno_3,collapse =  "")),
                     ifelse(is.na(geno_2),NA,paste0(geno_2,collapse =  "")))                  
  }else{print("Missing SNP data")}
  
  geno_all=paste0(geno_min,"_",geno_hetero,"_",geno_major)
  
  g_1=unlist(strsplit(ifelse(is.na(geno_min),"||",geno_min),""))
  g_2=unlist(strsplit(ifelse(is.na(geno_major),"||",geno_major),""))
  g_3=unlist(strsplit(ifelse(is.na(geno_hetero),"||",geno_hetero),""))
  
  if(length(geno_order)==3){
    min_allele=g_1[1]
    major_allele=g_2[1]
  }else if(length(geno_order)==2){
    if(geno_min=="_" | is.na(geno_min)){
      major_allele=g_2[1]
      min_allele=g_3[-which(g_3 %in% major_allele)]
    }else if(geno_major=="_" | is.na(geno_major)){
      min_allele=g_1[1]
      major_allele=g_3[-which(g_3 %in% min_allele)]
    }else if(geno_hetero=="_"){
      min_allele=g_1[1]
      major_allele=g_2[1]
    } 
  }else if(length(geno_order)==1){   
    min_allele=substr(geno[1],1,1)
    major_allele=substr(geno[4],1,1)
  }else{print("Missing SNP data")}
  
  freq_minor=sum(freq_snp_order[which(geno_order==geno_min)] , (0.5*freq_snp_order[which(geno_order==geno_hetero)]))
  freq_major=sum(freq_snp_order[which(geno_order==geno_major)] , (0.5*freq_snp_order[which(geno_order==geno_hetero)]))
  names(freq_major)=NULL
  names(freq_minor)=NULL
  
  snp_add_o=ifelse( ((snp_i==geno_min) & (!is.na((snp_i==geno_min)))),2,
                    ifelse( ((snp_i==geno_hetero) & (!is.na((snp_i==geno_hetero)))),1,
                            ifelse( ((snp_i==geno_major) & (!is.na((snp_i==geno_major)))),0,NA)))
  
  snp_dom_o=ifelse(snp_add_o %in% c(1,2),1,0)
  snp_rec_o=ifelse(snp_add_o %in% c(2),1,0)
  snp_add_r=2-snp_add_o
  snp_dom_r=1-snp_dom_o
  snp_rec_r=1-snp_rec_o
  
  if(length(snp_nam)==0){
    snp_stats=cbind.data.frame(geno_min,round(freq_minor*100,2),geno_all,min_allele,major_allele,num_geno,nmiss)
    colnames(snp_stats)=c("geno_minor","freq_minor","geno_all","minor_allele","major_allele","num_geno","missing")
    snp_dt=cbind.data.frame(snp_add_o,snp_dom_o,snp_rec_o,snp_add_r,snp_dom_r,snp_rec_r)
    colnames(snp_dt)=paste0("snp","_",c("add_o","dom_o","rec_o","add_r","dom_r","rec_r"))
  }else{
    snp_stats=cbind.data.frame(snp_nam,geno_min,round(freq_minor*100,2),geno_all,min_allele,major_allele,num_geno,nmiss)
    colnames(snp_stats)=c("snp_nam","geno_minor","freq_minor","geno_all","minor_allele","major_allele","num_geno","missing")
    snp_dt=cbind.data.frame(snp_add_o,snp_dom_o,snp_rec_o,snp_add_r,snp_dom_r,snp_rec_r)
    colnames(snp_dt)=paste0(snp_nam,"_",c("add_o","dom_o","rec_o","add_r","dom_r","rec_r"))
  }
  return(list(snp_stats,snp_dt))
}   ##END OF inheritance_A





























