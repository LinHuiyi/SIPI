###tryCatch
.waldtest_crr = function(model1,model2,test_n){
  options(warn=-1)
  result = tryCatch({
    waldtest_crr(model1,model2,test = test_n)
  }, error = function(w) {
    matrix(c(NA,NA),1,2,dimnames=list(c('a'),c('Chisq2','Pr(>Chisq)2')))
  })
  return(result)
}
.waldtest_single_crr = function(model1,test_n){
  options(warn=-1)
  result = tryCatch({
    waldtest_single_crr(model1,test = test_n)
  }, error = function(w) {
    matrix(c(NA,NA),1,2,dimnames=list(c('a'),c('Chisq2','Pr(>Chisq)2')))
  })
  return(result)
}
.lrtest_crr = function(model1,model2){
  options(warn=-1)
  result = tryCatch({
    lrtest_crr(model1,model2)
  }, error = function(w) {
    matrix(c(NA,NA),1,2,dimnames=list(c('a'),c('Chisq','Pr(>Chisq)2')))
  })
  return(result)
}

###function for 9 patterns
.SNP_Crr_int_9_c = function(Time,event,Adata,Bdata,X,TestType){
  X = data.frame(X)
  wholeABData = cbind(Time,event,Adata,Bdata,X)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }
  Time = wholeABData[,1]
  event = wholeABData[,2]
  Adata = wholeABData[,3]
  Bdata = wholeABData[,4]

  X = wholeABData[,5:dim(wholeABData)[2]]
  X = data.frame(X)

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  data_OAB = data.frame(Time=Time,event=event,Adata=Adata,Bdata=Bdata,
                        rAdata=rAdata,rBdata=rBdata)
  data_OABX = cbind(data_OAB,X)

  biccon = log(length(Time))
  lenX = dim(X)[2]

  X_names =  paste(colnames(X), collapse= "+")

  model1_for = as.formula(paste("Surv(Time,event)~Adata+Bdata+Adata:Bdata+",
                                X_names))
  model1 = fastcrr_r(model1_for,data=data_OABX)

  model2_for = as.formula(paste("Surv(Time,event)~Adata+Adata:Bdata+",
                                X_names))
  model2 = fastcrr_r(model2_for,data=data_OABX)

  model3_for = as.formula(paste("Surv(Time,event)~rAdata+rAdata:Bdata+",
                                X_names))
  model3 = fastcrr_r(model3_for,data=data_OABX)

  model4_for = as.formula(paste("Surv(Time,event)~Bdata+Adata:Bdata+",
                                X_names))
  model4 = fastcrr_r(model4_for,data=data_OABX)

  model5_for = as.formula(paste("Surv(Time,event)~rBdata+Adata:rBdata+",
                                X_names))
  model5 = fastcrr_r(model5_for,data=data_OABX)

  model6_for = as.formula(paste("Surv(Time,event)~Adata:Bdata+",
                                X_names))
  model6 = fastcrr_r(model6_for,data=data_OABX)

  model7_for = as.formula(paste("Surv(Time,event)~rAdata:Bdata+",
                                X_names))
  model7 = fastcrr_r(model7_for,data=data_OABX)

  model8_for = as.formula(paste("Surv(Time,event)~Adata:rBdata+",
                                X_names))
  model8 = fastcrr_r(model8_for,data=data_OABX)

  model9_for = as.formula(paste("Surv(Time,event)~rAdata:rBdata+",
                                X_names))
  model9 = fastcrr_r(model9_for,data=data_OABX)

  model0_for = as.formula(paste("Surv(Time,event)~",
                                X_names))
  model0 = fastcrr_r(model0_for,data=data_OABX)

  Res = matrix(numeric(0),9,5)

  if (is.na(model1$coefficients[length(model1$coefficients)])){
    Res[1,] = NA
  }else{
    coeff = model1$coefficients2[,c(1,3)]
    Res[1,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[1,5] = BIC_crr(model1)#extractAIC(model1,k=biccon)[2]
    model1_for = as.formula(paste("Surv(Time,event)~Adata+Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc = fastcrr_r(model1_for,data=data_OABX)
      anova = unlist(.waldtest_crr(modelc,model1,test="Chisq"))
    }else{
      modelc = fastcrr_r(model1_for,data=data_OABX)
      anova = unlist(.lrtest(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (is.na(model2$coefficients[length(model2$coefficients)])){
    Res[2,] = NA
  }else{
    coeff = model2$coefficients2[,c(1,3)]
    Res[2,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[2,5] = BIC_crr(model2)#extractAIC(model2,k=biccon)[2]
    model2_for = as.formula(paste("Surv(Time,event)~Adata+",
                                  X_names))
    if (is.waldtest){
      modelc = fastcrr_r(model2_for,data=data_OABX)
      anova = unlist(.waldtest_crr(modelc,model2,test="Chisq"))
    }else{
      modelc = coxph(model2_for,data=data_OABX)
      anova = unlist(.lrtest_crr(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (is.na(model3$coefficients[length(model3$coefficients)])){
    Res[3,] = NA
  }else{
    coeff = model3$coefficients2[,c(1,3)]
    Res[3,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[3,5] = BIC_crr(model3)#extractAIC(model3,k=biccon)[2]
    model3_for = as.formula(paste("Surv(Time,event)~rAdata+",
                                  X_names))
    if (is.waldtest){
      modelc = fastcrr_r(model3_for,data=data_OABX)
      anova = unlist(.waldtest_crr(modelc,model3,test="Chisq"))
    }else{
      modelc = fastcrr_r(model3_for,data=data_OABX)
      anova = unlist(.lrtest_crr(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (is.na(model4$coefficients[length(model4$coefficients)])){
    Res[4,] = NA
  }else{
    coeff = model4$coefficients2[,c(1,3)]
    Res[4,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[4,5] = BIC_crr(model4)#extractAIC(model4,k=biccon)[2]
    model4_for = as.formula(paste("Surv(Time,event)~Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc = fastcrr_r(model4_for,data=data_OABX)
      anova = unlist(.waldtest_crr(modelc,model4,test="Chisq"))
    }else{
      modelc = fastcrr_r(model4_for,data=data_OABX)
      anova = unlist(.lrtest_crr(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (is.na(model5$coefficients[length(model5$coefficients)])){
    Res[5,] = NA
  }else{
    coeff = model5$coefficients2[,c(1,3)]
    Res[5,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[5,5] = BIC_crr(model5)#extractAIC(model5,k=biccon)[2]
    model5_for = as.formula(paste("Surv(Time,event)~rBdata+",
                                  X_names))
    if (is.waldtest){
      modelc = fastcrr_r(model5_for,data=data_OABX)
      anova = unlist(.waldtest_crr(modelc,model5,test="Chisq"))
    }else{
      modelc = fastcrr_r(model5_for,data=data_OABX)
      anova = unlist(.lrtest_crr(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (is.na(model6$coefficients[length(model6$coefficients)])){
    Res[6,] = NA
  }else{
    coeff = model6$coefficients2[,c(1,3)]
    Res[6,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[6,5] = BIC_crr(model6)#extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_crr(model0,model6,test="Chisq"))
    }else{
      anova = unlist(.lrtest_crr(model0,model6))
    }
    Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (is.na(model7$coefficients[length(model7$coefficients)])){
    Res[7,] = NA
  }else{
    coeff = model7$coefficients2[,c(1,3)]
    Res[7,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[7,5] = BIC_crr(model7)#extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_crr(model0,model7,test="Chisq"))
    }else{
      anova = unlist(.lrtest_crr(model0,model7))
    }
    Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (is.na(model8$coefficients[length(model8$coefficients)])){
    Res[8,] = NA
  }else{
    coeff = model8$coefficients2[,c(1,3)]
    Res[8,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[8,5] = BIC_crr(model8)#extractAIC(model8,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova = unlist(.waldtest_crr(model0,model8,test="Chisq"))
    }else{
      anova = unlist(.lrtest_crr(model0,model8))
    }
    Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (is.na(model9$coefficients[length(model9$coefficients)])){
    Res[9,] = NA
  }else{
    coeff = model9$coefficients2[,c(1,3)]
    Res[9,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[9,5] = BIC_crr(model9)#extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_crr(model0,model9,test="Chisq"))
    }else{
      anova = unlist(.lrtest_crr(model0,model9))
    }
    Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }
  Res = apply(Res, 2, as.numeric)
  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}


.SNP_Crr_int_9_nc = function(Time,event,Adata,Bdata,TestType){
  wholeABData = cbind(Time,event,Adata,Bdata)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }
  Time = wholeABData[,1]
  event = wholeABData[,2]
  Adata = wholeABData[,3]
  Bdata = wholeABData[,4]
  wholeABData = NULL

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  data_OAB = data.frame(Time=Time,event=event,Adata=Adata,Bdata=Bdata,
                        rAdata=rAdata,rBdata=rBdata)
  model1_for = as.formula('Surv(Time,event)~Adata+Bdata+Adata:Bdata')
  model1 = fastcrr_r(model1_for, data_OAB)
  model2_for = as.formula('Surv(Time,event)~Adata+Adata:Bdata')
  model2 = fastcrr_r(model2_for, data_OAB)
  model3_for = as.formula('Surv(Time,event)~rAdata+rAdata:Bdata')
  model3 = fastcrr_r(model3_for, data_OAB)
  model4_for = as.formula('Surv(Time,event)~Bdata+Adata:Bdata')
  model4 = fastcrr_r(model4_for, data_OAB)
  model5_for = as.formula('Surv(Time,event)~rBdata+Adata:rBdata')
  model5 = fastcrr_r(model5_for, data_OAB)
  model6_for = as.formula('Surv(Time,event)~Adata:Bdata')
  model6 = fastcrr_r(model6_for, data_OAB)
  model7_for = as.formula('Surv(Time,event)~rAdata:Bdata')
  model7 = fastcrr_r(model7_for, data_OAB)
  model8_for = as.formula('Surv(Time,event)~Adata:rBdata')
  model8 = fastcrr_r(model8_for, data_OAB)
  model9_for = as.formula('Surv(Time,event)~rAdata:rBdata')
  model9 = fastcrr_r(model9_for, data_OAB)

  Res = matrix(numeric(0),9,5)
  if (dim(model1$coefficients2)[1]<3){#no intercept
    Res[1,] = NA
  }else{
    Res[1,1:2] = simplify2array(model1$coefficients2[3,c(1,3)])
    Res[1,5] = BIC_crr(model1)#extractAIC(model1,k=biccon)[2]
    if (is.waldtest){
      modelc_for = as.formula('Surv(Time,event)~Adata+Bdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.waldtest_crr(modelc,model1,test="Chisq"))
    }else{
      modelc_for = as.formula('Surv(Time,event)~Adata+Bdata')
      modelc = fastcrr_r(model1_for, data_OAB)
      anova = unlist(.lrtest_crr(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (dim(model2$coefficients2)[1]<2){
    Res[2,] = NA
  }else{
    Res[2,1:2] = simplify2array(model2$coefficients2[2,c(1,3)])
    Res[2,5] = BIC_crr(model2)#extractAIC(model2,k=biccon)[2]
    if (is.waldtest){
      modelc_for = as.formula('Surv(Time,event)~Adata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.waldtest_crr(modelc,model2,test="Chisq"))
    }else{
      modelc_for = as.formula('Surv(Time,event)~Adata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.lrtest_crr(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (dim(model3$coefficients2)[1]<2){
    Res[3,] = NA
  }else{
    Res[3,1:2] = simplify2array(model3$coefficients2[2,c(1,3)])
    Res[3,5] = BIC_crr(model3)#extractAIC(model3,k=biccon)[2]
    if (is.waldtest){
      modelc_for = as.formula('Surv(Time,event)~rAdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
    }else{
      modelc_for = as.formula('Surv(Time,event)~rAdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.lrtest(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (dim(model4$coefficients2)[1]<2){
    Res[4,] = NA
  }else{
    Res[4,1:2] =simplify2array(model4$coefficients2[2,c(1,3)])
    Res[4,5] = BIC_crr(model4)#extractAIC(model4,k=biccon)[2]

    if (is.waldtest){
      modelc_for = as.formula('Surv(Time,event)~Bdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.waldtest_crr(modelc,model4,test="Chisq"))
    }else{
      modelc_for = as.formula('Surv(Time,event)~Bdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.lrtest_crr(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (dim(model5$coefficients2)[1]<2){
    Res[5,] = NA
  }else{
    Res[5,1:2] = simplify2array(model5$coefficients2[2,c(1,3)])
    Res[5,5] = BIC_crr(model5)#extractAIC(model5,k=biccon)[2]
    if (is.waldtest){
      modelc_for = as.formula('Surv(Time,event)~rBdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
    }else{
      modelc_for = as.formula('Surv(Time,event)~rBdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.lrtest(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (dim(model6$coefficients2)[1]<1){
    Res[6,] = NA
  }else{
    Res[6,1:2] = simplify2array(model6$coefficients2[1,c(1,3)])
    Res[6,5] = BIC_crr(model6)#extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_single_crr(model6,test="Chisq"))
      Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    }else{
      Res[6,3:4] = NA
    }
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (dim(model7$coefficients2)[1]<1){
    Res[7,] = NA
  }else{
    Res[7,1:2] = simplify2array(model7$coefficients2[1,c(1,3)])
    Res[7,5] = BIC_crr(model7)#extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_single_crr(model7,test="Chisq"))
      Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    }else{
      Res[7,3:4] = NA
    }
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (dim(model8$coefficients2)[1]<1){
    Res[8,] = NA
  }else{
    Res[8,1:2] = simplify2array(model8$coefficients2[1,c(1,3)])
    Res[8,5] = BIC_crr(model8)#extractAIC(model8,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_single_crr(model8,test="Chisq"))
      Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    }else{
      Res[8,3:4] = NA
    }
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (dim(model9$coefficients2)[1]<1){
    Res[9,] = NA
  }else{
    Res[9,1:2] = simplify2array(model9$coefficients2[1,c(1,3)])
    Res[9,5] = BIC_crr(model9)#extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_single_crr(model9,test="Chisq"))
      Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    }else{
      Res[9,3:4] = NA
    }
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }
  Res = apply(Res, 2, as.numeric)
  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}


.SNP_Crr_int_45_r = function(Time,event,Domdata,Recdata,Condata,a,b,X,ZIM,TestType){
  DD = .SNP_Crr_int_9_1(Time,event,Domdata[,a],Domdata[,b],X,ZIM,TestType)
  DR = .SNP_Crr_int_9_1(Time,event,Domdata[,a],Recdata[,b],X,ZIM,TestType)
  RD = .SNP_Crr_int_9_1(Time,event,Recdata[,a],Domdata[,b],X,ZIM,TestType)
  RR = .SNP_Crr_int_9_1(Time,event,Recdata[,a],Recdata[,b],X,ZIM,TestType)
  AA = .SNP_Crr_int_9_1(Time,event,Condata[,a],Condata[,b],X,ZIM,TestType)
  Bic = c(DD[,5],DR[,5],RD[,5],RR[,5],AA[,5])
  if (all(is.na(Bic))){
    MinCp = MaxC = Minm = minB = minS = NA
  }else{
    m = which.min(Bic)
    mod = c("DD","DR","RD","RR","AA")[ceiling(m/9)]
    Minm = paste(mod,names(m),sep='_')
    MinCp = c(DD[,4],DR[,4],RD[,4],RR[,4],AA[,4])[m]
    MaxC = c(DD[,3],DR[,3],RD[,3],RR[,3],AA[,3])[m]
    minB = c(DD[,1],DR[,1],RD[,1],RR[,1],AA[,1])[m]
    minS= c(DD[,2],DR[,2],RD[,2],RR[,2],AA[,2])[m]

  }
  return(list(Bic=Bic,SM=Minm,Scv=MaxC,Scp=MinCp,minB=minB,minS=minS))
}


.SNP_Crr_int_9_1 = function(Time,event,Adata,Bdata,X,ZIM,TestType){
  if (length(X)==0){
    if (ZIM){
      return(.SNP_int_9_zeroinfl_nc_1(Outcome,Adata,Bdata,TestType,ModelType))
    }
    else{
      return(.SNP_Crr_int_9_nc_1(Time,event,Adata,Bdata,TestType))
    }
  }else{
    if (ZIM){
      return(.SNP_int_9_zeroinfl_1(Outcome,Adata,Bdata,X,TestType,ModelType))
    }else{
      return(.SNP_Crr_int_9_c_1(Time,event,Adata,Bdata,X,TestType))
    }
  }
}

#############
.SNP_Crr_int_9_c_1 = function(Time,event,Adata,Bdata,X,TestType){
  X = data.frame(X)
  wholeABData = cbind(Time,event,Adata,Bdata,X)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }

  Time = wholeABData[,1]
  event = wholeABData[,2]
  Adata = wholeABData[,3]
  Bdata = wholeABData[,4]
  X = wholeABData[,5:dim(wholeABData)[2]]
  X = data.frame(X)
  wholeABData = NULL

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  data_OAB = data.frame(Time=Time,event=event,Adata=Adata,Bdata=Bdata,
                        rAdata=rAdata,rBdata=rBdata)
  data_OABX = cbind(data_OAB,X)

  #data_OAB = NULL

  biccon = log(length(Time))
  lenX = dim(X)[2]

  X_names =  paste(colnames(X), collapse= "+")
  #rm(Outcome,Adata,Bdata,rAdata,rBdata,X,data_OAB)

  model1_for = as.formula(paste("Surv(Time,event)~Adata+Bdata+Adata:Bdata+",
                                X_names))
  model1 = fastcrr_r(model1_for,data=data_OABX)

  model2_for = as.formula(paste("Surv(Time,event)~Adata+Adata:Bdata+",
                                X_names))
  model2 = fastcrr_r(model2_for,data=data_OABX)

  model3_for = as.formula(paste("Surv(Time,event)~rAdata+rAdata:Bdata+",
                                X_names))
  model3 = fastcrr_r(model3_for,data=data_OABX)

  model4_for = as.formula(paste("Surv(Time,event)~Bdata+Adata:Bdata+",
                                X_names))
  model4 = fastcrr_r(model4_for,data=data_OABX)

  model5_for = as.formula(paste("Surv(Time,event)~rBdata+Adata:rBdata+",
                                X_names))
  model5 = fastcrr_r(model5_for,data=data_OABX)

  model6_for = as.formula(paste("Surv(Time,event)~Adata:Bdata+",
                                X_names))
  model6 = fastcrr_r(model6_for,data=data_OABX)

  model7_for = as.formula(paste("Surv(Time,event)~rAdata:Bdata+",
                                X_names))
  model7 = fastcrr_r(model7_for,data=data_OABX)

  model8_for = as.formula(paste("Surv(Time,event)~Adata:rBdata+",
                                X_names))
  model8 = fastcrr_r(model8_for,data=data_OABX)

  model9_for = as.formula(paste("Surv(Time,event)~rAdata:rBdata+",
                                X_names))
  model9 = fastcrr_r(model9_for,data=data_OABX)

  model0_for = as.formula(paste("Surv(Time,event)~",
                                X_names))
  model0 = fastcrr_r(model0_for,data=data_OABX)

  Res = matrix(numeric(0),9,5)

  if (is.na(model1$coefficients[length(model1$coefficients)])){
    Res[1,] = NA
  }else{
    coeff = model1$coefficients2[,c(1,3)]
    Res[1,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[1,5] = BIC_crr(model1)#extractAIC(model1,k=biccon)[2]
    model1_for = as.formula(paste("Surv(Time,event)~Adata+Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc = fastcrr_r(model1_for,data=data_OABX)
      anova = unlist(.waldtest_crr(modelc,model1,test="Chisq"))
    }else{
      modelc = fastcrr_r(model1_for,data=data_OABX)
      anova = unlist(.lrtest_crr(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (is.na(model2$coefficients[length(model2$coefficients)])){
    Res[2,] = NA
  }else{
    coeff = model2$coefficients2[,c(1,3)]
    Res[2,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[2,5] = BIC_crr(model2)# extractAIC(model2,k=biccon)[2]
    model2_for = as.formula(paste("Surv(Time,event)~Adata+",
                                  X_names))
    if (is.waldtest){
      modelc = fastcrr_r(model2_for,data=data_OABX)
      anova = unlist(.waldtest_crr(modelc,model2,test="Chisq"))
    }else{
      modelc = fastcrr_r(model2_for,data=data_OABX)
      anova = unlist(.lrtest_crr(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (is.na(model3$coefficients[length(model3$coefficients)])){
    Res[3,] = NA
  }else{
    coeff = model3$coefficients2[,c(1,3)]
    Res[3,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[3,5] = BIC_crr(model3)#extractAIC(model3,k=biccon)[2]
    model3_for = as.formula(paste("Surv(Time,event)~rAdata+",
                                  X_names))
    if (is.waldtest){
      modelc = fastcrr_r(model3_for,data=data_OABX)
      anova = unlist(.waldtest_crr(modelc,model3,test="Chisq"))
    }else{
      modelc = fastcrr_r(model3_for,data=data_OABX)
      anova = unlist(.lrtest_crr(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (is.na(model4$coefficients[length(model4$coefficients)])){
    Res[4,] = NA
  }else{
    coeff = model4$coefficients2[,c(1,3)]
    Res[4,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[4,5] = BIC_crr(model4)#extractAIC(model4,k=biccon)[2]
    model4_for = as.formula(paste("Surv(Time,event)~Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc = fastcrr_r(model4_for,data=data_OABX)
      anova = unlist(.waldtest_crr(modelc,model4,test="Chisq"))
    }else{
      modelc = fastcrr_r(model4_for,data=data_OABX)
      anova = unlist(.lrtest_crr(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (is.na(model5$coefficients[length(model5$coefficients)])){
    Res[5,] = NA
  }else{
    coeff = model5$coefficients2[,c(1,3)]
    Res[5,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[5,5] = BIC_crr(model5)#extractAIC(model5,k=biccon)[2]
    model5_for = as.formula(paste("Surv(Time,event)~rBdata+",
                                  X_names))
    if (is.waldtest){
      modelc = fastcrr_r(model5_for,data=data_OABX)
      anova = unlist(.waldtest_crr(modelc,model5,test="Chisq"))
    }else{
      modelc = fastcrr_r(model5_for,data=data_OABX)
      anova = unlist(.lrtest_crr(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (is.na(model6$coefficients[length(model6$coefficients)])){
    Res[6,] = NA
  }else{
    coeff = model6$coefficients2[,c(1,3)]
    Res[6,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[6,5] = BIC_crr(model6)#extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_crr(model0,model6,test="Chisq"))
    }else{
      anova = unlist(.lrtest_crr(model0,model6))
    }
    Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (is.na(model7$coefficients[length(model7$coefficients)])){
    Res[7,] = NA
  }else{
    coeff = model7$coefficients2[,c(1,3)]
    Res[7,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[7,5] = BIC_crr(model7)#extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_crr(model0,model7,test="Chisq"))
    }else{
      anova = unlist(.lrtest_crr(model0,model7))
    }
    Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (is.na(model8$coefficients[length(model8$coefficients)])){
    Res[8,] = NA
  }else{
    coeff = model8$coefficients2[,c(1,3)]
    Res[8,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[8,5] = BIC_crr(model8)#extractAIC(model8,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova = unlist(.waldtest_crr(model0,model8,test="Chisq"))
    }else{
      anova = unlist(.lrtest_crr(model0,model8))
    }
    Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (is.na(model9$coefficients[length(model9$coefficients)])){
    Res[9,] = NA
  }else{
    coeff = model9$coefficients2[,c(1,3)]
    Res[9,1:2] = simplify2array(coeff[dim(coeff)[1],])
    Res[9,5] = BIC_crr(model9)#extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_crr(model0,model9,test="Chisq"))
    }else{
      anova = unlist(.lrtest_crr(model0,model9))
    }
    Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }
  Res = apply(Res, 2, as.numeric)
  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}


.SNP_Crr_int_9_nc_1 = function(Time,event,Adata,Bdata,TestType){
  if (TestType=='WaldTest'){
    wholeABData = cbind(Time,event,Adata,Bdata)
    vdata = complete.cases(wholeABData)
    wholeABData = wholeABData[vdata,]
    min_sample = length(names(wholeABData)) + 3
    if (sum(vdata)<min_sample){
      Res = matrix(rep(NA,45),9,5)
      rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
      return(Res)
    }

    Time = wholeABData[,1]
    event = wholeABData[,2]
    Adata = wholeABData[,3]
    Bdata = wholeABData[,4]
    if (sum(Adata==2)>0){
      rAdata = abs(2-Adata)
      rBdata = abs(2-Bdata)
    }else{
      rAdata = 1-Adata
      rBdata = 1-Bdata
    }
    data_OAB = data.frame(Time=Time,event=event,Adata=Adata,Bdata=Bdata,
                          rAdata=rAdata,rBdata=rBdata)
    model1_for = as.formula('Surv(Time,event)~Adata+Bdata+Adata:Bdata')
    model1 = fastcrr_r(model1_for, data_OAB)
    model2_for = as.formula('Surv(Time,event)~Adata+Adata:Bdata')
    model2 = fastcrr_r(model2_for, data_OAB)
    model3_for = as.formula('Surv(Time,event)~rAdata+rAdata:Bdata')
    model3 = fastcrr_r(model3_for, data_OAB)
    model4_for = as.formula('Surv(Time,event)~Bdata+Adata:Bdata')
    model4 = fastcrr_r(model4_for, data_OAB)
    model5_for = as.formula('Surv(Time,event)~rBdata+Adata:rBdata')
    model5 = fastcrr_r(model5_for, data_OAB)
    model6_for = as.formula('Surv(Time,event)~Adata:Bdata')
    model6 = fastcrr_r(model6_for, data_OAB)
    model7_for = as.formula('Surv(Time,event)~rAdata:Bdata')
    model7 = fastcrr_r(model7_for, data_OAB)
    model8_for = as.formula('Surv(Time,event)~Adata:rBdata')
    model8 = fastcrr_r(model8_for, data_OAB)
    model9_for = as.formula('Surv(Time,event)~rAdata:rBdata')
    model9 = fastcrr_r(model9_for, data_OAB)

    biccon = log(length(Time))
    #model0 = coxph(Surv(Time, event)~1)

    Res = matrix(numeric(0),9,5)
    if (dim(model1$coefficients2)[1]<3){
      Res[1,] = NA
    }else{
      Res[1,1:2] = simplify2array(model1$coefficients2[3,c(1,3)])
      Res[1,5] = BIC_crr(model1)#extractAIC(model1,k=biccon)[2]
      modelc_for = as.formula('Surv(Time,event)~Adata+Bdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.waldtest_crr(modelc,model1,test="Chisq"))
      Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[1,]=NA}
    }
    if (dim(model2$coefficients2)[1]<2){
      Res[2,] = NA
    }else{
      Res[2,1:2] = simplify2array(model2$coefficients2[2,c(1,3)])
      Res[2,5] = BIC_crr(model2)#extractAIC(model2,k=biccon)[2]
      modelc_for = as.formula('Surv(Time,event)~Adata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.waldtest_crr(modelc,model2,test="Chisq"))
      Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[2,]=NA}
    }
    if (dim(model3$coefficients2)[1]<2){
      Res[3,] = NA
    }else{
      Res[3,1:2] = simplify2array(model3$coefficients2[2,c(1,3)])
      Res[3,5] = BIC_crr(model3)#extractAIC(model3,k=biccon)[2]
      modelc_for = as.formula('Surv(Time,event)~rAdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
      Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[3,]=NA}
    }
    if (dim(model4$coefficients2)[1]<2){
      Res[4,] = NA
    }else{
      Res[4,1:2] =simplify2array(model4$coefficients2[2,c(1,3)])
      Res[4,5] = BIC_crr(model4)#extractAIC(model4,k=biccon)[2]
      modelc_for = as.formula('Surv(Time,event)~Bdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.waldtest_crr(modelc,model4,test="Chisq"))
      Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[4,]=NA}
    }
    if (dim(model5$coefficients2)[1]<2){
      Res[5,] = NA
    }else{
      Res[5,1:2] = simplify2array(model5$coefficients2[2,c(1,3)])
      Res[5,5] = BIC_crr(model5)#extractAIC(model5,k=biccon)[2]
      modelc_for = as.formula('Surv(Time,event)~rBdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
      Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[5,]=NA}
    }
    if (dim(model6$coefficients2)[1]<1){
      Res[6,] = NA
    }else{
      Res[6,1:2] = simplify2array(model6$coefficients2[1,c(1,3)])
      Res[6,5] = BIC_crr(model6)#extractAIC(model6,k=biccon)[2]
      anova = unlist(.waldtest_single_crr(model6,test="Chisq"))
      Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[6,]=NA}
    }
    if (dim(model7$coefficients2)[1]<1){
      Res[7,] = NA
    }else{
      Res[7,1:2] = simplify2array(model7$coefficients2[1,c(1,3)])
      Res[7,5] = BIC_crr(model7)#extractAIC(model7,k=biccon)[2]
      anova = unlist(.waldtest_single_crr(model7,test="Chisq"))
      Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[7,]=NA}
    }
    if (dim(model8$coefficients2)[1]<1){
      Res[8,] = NA
    }else{
      Res[8,1:2] = simplify2array(model8$coefficients2[1,c(1,3)])
      Res[8,5] = BIC_crr(model8)#extractAIC(model8,k=biccon)[2]
      anova = unlist(.waldtest_single_crr(model8,test="Chisq"))
      Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[8,]=NA}
    }
    if (dim(model9$coefficients2)[1]<1){
      Res[9,] = NA
    }else{
      Res[9,1:2] = simplify2array(model9$coefficients2[1,c(1,3)])
      Res[9,5] = BIC_crr(model9)#extractAIC(model9,k=biccon)[2]
      anova = unlist(.waldtest_single_crr(model9,test="Chisq"))
      Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[9,]=NA}
    }
    Res = apply(Res, 2, as.numeric)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    wholeABData = cbind(Time,event,Adata,Bdata)
    vdata = complete.cases(wholeABData)
    wholeABData = wholeABData[vdata,]
    min_sample = length(names(wholeABData)) + 3
    if (sum(vdata)<min_sample){
      Res = matrix(rep(NA,45),9,5)
      rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
      return(Res)
    }
    Time = wholeABData[,1]
    event = wholeABData[,2]
    Adata = wholeABData[,3]
    Bdata = wholeABData[,4]
    wholeABData = NULL

    if (sum(Adata==2)>0){
      rAdata = abs(2-Adata)
      rBdata = abs(2-Bdata)
    }else{
      rAdata = 1-Adata
      rBdata = 1-Bdata
    }

    data_OAB = data.frame(Time=Time,event=event,Adata=Adata,Bdata=Bdata,
                          rAdata=rAdata,rBdata=rBdata)
    model1_for = as.formula('Surv(Time,event)~Adata+Bdata+Adata:Bdata')
    model1 = fastcrr_r(model1_for, data_OAB)
    model2_for = as.formula('Surv(Time,event)~Adata+Adata:Bdata')
    model2 = fastcrr_r(model2_for, data_OAB)
    model3_for = as.formula('Surv(Time,event)~rAdata+rAdata:Bdata')
    model3 = fastcrr_r(model3_for, data_OAB)
    model4_for = as.formula('Surv(Time,event)~Bdata+Adata:Bdata')
    model4 = fastcrr_r(model4_for, data_OAB)
    model5_for = as.formula('Surv(Time,event)~rBdata+Adata:rBdata')
    model5 = fastcrr_r(model5_for, data_OAB)
    model6_for = as.formula('Surv(Time,event)~Adata:Bdata')
    model6 = fastcrr_r(model6_for, data_OAB)
    model7_for = as.formula('Surv(Time,event)~rAdata:Bdata')
    model7 = fastcrr_r(model7_for, data_OAB)
    model8_for = as.formula('Surv(Time,event)~Adata:rBdata')
    model8 = fastcrr_r(model8_for, data_OAB)
    model9_for = as.formula('Surv(Time,event)~rAdata:rBdata')
    model9 = fastcrr_r(model9_for, data_OAB)
    biccon = log(length(Time))

    #model0 = coxph(Surv(Time, event)~1)
    Res = matrix(0,9,5)
    if (dim(model1$coefficients2)[1]<3){
      Res[1,] = NA
    }else{
      Res[1,1:2] = simplify2array(model1$coefficients2[3,c(1,3)])
      Res[1,5] = BIC_crr(model1)#extractAIC(model1,k=biccon)[2]
      modelc_for = as.formula('Surv(Time,event)~Adata+Bdata')
      modelc = fastcrr_r(model1_for, data_OAB)
      anova = unlist(.lrtest_crr(modelc,model1))
      Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[1,]=NA}
    }
    if (dim(model2$coefficients2)[1]<2){
      Res[2,] = NA
    }else{
      Res[2,1:2] = simplify2array(model2$coefficients2[2,c(1,3)])
      Res[2,5] = BIC_crr(model2)#extractAIC(model2,k=biccon)[2]
      modelc_for = as.formula('Surv(Time,event)~Adata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.lrtest_crr(modelc,model2))
      Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[2,]=NA}
    }
    if (dim(model3$coefficients2)[1]<2){
      Res[3,] = NA
    }else{
      Res[3,1:2] = simplify2array(model3$coefficients2[2,c(1,3)])
      Res[3,5] = BIC_crr(model3)#extractAIC(model3,k=biccon)[2]
      modelc_for = as.formula('Surv(Time,event)~rAdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.lrtest(modelc,model3))
      Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[3,]=NA}
    }
    if (dim(model4$coefficients2)[1]<2){
      Res[4,] = NA
    }else{
      Res[4,1:2] =simplify2array(model4$coefficients2[2,c(1,3)])
      Res[4,5] = BIC_crr(model4)#extractAIC(model4,k=biccon)[2]
      modelc_for = as.formula('Surv(Time,event)~Bdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.lrtest_crr(modelc,model4))
      Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[4,]=NA}
    }
    if (dim(model5$coefficients2)[1]<2){
      Res[5,] = NA
    }else{
      Res[5,1:2] = simplify2array(model5$coefficients2[2,c(1,3)])
      Res[5,5] = BIC_crr(model5)#extractAIC(model5,k=biccon)[2]
      modelc_for = as.formula('Surv(Time,event)~rBdata')
      modelc = fastcrr_r(modelc_for, data_OAB)
      anova = unlist(.lrtest(modelc,model5))
      Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[5,]=NA}
    }
    if (dim(model6$coefficients2)[1]<1){
      Res[6,] = NA
    }else{
      Res[6,1:2] = simplify2array(model6$coefficients2[1,c(1,3)])
      Res[6,5] = BIC_crr(model6)#extractAIC(model6,k=biccon)[2]
      Res[6,3:4] = NA
      if (is.na(anova["Chisq2"])){Res[6,]=NA}
    }
    if (dim(model7$coefficients2)[1]<1){
      Res[7,] = NA
    }else{
      Res[7,1:2] = simplify2array(model7$coefficients2[1,c(1,3)])
      Res[7,5] = BIC_crr(model7)#extractAIC(model7,k=biccon)[2]
      Res[7,3:4] = NA
      if (is.na(anova["Chisq2"])){Res[7,]=NA}
    }
    if (dim(model8$coefficients2)[1]<1){
      Res[8,] = NA
    }else{
      Res[8,1:2] = simplify2array(model8$coefficients2[1,c(1,3)])
      Res[8,5] = BIC_crr(model8)#extractAIC(model8,k=biccon)[2]
      Res[8,3:4] = NA
      if (is.na(anova["Chisq2"])){Res[8,]=NA}
    }
    if (dim(model9$coefficients2)[1]<1){
      Res[9,] = NA
    }else{
      Res[9,1:2] = simplify2array(model9$coefficients2[1,c(1,3)])
      Res[9,5] = BIC_crr(model9)#extractAIC(model9,k=biccon)[2]
      Res[9,3:4] = NA
      if (is.na(anova["Chisq2"])){Res[9,]=NA}
    }
    Res = apply(Res, 2, as.numeric)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}
####################

