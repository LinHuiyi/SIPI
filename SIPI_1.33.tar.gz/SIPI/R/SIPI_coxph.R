###tryCatch
.waldtest = function(model1,model2,test_n){
  options(warn=-1)
  result = tryCatch({
    waldtest(model1,model2,test = test_n)
  }, error = function(w) {
    matrix(c(NA,NA),1,2,dimnames=list(c('a'),c('Chisq','Pr(>Chisq)2')))
  })
  return(result)
}
.waldtest_single = function(model1,test_n){
  options(warn=-1)
  result = tryCatch({
    waldtest(model1,test = test_n)
  }, error = function(w) {
    matrix(c(NA,NA),1,2,dimnames=list(c('a'),c('Chisq','Pr(>Chisq)2')))
  })
  return(result)
}
.lrtest = function(model1,model2){
  options(warn=-1)
  result = tryCatch({
    lrtest(model1,model2)
  }, error = function(w) {
    matrix(c(NA,NA),1,2,dimnames=list(c('a'),c('Chisq','Pr(>Chisq)2')))
  })
  return(result)
}

###function for 9 patterns
.SNP_Cox_int_9_c = function(Time,event,Adata,Bdata,X,TestType){
  X = data.frame(X)
  wholeABData = cbind(Time,event,Adata,Bdata,X)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }
  Time = wholeABData[,1]
  event = wholeABData[,2]
  Adata = wholeABData[,3]
  Bdata = wholeABData[,4]

  X = wholeABData[,5:dim(wholeABData)[2]]
  X = data.frame(X)

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  data_OAB = data.frame(Time=Time,event=event,Adata=Adata,Bdata=Bdata,
                        rAdata=rAdata,rBdata=rBdata)
  data_OABX = cbind(data_OAB,X)

  biccon = log(length(Time))
  lenX = dim(X)[2]

  X_names =  paste(colnames(X), collapse= "+")

  model1_for = as.formula(paste("Surv(Time,event)~Adata+Bdata+Adata:Bdata+",
                                X_names))
  model1 = coxph(model1_for,data=data_OABX)

  model2_for = as.formula(paste("Surv(Time,event)~Adata+Adata:Bdata+",
                                X_names))
  model2 = coxph(model2_for,data=data_OABX)

  model3_for = as.formula(paste("Surv(Time,event)~rAdata+rAdata:Bdata+",
                                X_names))
  model3 = coxph(model3_for,data=data_OABX)

  model4_for = as.formula(paste("Surv(Time,event)~Bdata+Adata:Bdata+",
                                X_names))
  model4 = coxph(model4_for,data=data_OABX)

  model5_for = as.formula(paste("Surv(Time,event)~rBdata+Adata:rBdata+",
                                X_names))
  model5 = coxph(model5_for,data=data_OABX)

  model6_for = as.formula(paste("Surv(Time,event)~Adata:Bdata+",
                                X_names))
  model6 = coxph(model6_for,data=data_OABX)

  model7_for = as.formula(paste("Surv(Time,event)~rAdata:Bdata+",
                                X_names))
  model7 = coxph(model7_for,data=data_OABX)

  model8_for = as.formula(paste("Surv(Time,event)~Adata:rBdata+",
                                X_names))
  model8 = coxph(model8_for,data=data_OABX)

  model9_for = as.formula(paste("Surv(Time,event)~rAdata:rBdata+",
                                X_names))
  model9 = coxph(model9_for,data=data_OABX)

  model0_for = as.formula(paste("Surv(Time,event)~",
                                X_names))
  model0 = coxph(model0_for,data=data_OABX)

  Res = matrix(numeric(0),9,5)

  if (is.na(model1$coefficients[length(model1$coefficients)])){
    Res[1,] = NA
  }else{
    coeff = summary(model1)$coefficients[,c(1,3)]
    Res[1,1:2] = coeff[dim(coeff)[1],]
    Res[1,5] = BIC(model1)#extractAIC(model1,k=biccon)[2]
    model1_for = as.formula(paste("Surv(Time,event)~Adata+Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc =coxph(model1_for,data=data_OABX)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
    }else{
      modelc = coxph(model1_for,data=data_OABX)
      anova = unlist(.lrtest(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (is.na(model2$coefficients[length(model2$coefficients)])){
    Res[2,] = NA
  }else{
    coeff = summary(model2)$coefficients[,c(1,3)]
    Res[2,1:2] = coeff[dim(coeff)[1],]
    Res[2,5] = BIC(model2)#extractAIC(model2,k=biccon)[2]
    model2_for = as.formula(paste("Surv(Time,event)~Adata+",
                                  X_names))
    if (is.waldtest){
      modelc = coxph(model2_for,data=data_OABX)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
    }else{
      modelc = coxph(model2_for,data=data_OABX)
      anova = unlist(.lrtest(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (is.na(model3$coefficients[length(model3$coefficients)])){
    Res[3,] = NA
  }else{
    coeff = summary(model3)$coefficients[,c(1,3)]
    Res[3,1:2] = coeff[dim(coeff)[1],]
    Res[3,5] = BIC(model3)#extractAIC(model3,k=biccon)[2]
    model3_for = as.formula(paste("Surv(Time,event)~rAdata+",
                                  X_names))
    if (is.waldtest){
      modelc = coxph(model3_for,data=data_OABX)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
    }else{
      modelc = coxph(model3_for,data=data_OABX)
      anova = unlist(.lrtest(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (is.na(model4$coefficients[length(model4$coefficients)])){
    Res[4,] = NA
  }else{
    coeff = summary(model4)$coefficients[,c(1,3)]
    Res[4,1:2] = coeff[dim(coeff)[1],]
    Res[4,5] = BIC(model4)#extractAIC(model4,k=biccon)[2]
    model4_for = as.formula(paste("Surv(Time,event)~Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc = coxph(model4_for,data=data_OABX)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
    }else{
      modelc = coxph(model4_for,data=data_OABX)
      anova = unlist(.lrtest(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (is.na(model5$coefficients[length(model5$coefficients)])){
    Res[5,] = NA
  }else{
    coeff = summary(model5)$coefficients[,c(1,3)]
    Res[5,1:2] = coeff[dim(coeff)[1],]
    Res[5,5] = BIC(model5)#extractAIC(model5,k=biccon)[2]
    model5_for = as.formula(paste("Surv(Time,event)~rBdata+",
                                  X_names))
    if (is.waldtest){
      modelc = coxph(model5_for,data=data_OABX)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
    }else{
      modelc = coxph(model5_for,data=data_OABX)
      anova = unlist(.lrtest(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (is.na(model6$coefficients[length(model6$coefficients)])){
    Res[6,] = NA
  }else{
    coeff = summary(model6)$coefficients[,c(1,3)]
    Res[6,1:2] = coeff[dim(coeff)[1],]
    Res[6,5] = BIC(model6)#extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model6,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model6))
    }
    Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (is.na(model7$coefficients[length(model7$coefficients)])){
    Res[7,] = NA
  }else{
    coeff = summary(model7)$coefficients[,c(1,3)]
    Res[7,1:2] = coeff[dim(coeff)[1],]
    Res[7,5] = BIC(model7)#extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model7,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model7))
    }
    Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (is.na(model8$coefficients[length(model8$coefficients)])){
    Res[8,] = NA
  }else{
    coeff = summary(model8)$coefficients[,c(1,3)]
    Res[8,1:2] = coeff[dim(coeff)[1],]
    Res[8,5] = BIC(model8)#extractAIC(model8,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova = unlist(.waldtest(model0,model8,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model8))
    }
    Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (is.na(model9$coefficients[length(model9$coefficients)])){
    Res[9,] = NA
  }else{
    coeff = summary(model9)$coefficients[,c(1,3)]
    Res[9,1:2] = coeff[dim(coeff)[1],]
    Res[9,5] = BIC(model9)#extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model9,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model9))
    }
    Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }

  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}



.SNP_Cox_int_9_nc = function(Time,event,Adata,Bdata,TestType){
  wholeABData = cbind(Time,event,Adata,Bdata)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }
  Time = wholeABData[,1]
  event = wholeABData[,2]
  Adata = wholeABData[,3]
  Bdata = wholeABData[,4]
  wholeABData = NULL

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  model1 = coxph(Surv(Time,event)~Adata+Bdata+Adata:Bdata)
  model2 = coxph(Surv(Time,event)~Adata+Adata:Bdata)
  model3 = coxph(Surv(Time,event)~rAdata+rAdata:Bdata)
  model4 = coxph(Surv(Time,event)~Bdata+Adata:Bdata)
  model5 = coxph(Surv(Time,event)~rBdata+Adata:rBdata)
  model6 = coxph(Surv(Time,event)~Adata:Bdata)
  model7 = coxph(Surv(Time,event)~rAdata:Bdata)
  model8 = coxph(Surv(Time,event)~Adata:rBdata)
  model9 = coxph(Surv(Time,event)~rAdata:rBdata)

  biccon = log(length(Time))

  model0 = coxph(Surv(Time, event)~1)
  Res = matrix(numeric(0),9,5)
  if (dim(summary(model1)$coefficients)[1]<3){#no intercept
    Res[1,] = NA
  }else{
    Res[1,1:2] = summary(model1)$coefficients[3,c(1,3)]
    Res[1,5] = BIC(model1)#extractAIC(model1,k=biccon)[2]
    if (is.waldtest){
      modelc = coxph(Surv(Time,event)~Adata+Bdata)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
    }else{
      modelc = coxph(Surv(Time,event)~Adata+Bdata)
      anova = unlist(.lrtest(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (dim(summary(model2)$coefficients)[1]<2){
    Res[2,] = NA
  }else{
    Res[2,1:2] = summary(model2)$coefficients[2,c(1,3)]
    Res[2,5] = BIC(model2)#extractAIC(model2,k=biccon)[2]
    if (is.waldtest){
      modelc = coxph(Surv(Time,event)~Adata)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
    }else{
      modelc = coxph(Surv(Time,event)~Adata)
      anova = unlist(.lrtest(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (dim(summary(model3)$coefficients)[1]<2){
    Res[3,] = NA
  }else{
    Res[3,1:2] = summary(model3)$coefficients[2,c(1,3)]
    Res[3,5] = BIC(model3)#extractAIC(model3,k=biccon)[2]
    if (is.waldtest){
      modelc = coxph(Surv(Time,event)~rAdata)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
    }else{
      modelc = coxph(Surv(Time,event)~rAdata)
      anova = unlist(.lrtest(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (dim(summary(model4)$coefficients)[1]<2){
    Res[4,] = NA
  }else{
    Res[4,1:2] = summary(model4)$coefficients[2,c(1,3)]
    Res[4,5] = BIC(model4)#extractAIC(model4,k=biccon)[2]

    if (is.waldtest){
      modelc = coxph(Surv(Time,event)~Bdata)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
    }else{
      modelc = coxph(Surv(Time,event)~Bdata)
      anova = unlist(.lrtest(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (dim(summary(model5)$coefficients)[1]<2){
    Res[5,] = NA
  }else{
    Res[5,1:2] = summary(model5)$coefficients[2,c(1,3)]
    Res[5,5] = BIC(model5)#extractAIC(model5,k=biccon)[2]
    if (is.waldtest){
      modelc = coxph(Surv(Time,event)~rBdata)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
    }else{
      modelc = coxph(Surv(Time,event)~rBdata)
      anova = unlist(.lrtest(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (dim(summary(model6)$coefficients)[1]<1){
    Res[6,] = NA
  }else{
    Res[6,1:2] = summary(model6)$coefficients[1,c(1,3)]
    Res[6,5] = BIC(model6)#extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_single(model6,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model6))
    }
    Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (dim(summary(model7)$coefficients)[1]<1){
    Res[7,] = NA
  }else{
    Res[7,1:2] = summary(model7)$coefficients[1,c(1,3)]
    Res[7,5] = BIC(model7)#extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_single(model7,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model7))
    }
    Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (dim(summary(model8)$coefficients)[1]<1){
    Res[8,] = NA
  }else{
    Res[8,1:2] = summary(model8)$coefficients[1,c(1,3)]
    Res[8,5] = BIC(model8)#extractAIC(model8,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_single(model8,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model8))
    }
    Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (dim(summary(model9)$coefficients)[1]<1){
    Res[9,] = NA
  }else{
    Res[9,1:2] = summary(model9)$coefficients[1,c(1,3)]
    Res[9,5] = BIC(model9)#extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest_single(model9,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model9))
    }
    Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }

  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}

#

.SNP_Cox_int_45_r = function(Time,event,Domdata,Recdata,Condata,a,b,X,ZIM,TestType){
  DD = .SNP_Cox_int_9_1(Time,event,Domdata[,a],Domdata[,b],X,ZIM,TestType)
  DR = .SNP_Cox_int_9_1(Time,event,Domdata[,a],Recdata[,b],X,ZIM,TestType)
  RD = .SNP_Cox_int_9_1(Time,event,Recdata[,a],Domdata[,b],X,ZIM,TestType)
  RR = .SNP_Cox_int_9_1(Time,event,Recdata[,a],Recdata[,b],X,ZIM,TestType)
  AA = .SNP_Cox_int_9_1(Time,event,Condata[,a],Condata[,b],X,ZIM,TestType)
  Bic = c(DD[,5],DR[,5],RD[,5],RR[,5],AA[,5])
  if (all(is.na(Bic))){
    MinCp = MaxC = Minm = NA
  }else{
    m = which.min(Bic)
    mod = c("DD","DR","RD","RR","AA")[ceiling(m/9)]
    Minm = paste(mod,names(m),sep='_')
    MinCp = c(DD[,4],DR[,4],RD[,4],RR[,4],AA[,4])[m]
    MaxC = c(DD[,3],DR[,3],RD[,3],RR[,3],AA[,3])[m]
    minB = c(DD[,1],DR[,1],RD[,1],RR[,1],AA[,1])[m]
    minS= c(DD[,2],DR[,2],RD[,2],RR[,2],AA[,2])[m]

  }
  return(list(Bic=Bic,SM=Minm,Scv=MaxC,Scp=MinCp,minB=minB,minS=minS))
}

.SNP_Cox_int_9_1 = function(Time,event,Adata,Bdata,X,ZIM,TestType){
  if (length(X)==0){
    if (ZIM){
      return(.SNP_int_9_zeroinfl_nc_1(Outcome,Adata,Bdata,TestType,ModelType))
    }
    else{
      return(.SNP_Cox_int_9_nc_1(Time,event,Adata,Bdata,TestType))
    }
  }else{
    if (ZIM){
      return(.SNP_int_9_zeroinfl_1(Outcome,Adata,Bdata,X,TestType,ModelType))
    }else{
      return(.SNP_Cox_int_9_c_1(Time,event,Adata,Bdata,X,TestType))
    }
  }
}

#############
.SNP_Cox_int_9_c_1 = function(Time,event,Adata,Bdata,X,TestType){
  X = data.frame(X)
  wholeABData = cbind(Time,event,Adata,Bdata,X)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }

  Time = wholeABData[,1]
  event = wholeABData[,2]
  Adata = wholeABData[,3]
  Bdata = wholeABData[,4]
  X = wholeABData[,4:dim(wholeABData)[2]]
  X = data.frame(X)
  wholeABData = NULL

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  data_OAB = data.frame(Time=Time,event=event,Adata=Adata,Bdata=Bdata,
                        rAdata=rAdata,rBdata=rBdata)
  data_OABX = cbind(data_OAB,X)

  data_OAB = NULL

  biccon = log(length(Time))
  lenX = dim(X)[2]

  X_names =  paste(colnames(X), collapse= "+")
  rm(Outcome,Adata,Bdata,rAdata,rBdata,X,data_OAB)

  model1_for = as.formula(paste("Surv(Time,event)~Adata+Bdata+Adata:Bdata+",
                                X_names))
  model1 = coxph(model1_for,data=data_OABX)

  model2_for = as.formula(paste("Surv(Time,event)~Adata+Adata:Bdata+",
                                X_names))
  model2 = coxph(model2_for,data=data_OABX)

  model3_for = as.formula(paste("Surv(Time,event)~rAdata+rAdata:Bdata+",
                                X_names))
  model3 = coxph(model3_for,data=data_OABX)

  model4_for = as.formula(paste("Surv(Time,event)~Bdata+Adata:Bdata+",
                                X_names))
  model4 = coxph(model4_for,data=data_OABX)

  model5_for = as.formula(paste("Surv(Time,event)~rBdata+Adata:rBdata+",
                                X_names))
  model5 = coxph(model5_for,data=data_OABX)

  model6_for = as.formula(paste("Surv(Time,event)~Adata:Bdata+",
                                X_names))
  model6 = coxph(model6_for,data=data_OABX)

  model7_for = as.formula(paste("Surv(Time,event)~rAdata:Bdata+",
                                X_names))
  model7 = coxph(model7_for,data=data_OABX)

  model8_for = as.formula(paste("Surv(Time,event)~Adata:rBdata+",
                                X_names))
  model8 = coxph(model8_for,data=data_OABX)

  model9_for = as.formula(paste("Surv(Time,event)~rAdata:rBdata+",
                                X_names))
  model9 = coxph(model9_for,data=data_OABX)

  model0_for = as.formula(paste("Surv(Time,event)~",
                                X_names))
  model0 = coxph(model0_for,data=data_OABX)

  Res = matrix(numeric(0),9,5)

  if (is.na(model1$coefficients[length(model1$coefficients)])){
    Res[1,] = NA
  }else{
    coeff = summary(model1)$coefficients[,c(1,3)]
    Res[1,1:2] = coeff[dim(coeff)[1],]
    Res[1,5] = BIC(model1)#extractAIC(model1,k=biccon)[2]
    model1_for = as.formula(paste("Surv(Time,event)~Adata+Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc =coxph(model1_for,data=data_OABX)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
    }else{
      modelc = coxph(model1_for,data=data_OABX)
      anova = unlist(.lrtest(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (is.na(model2$coefficients[length(model2$coefficients)])){
    Res[2,] = NA
  }else{
    coeff = summary(model2)$coefficients[,c(1,3)]
    Res[2,1:2] = coeff[dim(coeff)[1],]
    Res[2,5] = BIC(model2)# extractAIC(model2,k=biccon)[2]
    model2_for = as.formula(paste("Surv(Time,event)~Adata+",
                                  X_names))
    if (is.waldtest){
      modelc = coxph(model2_for,data=data_OABX)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
    }else{
      modelc = coxph(model2_for,data=data_OABX)
      anova = unlist(.lrtest(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (is.na(model3$coefficients[length(model3$coefficients)])){
    Res[3,] = NA
  }else{
    coeff = summary(model3)$coefficients[,c(1,3)]
    Res[3,1:2] = coeff[dim(coeff)[1],]
    Res[3,5] = BIC(model3)#extractAIC(model3,k=biccon)[2]
    model3_for = as.formula(paste("Surv(Time,event)~rAdata+",
                                  X_names))
    if (is.waldtest){
      modelc = coxph(model3_for,data=data_OABX)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
    }else{
      modelc = coxph(model3_for,data=data_OABX)
      anova = unlist(.lrtest(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (is.na(model4$coefficients[length(model4$coefficients)])){
    Res[4,] = NA
  }else{
    coeff = summary(model4)$coefficients[,c(1,3)]
    Res[4,1:2] = coeff[dim(coeff)[1],]
    Res[4,5] = BIC(model4)#extractAIC(model4,k=biccon)[2]
    model4_for = as.formula(paste("Surv(Time,event)~Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc = coxph(model4_for,data=data_OABX)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
    }else{
      modelc = coxph(model4_for,data=data_OABX)
      anova = unlist(.lrtest(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (is.na(model5$coefficients[length(model5$coefficients)])){
    Res[5,] = NA
  }else{
    coeff = summary(model5)$coefficients[,c(1,3)]
    Res[5,1:2] = coeff[dim(coeff)[1],]
    Res[5,5] = BIC(model5)#extractAIC(model5,k=biccon)[2]
    model5_for = as.formula(paste("Surv(Time,event)~rBdata+",
                                  X_names))
    if (is.waldtest){
      modelc = coxph(model5_for,data=data_OABX)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
    }else{
      modelc = coxph(model5_for,data=data_OABX)
      anova = unlist(.lrtest(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (is.na(model6$coefficients[length(model6$coefficients)])){
    Res[6,] = NA
  }else{
    coeff = summary(model6)$coefficients[,c(1,3)]
    Res[6,1:2] = coeff[dim(coeff)[1],]
    Res[6,5] = BIC(model6)#extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model6,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model6))
    }
    Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (is.na(model7$coefficients[length(model7$coefficients)])){
    Res[7,] = NA
  }else{
    coeff = summary(model7)$coefficients[,c(1,3)]
    Res[7,1:2] = coeff[dim(coeff)[1],]
    Res[7,5] = BIC(model7)#extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model7,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model7))
    }
    Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (is.na(model8$coefficients[length(model8$coefficients)])){
    Res[8,] = NA
  }else{
    coeff = summary(model8)$coefficients[,c(1,3)]
    Res[8,1:2] = coeff[dim(coeff)[1],]
    Res[8,5] = BIC(model8)#extractAIC(model8,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova = unlist(.waldtest(model0,model8,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model8))
    }
    Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (is.na(model9$coefficients[length(model9$coefficients)])){
    Res[9,] = NA
  }else{
    coeff = summary(model9)$coefficients[,c(1,3)]
    Res[9,1:2] = coeff[dim(coeff)[1],]
    Res[9,5] = BIC(model9)#extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model9,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model9))
    }
    Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }

  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}


.SNP_Cox_int_9_nc_1 = function(Time,event,Adata,Bdata,TestType){
  if (TestType=='WaldTest'){
    wholeABData = cbind(Time,event,Adata,Bdata)
    vdata = complete.cases(wholeABData)
    wholeABData = wholeABData[vdata,]
    min_sample = length(names(wholeABData)) + 3
    if (sum(vdata)<min_sample){
      Res = matrix(rep(NA,45),9,5)
      rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
      return(Res)
    }

    Time = wholeABData[,1]
    event = wholeABData[,2]
    Adata = wholeABData[,3]
    Bdata = wholeABData[,4]
    if (sum(Adata==2)>0){
      rAdata = abs(2-Adata)
      rBdata = abs(2-Bdata)
    }else{
      rAdata = 1-Adata
      rBdata = 1-Bdata
    }
    model1 = coxph(Surv(Time, event)~Adata+Bdata+Adata:Bdata)
    model2 = coxph(Surv(Time, event)~Adata+Adata:Bdata)
    model3 = coxph(Surv(Time, event)~rAdata+rAdata:Bdata)
    model4 = coxph(Surv(Time, event)~Bdata+Adata:Bdata)
    model5 = coxph(Surv(Time, event)~rBdata+Adata:rBdata)
    model6 = coxph(Surv(Time, event)~Adata:Bdata)
    model7 = coxph(Surv(Time, event)~rAdata:Bdata)
    model8 = coxph(Surv(Time, event)~Adata:rBdata)
    model9 = coxph(Surv(Time, event)~rAdata:rBdata)

    biccon = log(length(Time))
    model0 = coxph(Surv(Time, event)~1)

    Res = matrix(numeric(0),9,5)
    if (dim(summary(model1)$coefficients)[1]<3){
      Res[1,] = NA
    }else{
      Res[1,1:2] = summary(model1)$coefficients[3,c(1,3)]
      Res[1,5] = BIC(model1)#extractAIC(model1,k=biccon)[2]
      modelc = coxph(Surv(Time,event)~Adata+Bdata)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
      Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[1,]=NA}
    }
    if (dim(summary(model2)$coefficients)[1]<2){
      Res[2,] = NA
    }else{
      Res[2,1:2] = summary(model2)$coefficients[2,c(1,3)]
      Res[2,5] = BIC(model2)#extractAIC(model2,k=biccon)[2]
      modelc = coxph(Surv(Time,event)~Adata)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
      Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[2,]=NA}
    }
    if (dim(summary(model3)$coefficients)[1]<2){
      Res[3,] = NA
    }else{
      Res[3,1:2] = summary(model3)$coefficients[2,c(1,3)]
      Res[3,5] = BIC(model3)#extractAIC(model3,k=biccon)[2]
      modelc = coxph(Surv(Time,event)~rAdata)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
      Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[3,]=NA}
    }
    if (dim(summary(model4)$coefficients)[1]<2){
      Res[4,] = NA
    }else{
      Res[4,1:2] = summary(model4)$coefficients[2,c(1,3)]
      Res[4,5] = BIC(model4)#extractAIC(model4,k=biccon)[2]
      modelc = coxph(Surv(Time,event)~Bdata)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
      Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[4,]=NA}
    }
    if (dim(summary(model5)$coefficients)[1]<2){
      Res[5,] = NA
    }else{
      Res[5,1:2] = summary(model5)$coefficients[2,c(1,3)]
      Res[5,5] = BIC(model5)#extractAIC(model5,k=biccon)[2]
      modelc = coxph(Surv(Time,event)~rBdata)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
      Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[5,]=NA}
    }
    if (dim(summary(model6)$coefficients)[1]<1){
      Res[6,] = NA
    }else{
      Res[6,1:2] = summary(model6)$coefficients[1,c(1,3)]
      Res[6,5] = BIC(model6)#extractAIC(model6,k=biccon)[2]
      anova = unlist(.waldtest(model0,model6,test="Chisq"))
      Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[6,]=NA}
    }
    if (dim(summary(model7)$coefficients)[1]<1){
      Res[7,] = NA
    }else{
      Res[7,1:2] = summary(model7)$coefficients[1,c(1,3)]
      Res[7,5] = BIC(model7)#extractAIC(model7,k=biccon)[2]
      anova = unlist(.waldtest(model0,model7,test="Chisq"))
      Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[7,]=NA}
    }
    if (dim(summary(model8)$coefficients)[1]<1){
      Res[8,] = NA
    }else{
      Res[8,1:2] = summary(model8)$coefficients[1,c(1,3)]
      Res[8,5] = BIC(model8)#extractAIC(model8,k=biccon)[2]
      anova = unlist(.waldtest(model0,model8,test="Chisq"))
      Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[8,]=NA}
    }
    if (dim(summary(model9)$coefficients)[1]<1){
      Res[9,] = NA
    }else{
      Res[9,1:2] = summary(model9)$coefficients[1,c(1,3)]
      Res[9,5] = BIC(model9)#extractAIC(model9,k=biccon)[2]
      anova = unlist(.waldtest(model0,model9,test="Chisq"))
      Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[9,]=NA}
    }
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    wholeABData = cbind(Time,event,Adata,Bdata)
    vdata = complete.cases(wholeABData)
    wholeABData = wholeABData[vdata,]
    min_sample = length(names(wholeABData)) + 3
    if (sum(vdata)<min_sample){
      Res = matrix(rep(NA,45),9,5)
      rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
      return(Res)
    }
    Time = wholeABData[,1]
    event = wholeABData[,2]
    Adata = wholeABData[,3]
    Bdata = wholeABData[,4]
    wholeABData = NULL

    if (sum(Adata==2)>0){
      rAdata = abs(2-Adata)
      rBdata = abs(2-Bdata)
    }else{
      rAdata = 1-Adata
      rBdata = 1-Bdata
    }

    model1 = coxph(Surv(Time, event)~Adata+Bdata+Adata:Bdata)
    model2 = coxph(Surv(Time, event)~Adata+Adata:Bdata)
    model3 = coxph(Surv(Time, event)~rAdata+rAdata:Bdata)
    model4 = coxph(Surv(Time, event)~Bdata+Adata:Bdata)
    model5 = coxph(Surv(Time, event)~rBdata+Adata:rBdata)
    model6 = coxph(Surv(Time, event)~Adata:Bdata)
    model7 = coxph(Surv(Time, event)~rAdata:Bdata)
    model8 = coxph(Surv(Time, event)~Adata:rBdata)
    model9 = coxph(Surv(Time, event)~rAdata:rBdata)

    biccon = log(length(Time))

    model0 = coxph(Surv(Time, event)~1)
    Res = matrix(0,9,5)
    if (dim(summary(model1)$coefficients)[1]<3){
      Res[1,] = NA
    }else{
      Res[1,1:2] = summary(model1)$coefficients[3,c(1,3)]
      Res[1,5] = BIC(model1)#extractAIC(model1,k=biccon)[2]
      modelc = coxph(Surv(Time,event)~Adata+Bdata)
      anova = unlist(.lrtest(modelc,model1))
      Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[1,]=NA}
    }
    if (dim(summary(model2)$coefficients)[1]<2){
      Res[2,] = NA
    }else{
      Res[2,1:2] = summary(model2)$coefficients[2,c(1,3)]
      Res[2,5] = BIC(model2)#extractAIC(model2,k=biccon)[2]
      modelc = coxph(Surv(Time,event)~Adata)
      anova = unlist(.lrtest(modelc,model2))
      Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[2,]=NA}
    }
    if (dim(summary(model3)$coefficients)[1]<2){
      Res[3,] = NA
    }else{
      Res[3,1:2] = summary(model3)$coefficients[2,c(1,3)]
      Res[3,5] = BIC(model3)#extractAIC(model3,k=biccon)[2]
      modelc = coxph(Surv(Time,event)~rAdata)
      anova = unlist(.lrtest(modelc,model3))
      Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[3,]=NA}
    }
    if (dim(summary(model4)$coefficients)[1]<2){
      Res[4,] = NA
    }else{
      Res[4,1:2] = summary(model4)$coefficients[2,c(1,3)]
      Res[4,5] = BIC(model4)#extractAIC(model4,k=biccon)[2]
      modelc = coxph(Surv(Time,event)~Bdata)
      anova = unlist(.lrtest(modelc,model4))
      Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[4,]=NA}
    }
    if (dim(summary(model5)$coefficients)[1]<2){
      Res[5,] = NA
    }else{
      Res[5,1:2] = summary(model5)$coefficients[2,c(1,3)]
      Res[5,5] = BIC(model5)#extractAIC(model5,k=biccon)[2]
      modelc = coxph(Surv(Time,event)~rBdata)
      anova = unlist(.lrtest(modelc,model5))
      Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[5,]=NA}
    }
    if (dim(summary(model6)$coefficients)[1]<1){
      Res[6,] = NA
    }else{
      Res[6,1:2] = summary(model6)$coefficients[1,c(1,3)]
      Res[6,5] = BIC(model6)#extractAIC(model6,k=biccon)[2]
      anova = unlist(.lrtest(model0,model6))
      Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[6,]=NA}
    }
    if (dim(summary(model7)$coefficients)[1]<1){
      Res[7,] = NA
    }else{
      Res[7,1:2] = summary(model7)$coefficients[1,c(1,3)]
      Res[7,5] = BIC(model7)#extractAIC(model7,k=biccon)[2]
      anova = unlist(.lrtest(model0,model7))
      Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[7,]=NA}
    }
    if (dim(summary(model8)$coefficients)[1]<1){
      Res[8,] = NA
    }else{
      Res[8,1:2] = summary(model8)$coefficients[1,c(1,3)]
      Res[8,5] = BIC(model8)#extractAIC(model8,k=biccon)[2]
      anova = unlist(.lrtest(model0,model8))
      Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[8,]=NA}
    }
    if (dim(summary(model9)$coefficients)[1]<1){
      Res[9,] = NA
    }else{
      Res[9,1:2] = summary(model9)$coefficients[1,c(1,3)]
      Res[9,5] = BIC(model9)#extractAIC(model9,k=biccon)[2]
      anova = unlist(.lrtest(model0,model9))
      Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[9,]=NA}
    }
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}
####################

