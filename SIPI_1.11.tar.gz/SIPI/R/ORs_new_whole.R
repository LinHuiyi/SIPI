OddsRatioEst_unit_pair_cal_ALL = function(Outcome,SNPdata,PairInfo1,PairInfo2,patt,X,ModelType = "binomial"){
  if (length(X)==0){
    OR = OddsRatioEst_unit_pair_cal(Outcome,SNPdata,PairInfo1,PairInfo2,patt,ModelType = "binomial")
    for (i in 1:length(OR)){
      rownames(OR[[i]]) = NULL
    }
    return(OR)
  }else{
    OR = OddsRatioEst_unit_pair_cal_X(Outcome,SNPdata,PairInfo1,PairInfo2,patt,X, ModelType = "binomial")
    for (i in 1:length(OR)){
      rownames(OR[[i]]) = NULL
    }
    return(OR)
  }
}

OddsRatioEst_unit_pair_cal_X = function(Outcome,SNPdata,PairInfo1,PairInfo2,patt,X,ModelType = "binomial"){
   results = list()
  if (length(patt)==1){
    sp = parsing_pattern(patt)
    results[['SNP1_SNP2']] = OddsRatioEst_pair_cal_X(Outcome,SNPdata,c(PairInfo1, PairInfo2),sp,X,ModelType = "binomial")

  }else{
    results = lapply(1:length(patt), function(i) OddsRatioEst_pair_cal_X(Outcome,SNPdata,c(PairInfo1[i], PairInfo2[i]),parsing_pattern(patt[i]),X,ModelType = "binomial"))
    names(results) = sapply(1:length(patt), function(i)  paste(PairInfo1[i],'_',PairInfo2[i],sep=""))
  }
  return(results)
}


OddsRatioEst_pair_cal_X = function (Outcome,SNPdata,PairInfo,patt_num,X,ModelType = "binomial"){
  SNPdata = SNPdata[,PairInfo]

  sData = setupSNP(SNPdata,1:2,sep="")
  Domdata = sapply(1:2, function(x) as.numeric(dominant(sData[,x]))) - 1
  Recdata = sapply(1:2, function(x) as.numeric(recessive(sData[,x]))) - 1
  Condata = sapply(1:2, function(x) as.numeric(additive(sData[,x])))
  if (patt_num[1]==1){
    Ors = .Ors_naa_X(Outcome,Domdata[,1],Domdata[,2],ModelType,patt_num[2],X)
    rownames(Ors) = paste("DD",rownames(Ors),sep='_')
  }else if (patt_num[1]==2){
    Ors = .Ors_naa_X(Outcome,Domdata[,1],Recdata[,2],ModelType,patt_num[2],X)
    rownames(Ors) = paste("DR",rownames(Ors),sep='_')
  }else if (patt_num[1]==3){
    Ors = .Ors_naa_X(Outcome,Recdata[,1],Domdata[,2],ModelType,patt_num[2],X)
    rownames(Ors) = paste("RD",rownames(Ors),sep='_')
  }else if (patt_num[1]==4){
    Ors = .Ors_naa_X(Outcome,Recdata[,1],Recdata[,2],ModelType,patt_num[2],X)
    rownames(Ors) = paste("RR",rownames(Ors),sep='_')
  }else{
    Ors = .Ors_aa_X(Outcome,Condata[,1],Condata[,2],ModelType,patt_num[2],X)
  }

  colnames(Ors) = c('OR','OR_CI_2.5%','OR_CI_97.5%','P-value')
  d = as.data.frame(Ors)
  Mode = rownames(d)
  #rownames(d) = ""
  Ors = cbind(Mode,d)
  return (OddsRatioEst=Ors)
}




.Ors_aa_X = function(Outcome,Adata,Bdata,ModelType,patt_num_2,X){
  X = data.frame(X)
  wholeABData = cbind(Outcome,Adata,Bdata,X)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  min_sample = length(names(wholeABData)) + 3
  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  X = wholeABData[,4:dim(wholeABData)[2]]
  X = data.frame(X)
  wholeABData = NULL
  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }


  Cdata = Adata*Bdata
  roCdata = rAdata*Bdata
  orCdata = Adata*rBdata
  rrCdata = rAdata*rBdata
  data_OF = data.frame(Outcome=Outcome,Adata=Adata,Bdata=Bdata,
                        Cdata=Cdata,roCdata=roCdata,orCdata=orCdata,rrCdata=rrCdata)
  data_OFX = cbind(data_OF,X)
  X_names =  paste(colnames(X), collapse= "+")

  if (patt_num_2==1){
    model1_for = as.formula(paste("Outcome~Adata+Bdata+Cdata+",
                                  X_names))
    model1 = glm(model1_for,data=data_OFX,family=ModelType)

    modelc_for = as.formula(paste("Outcome~Bdata+Cdata+",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv11 = unlist(.waldtest(modelc, model1, test="Chisq"))["Pr(>Chisq)2"]

    modelc_for = as.formula(paste("Outcome~Adata+Cdata+",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv12 = unlist(.waldtest(modelc, model1, test="Chisq"))["Pr(>Chisq)2"]

    modelc_for = as.formula(paste("Outcome~Adata+Bdata+",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv13 = unlist(.waldtest(modelc, model1, test="Chisq"))["Pr(>Chisq)2"]

    pv1=rbind(pv11,pv12,pv13)
    Res = cbind(cbind(coef(model1), suppressMessages(confint.default(model1)))[2:4,],pv1)
    rownames(Res) = c("AA_Full_1","AA_Full_2","AA_Full_12")
  }else if (patt_num_2==2){
    model1_for = as.formula(paste("Outcome~Adata+Cdata+",
                                  X_names))
    model2 = glm(model1_for,data=data_OFX,family=ModelType)

    modelc_for = as.formula(paste("Outcome~Cdata+",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv21 = unlist(.waldtest(modelc, model2, test="Chisq"))["Pr(>Chisq)2"]

    modelc_for = as.formula(paste("Outcome~Adata+",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv22 = unlist(.waldtest(modelc, model2, test="Chisq"))["Pr(>Chisq)2"]
    pv2=rbind(pv21,pv22)
    Res =cbind(cbind(coef(model2), suppressMessages(confint.default(model2)))[2:3,],pv2)
    rownames(Res) =c("AA_M1_int_o1_1","AA_M1_int_o1_12")
  }else if (patt_num_2==3){
    model1_for = as.formula(paste("Outcome~rAdata+roCdata+",
                                  X_names))
    model3 = glm(model1_for,data=data_OFX,family=ModelType)

    modelc_for = as.formula(paste("Outcome~roCdata+",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv31 = unlist(.waldtest(modelc, model3, test="Chisq"))["Pr(>Chisq)2"]

    modelc_for = as.formula(paste("Outcome~rAdata+",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv32 = unlist(.waldtest(modelc, model3, test="Chisq"))["Pr(>Chisq)2"]
    pv3 = rbind(pv31,pv32)
    Res = cbind(cbind(coef(model3), suppressMessages(confint.default(model3)))[2:3,],pv3)
    rownames(Res) =c("AA_M1_int_r1_1","AA_M1_int_r1_12")
  }else if (patt_num_2==4){
    model1_for = as.formula(paste("Outcome~Bdata+Cdata+",
                                  X_names))
    model4 = glm(model1_for,data=data_OFX,family=ModelType)

    modelc_for = as.formula(paste("Outcome~Cdata+",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv41 = unlist(.waldtest(modelc, model4, test="Chisq"))["Pr(>Chisq)2"]
    modelc_for = as.formula(paste("Outcome~Bdata+",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv42 = unlist(.waldtest(modelc, model4, test="Chisq"))["Pr(>Chisq)2"]
    pv4 = rbind(pv41,pv42)
    Res = cbind(cbind(coef(model4), suppressMessages(confint.default(model4)))[2:3,],pv4)
    rownames(Res) =c("AA_M2_int_o2_2","AA_M2_int_o2_12")
  }else if (patt_num_2==5){
    model1_for = as.formula(paste("Outcome~rBdata+orCdata+",
                                  X_names))
    model5 = glm(model1_for,data=data_OFX,family=ModelType)

    modelc_for = as.formula(paste("Outcome~orCdata+",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv51 = unlist(.waldtest(modelc, model5, test="Chisq"))["Pr(>Chisq)2"]

    modelc_for = as.formula(paste("Outcome~rBdata+",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv52 = unlist(.waldtest(modelc, model5, test="Chisq"))["Pr(>Chisq)2"]
    pv5 = rbind(pv51,pv52)
    Res = cbind(cbind(coef(model5), suppressMessages(confint.default(model5)))[2:3,],pv5)
    rownames(Res) =c("AA_M2_int_r2_2","AA_M2_int_r2_12")
  }else if (patt_num_2==6){
    model1_for = as.formula(paste("Outcome~Cdata+",
                                  X_names))
    model6 = glm(model1_for,data=data_OFX,family=ModelType)
    modelc_for = as.formula(paste("Outcome~",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv6 = unlist(.waldtest(modelc, model6, test="Chisq"))["Pr(>Chisq)2"]
    Res = c(cbind(coef(model6), suppressMessages(confint.default(model6)))[2,],pv6)
    Res = matrix(Res,1)
    rownames(Res) =c("AA_int_oo_12")
  }else if (patt_num_2==8){
    model1_for = as.formula(paste("Outcome~orCdata+",
                                  X_names))
    model8 = glm(model1_for,data=data_OFX,family=ModelType)

    modelc_for = as.formula(paste("Outcome~",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv8 = unlist(.waldtest(modelc, model8, test="Chisq"))["Pr(>Chisq)2"]
    Res = c(cbind(coef(model8), suppressMessages(confint.default(model8)))[2,],pv8)
    Res = matrix(Res,1)
    rownames(Res) =c("AA_int_or_12")
  }else if (patt_num_2==7){
    model1_for = as.formula(paste("Outcome~roCdata+",
                                  X_names))
    model7 = glm(model1_for,data=data_OFX,family=ModelType)
    modelc_for = as.formula(paste("Outcome~",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv7 = unlist(.waldtest(modelc, model7, test="Chisq"))["Pr(>Chisq)2"]
    Res = c(cbind(coef(model7), suppressMessages(confint.default(model7)))[2,],pv7)
    Res = matrix(Res,1)
    rownames(Res) =c("AA_int_ro_12")
  }else{
    model1_for = as.formula(paste("Outcome~rrCdata+",
                                  X_names))
    model9 = glm(model1_for,data=data_OFX,family=ModelType)
    modelc_for = as.formula(paste("Outcome~",
                                  X_names))
    modelc = glm(modelc_for,data=data_OFX,family=ModelType)
    pv9 = unlist(.waldtest(modelc, model9, test="Chisq"))["Pr(>Chisq)2"]
    Res = c(cbind(coef(model9), suppressMessages(confint.default(model9)))[2,],pv9)
    Res = matrix(Res,1)
    rownames(Res) =c("AA_int_rr_12")
  }
  Res[,1:3] = exp(Res[,1:3])
  return(Res)
}


.Ors_naa_X = function(Outcome,Adata,Bdata,ModelType,patt_num_2,X){
  X = data.frame(X)
  wholeABData = cbind(Outcome,Adata,Bdata,X)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  min_sample = length(names(wholeABData)) + 3
  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  X = wholeABData[,4:dim(wholeABData)[2]]
  X = data.frame(X)
  wholeABData = NULL
  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  if (patt_num_2==1){
    #1
    a = c()
    for (i in 1: length(Adata)){
      if (Adata[i]==0 & Bdata[i]==0){
        a = c(a, 0)
      }else if (Adata[i]==1 & Bdata[i]==0){
        a = c(a, 1)
      }else if (Adata[i]==0 & Bdata[i]==1){
        a = c(a, 2)
      }else{
        a = c(a, 3)}
    }
    if (sum(a==1)>0){
      b = ((a==0) | (a==1))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model11 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model11, test="Chisq"))["Pr(>Chisq)2"]
      m11 = cbind(coef(model11), suppressMessages(confint.default(model11)),pv)[2,]
    }else{
      m11=c(NA, NA, NA, NA)
    }
    if (sum(a==2)>0){
      b = ((a==0) | (a==2))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model12 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model12, test="Chisq"))["Pr(>Chisq)2"]
      m12 = cbind(coef(model12), suppressMessages(confint.default(model12)),pv)[2,]
    }else{
      m12 = c(NA, NA, NA, NA)
    }
    if (sum(a==3)>0){
      b = ((a==0) | (a==3))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model13 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model13, test="Chisq"))["Pr(>Chisq)2"]
      m13 = cbind(coef(model13), suppressMessages(confint.default(model13)),pv)[2,]
    }else{
      m13 = c(NA, NA, NA, NA)
    }
    Res = rbind(m11,m12,m13)
    rownames(Res) = c("Full_1vs0","Full_2vs0","Full_3vs0")
  }else if (patt_num_2==2){
    #2
    a = c()
    for (i in 1: length(Adata)){
      if (Adata[i]==0 & Bdata[i]==0){
        a = c(a, 0)
      }else if (Adata[i]==1 & Bdata[i]==0){
        a = c(a, 1)
      }else if (Adata[i]==0 & Bdata[i]==1){
        a = c(a, 0)
      }else{
        a = c(a, 2)}
    }

    if (sum(a==1)>0){
      b = ((a==0) | (a==1))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model21 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model21, test="Chisq"))["Pr(>Chisq)2"]
      m21 = cbind(coef(model21), suppressMessages(confint.default(model21)),pv)[2,]
    }else{
      m21 = c(NA, NA, NA, NA)
    }
    if (sum(a==2)>0){
      b = ((a==0) | (a==2))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model22 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model22, test="Chisq"))["Pr(>Chisq)2"]
      m22 = cbind(coef(model22), suppressMessages(confint.default(model22)),pv)[2,]
    }else{
      m22 = c(NA, NA, NA, NA)
    }
    Res = rbind(m21,m22)
    rownames(Res) = c("M1_int_o1_1vs0","M1_int_o1_2vs0")
  }else if (patt_num_2==3){
    #3
    a = c()
    for (i in 1: length(rAdata)){
      if (rAdata[i]==0 & Bdata[i]==0){
        a = c(a, 0)
      }else if (rAdata[i]==0 & Bdata[i]==1){
        a = c(a, 0)
      }else if (rAdata[i]==1 & Bdata[i]==0){
        a = c(a, 1)
      }else{
        a = c(a, 2)}
    }
    if (sum(a==1)>0){
      b = ((a==0) | (a==1))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model31 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model31, test="Chisq"))["Pr(>Chisq)2"]
      m31 = cbind(coef(model31), suppressMessages(confint.default(model31)),pv)[2,]
    }else{
      m31 = c(NA, NA, NA, NA)
    }
    if (sum(a==2)>0){
      b = ((a==0) | (a==2))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model32 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model32, test="Chisq"))["Pr(>Chisq)2"]
      m32 = cbind(coef(model32), suppressMessages(confint.default(model32)),pv)[2,]
    }else{
      m32 = c(NA, NA, NA, NA)
    }
    Res = rbind(m31,m32)
    rownames(Res) = c("M1_int_r1_1vs0","M1_int_r1_2vs0")
  }else if (patt_num_2==4){
    #4
    a = c()
    for (i in 1: length(Adata)){
      if (Adata[i]==0 & Bdata[i]==0){
        a = c(a, 0)
      }else if (Adata[i]==1 & Bdata[i]==0){
        a = c(a, 0)
      }else if (Adata[i]==0 & Bdata[i]==1){
        a = c(a, 1)
      }else{
        a = c(a, 2)}
    }
    if (sum(a==1)>0){
      b = ((a==0) | (a==1))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model41 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model41, test="Chisq"))["Pr(>Chisq)2"]
      m41 = cbind(coef(model41), suppressMessages(confint.default(model41)),pv)[2,]
    }else{
      m41 = c(NA, NA, NA, NA)
    }
    if (sum(a==2)>0){
      b = ((a==0) | (a==2))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model42 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model42, test="Chisq"))["Pr(>Chisq)2"]
      m42 = cbind(coef(model42), suppressMessages(confint.default(model42)),pv)[2,]
    }else{
      m42 = c(NA, NA, NA, NA)
    }
    Res = rbind(m41,m42)
    rownames(Res) = c("M2_int_o2_1vs0","M2_int_o2_2vs0")
  }else if (patt_num_2==5){
    #5
    a = c()
    for (i in 1: length(Adata)){
      if (Adata[i]==0 & rBdata[i]==0){
        a = c(a, 0)
      }else if (Adata[i]==1 & rBdata[i]==0){
        a = c(a, 0)
      }else if (Adata[i]==1 & rBdata[i]==1){
        a = c(a, 2)
      }else{
        a = c(a, 1)}
    }
    if (sum(a==1)>0){
      b = ((a==0) | (a==1))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model51 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model51, test="Chisq"))["Pr(>Chisq)2"]
      m51 = cbind(coef(model51), suppressMessages(confint.default(model51)),pv)[2,]
    }else{
      m51 = c(NA, NA, NA, NA)
    }
    if (sum(a==2)>0){
      b = ((a==0) | (a==2))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model52 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model52, test="Chisq"))["Pr(>Chisq)2"]
      m52 = cbind(coef(model52), suppressMessages(confint.default(model52)),pv)[2,]
    }else{
      m52 = c(NA, NA, NA, NA)
    }
    Res = rbind(m51,m52)
    rownames(Res) = c("M2_int_r2_1vs0","M2_int_r2_2vs0")
  }else if (patt_num_2==6){
    #6
    a = c()
    for (i in 1: length(Adata)){
      if (Adata[i]==1 & Bdata[i]==1){
        a = c(a, 1)
      }else{
        a = c(a, 0)}
    }
    if (sum(a==1)>0){
      b = ((a==0) | (a==1))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model61 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model61, test="Chisq"))["Pr(>Chisq)2"]
      m61 = cbind(coef(model61), suppressMessages(confint.default(model61)),pv)[2,]
    }else{
      m61 = c(NA, NA, NA, NA)
    }
    Res =  matrix(m61,1)
    rownames(Res) = c("int_oo_1vs0")
  }else if (patt_num_2==8){
    #8
    a = c()
    for (i in 1: length(Adata)){
      if (Adata[i]==1 & rBdata[i]==1){
        a = c(a, 1)
      }else{
        a = c(a, 0)}
    }
    if (sum(a==1)>0){
      b = ((a==0) | (a==1))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model81 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model81, test="Chisq"))["Pr(>Chisq)2"]
      m81 = cbind(coef(model81), suppressMessages(confint.default(model81)),pv)[2,]
    }else{
      m81 = c(NA, NA, NA, NA)
    }
    Res =  matrix(m81,1)
    rownames(Res) = c("int_or_1vs0")
  }else if (patt_num_2==7){
    #7
    a = c()
    for (i in 1: length(rAdata)){
      if (rAdata[i]==1 & Bdata[i]==1){
        a = c(a, 1)
      }else{
        a = c(a, 0)}
    }
    if (sum(a==1)>0){
      b = ((a==0) | (a==1))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model71 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model71, test="Chisq"))["Pr(>Chisq)2"]
      m71 = cbind(coef(model71), suppressMessages(confint.default(model71)),pv)[2,]
    }else{
      m71 = c(NA, NA, NA, NA)
    }
    Res =  matrix(m71,1)
    rownames(Res) = c("int_ro_1vs0")
  }else{
    #9
    a = c()
    for (i in 1: length(rAdata)){
      if (rAdata[i]==1 & rBdata[i]==1){
        a = c(a, 1)
      }else{
        a = c(a, 0)}
    }
    if (sum(a==1)>0){
      b = ((a==0) | (a==1))
      data_OF = data.frame(Outcome=Outcome[b],aa=factor(a[b]))
      data_OFX = cbind(data_OF,X[b,])
      colnames(data_OFX) =  c(colnames(data_OF), colnames(X))
      X_names =  paste(colnames(X), collapse= "+")
      model1_for = as.formula(paste("Outcome~aa+",X_names))
      modelc_for = as.formula(paste("Outcome~",X_names))
      model91 = glm(model1_for,data=data_OFX,family=ModelType)
      modelc = glm(modelc_for,data=data_OFX,family=ModelType)
      pv = unlist(.waldtest(modelc, model91, test="Chisq"))["Pr(>Chisq)2"]
      m91 = cbind(coef(model91), suppressMessages(confint.default(model91)),pv)[2,]
    }else{
      m91 = c(NA, NA, NA, NA)
    }
    Res = matrix(m91,1)
    rownames(Res) = c("int_rr_1vs0")
  }
  Res[,1:3] = exp(Res[,1:3])
  return(Res)
}

