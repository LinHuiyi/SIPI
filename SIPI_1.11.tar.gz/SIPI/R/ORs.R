
write_OR_csv = function(obj,path){
  if (is.matrix(obj)|is.data.frame(obj)){
    write.csv(obj, path, row.names=F)
  }else{
    SNP_names = names(obj)
    if (all(names(obj)!="selectedModel")){
      d_all = c()
      for (i in SNP_names){
        d1 = obj[[i]]
        d2 = rep(i,dim(d1)[1])
        #d3 = rownames(d1)
        d_all = rbind(d_all, cbind(d2,d1))
      }
      colnames(d_all)[1] = 'Pair'
      #colnames(d_all)[2] = 'Pattern'
      write.csv(d_all, path,row.names=FALSE)
    }else{
      m1 = obj$selectedModel
      m2 = obj$OR
      SNP_names = names(m2)
      d_all = c()
      s_all = c()
      s = 1
      res=c()
      for (i in SNP_names){
        d1 = m2[[i]]
        d2 = rep(i,dim(d1)[1])
        #d3 = rownames(d1)
        m1_all = matrix(data=NA,nrow=dim(d1)[1],ncol=5)
        m1_all[1,] = m1[s,]
        res = rbind(res, cbind(m1_all, cbind(d2,d1)))
        s = s+1
      }
      colnames(res)[1:5] = colnames(m1)
      colnames(res)[6] = 'Pair'
      #colnames(res)[7] = 'Pattern'
      res = res[,c(1,2,3,7,8,9,10)]
      write.csv(res, path,row.names=FALSE,na = "")
    }

  }
}




OddsRatioEst_unit_forall = function(Outcome,SNPdata,PairInfo1,PairInfo2,patt,ModelType = "binomial"){
  results = list()
  if (length(patt)==1){
    res = OddsRatioEst(Outcome,SNPdata,c(PairInfo1, PairInfo2),ModelType = "binomial")
    idx = c()
    for (i in rownames(res)){
      if (is.na(pmatch(patt, i))){
        idx = c(idx, FALSE)
      }else{
        idx = c(idx, TRUE)
      }
    }
    if (sum(idx)>0){
      results[['SNP1_SNP2']] = matrix(res[idx,],sum(idx),3, dimnames = list(rownames(res)[idx],colnames(res)))
    }

  }else{
    for (i in 1:length(patt)){
      res = OddsRatioEst(Outcome,SNPdata,c(PairInfo1[i], PairInfo2[i]),ModelType = "binomial")
      idx = c()
      for (k in rownames(res)){
        if (is.na(pmatch(patt[i], k))){
          idx = c(idx, FALSE)
        }else{
          idx = c(idx, TRUE)
        }
      }
      if (sum(idx)>0){
        p = paste(PairInfo1[i],'_',PairInfo2[i],sep="")
        results[[p]] = matrix(res[idx,],sum(idx),3, dimnames = list(rownames(res)[idx],colnames(res)))
      }
    }
  }
  return(results)
}





OddsRatioEst_unit = function(Outcome,SNPdata,PairInfo1,PairInfo2,patt,ModelType = "binomial"){
  results = list()
  if (length(patt)==1){
    res = OddsRatioEst(Outcome,SNPdata,c(PairInfo1, PairInfo2),ModelType = "binomial")
    idx = c()
    for (i in rownames(res)){
      if (is.na(pmatch(patt, i))){
        idx = c(idx, FALSE)
      }else{
        idx = c(idx, TRUE)
      }
    }
    results[['SNP1_SNP2']] = matrix(res[idx,],sum(idx),3, dimnames = list(rownames(res)[idx],colnames(res)))
  }else{
    for (i in 1:length(patt)){
      res = OddsRatioEst(Outcome,SNPdata,c(PairInfo1[i], PairInfo2[i]),ModelType = "binomial")
      idx = c()
      for (k in rownames(res)){
        if (is.na(pmatch(patt[i], k))){
          idx = c(idx, FALSE)
        }else{
          idx = c(idx, TRUE)
        }
      }
      p = paste(PairInfo1[i],'_',PairInfo2[i],sep="")
      results[[p]] = matrix(res[idx,],sum(idx),3, dimnames = list(rownames(res)[idx],colnames(res)))
    }
  }
  return(results)
}



OddsRatioEst = function (Outcome,SNPdata,PairInfo,ModelType = "binomial"){
  SNPdata = SNPdata[,PairInfo]

  sData = setupSNP(SNPdata,1:2,sep="")
  Domdata = sapply(1:2, function(x) as.numeric(dominant(sData[,x]))) - 1
  Recdata = sapply(1:2, function(x) as.numeric(recessive(sData[,x]))) - 1
  Condata = sapply(1:2, function(x) as.numeric(additive(sData[,x])))

  DD = .Ors_naa_all(Outcome,Domdata[,1],Domdata[,2],ModelType)
  DR = .Ors_naa_all(Outcome,Domdata[,1],Recdata[,2],ModelType)
  RD = .Ors_naa_all(Outcome,Recdata[,1],Domdata[,2],ModelType)
  RR = .Ors_naa_all(Outcome,Recdata[,1],Recdata[,2],ModelType)
  AA = .Ors_aa_all(Outcome,Condata[,1],Condata[,2],ModelType)
  rownames(DD) = paste("DD",rownames(DD),sep='_')
  rownames(DR) = paste("DR",rownames(DR),sep='_')
  rownames(RD) = paste("RD",rownames(RD),sep='_')
  rownames(RR) = paste("RR",rownames(RR),sep='_')

  Ors = rbind(DD, DR, RD, RR, AA)
  colnames(Ors) = c('OR','OR_CI_2.5%','OR_CI_97.5%','P-value')
  return (OddsRatioEst=Ors)
  }

.Ors_aa_all = function(Outcome,Adata,Bdata,ModelType){
  wholeABData = cbind(Outcome,Adata,Bdata)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  wholeABData = NULL
  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  #1
  Cdata = Adata*Bdata
  model1 = glm(Outcome~Adata+Bdata+Cdata,family=ModelType)
  modelc = glm(Outcome~Bdata+Cdata,family=ModelType)
  pv11 = unlist(.waldtest(modelc, model1, test="Chisq"))["Pr(>Chisq)2"]

  modelc = glm(Outcome~Adata+Cdata,family=ModelType)
  pv12 = unlist(.waldtest(modelc, model1, test="Chisq"))["Pr(>Chisq)2"]
  modelc = glm(Outcome~Adata+Bdata,family=ModelType)
  pv13 = unlist(.waldtest(modelc, model1, test="Chisq"))["Pr(>Chisq)2"]
  pv1 = rbind(pv11,pv12,pv13)
  #2
  model2 = glm(Outcome~Adata+Cdata,family=ModelType)
  modelc = glm(Outcome~Cdata,family=ModelType)
  pv21 = unlist(.waldtest(modelc, model2, test="Chisq"))["Pr(>Chisq)2"]
  modelc = glm(Outcome~Adata,family=ModelType)
  pv22 = unlist(.waldtest(modelc, model2, test="Chisq"))["Pr(>Chisq)2"]
  pv2 = rbind(pv21,pv22)
  #3
  roCdata = rAdata*Bdata
  model3 = glm(Outcome~rAdata+roCdata,family=ModelType)
  modelc = glm(Outcome~roCdata,family=ModelType)
  pv31 = unlist(.waldtest(modelc, model3, test="Chisq"))["Pr(>Chisq)2"]
  modelc = glm(Outcome~rAdata,family=ModelType)
  pv32 = unlist(.waldtest(modelc, model3, test="Chisq"))["Pr(>Chisq)2"]
  pv3 = rbind(pv31,pv32)
  #4
  model4 = glm(Outcome~Bdata+Cdata,family=ModelType)
  modelc = glm(Outcome~Cdata,family=ModelType)
  pv41 = unlist(.waldtest(modelc, model4, test="Chisq"))["Pr(>Chisq)2"]
  modelc = glm(Outcome~Bdata,family=ModelType)
  pv42 = unlist(.waldtest(modelc, model4, test="Chisq"))["Pr(>Chisq)2"]
  pv4 = rbind(pv41,pv42)
  #5
  orCdata = Adata*rBdata
  model5 = glm(Outcome~rBdata+orCdata,family=ModelType)
  modelc = glm(Outcome~orCdata,family=ModelType)
  pv51 = unlist(.waldtest(modelc, model5, test="Chisq"))["Pr(>Chisq)2"]
  modelc = glm(Outcome~rBdata,family=ModelType)
  pv52 = unlist(.waldtest(modelc, model5, test="Chisq"))["Pr(>Chisq)2"]
  pv5 = rbind(pv51,pv52)
  #6
  model6 = glm(Outcome~Adata:Bdata,family=ModelType)
  modelc = glm(Outcome~1,family=ModelType)
  pv6 = unlist(.waldtest(modelc, model6, test="Chisq"))["Pr(>Chisq)2"]
  #7
  model7 = glm(Outcome~rAdata:Bdata,family=ModelType)
  modelc = glm(Outcome~1,family=ModelType)
  pv7 = unlist(.waldtest(modelc, model7, test="Chisq"))["Pr(>Chisq)2"]
  model8 = glm(Outcome~Adata:rBdata,family=ModelType)
  modelc = glm(Outcome~1,family=ModelType)
  pv8 = unlist(.waldtest(modelc, model8, test="Chisq"))["Pr(>Chisq)2"]
  model9 = glm(Outcome~rAdata:rBdata,family=ModelType)
  modelc = glm(Outcome~1,family=ModelType)
  pv9 = unlist(.waldtest(modelc, model9, test="Chisq"))["Pr(>Chisq)2"]

  m1 = cbind(cbind(coef(model1), suppressMessages(confint.default(model1)))[2:4,],pv1)
  m2 = cbind(cbind(coef(model2), suppressMessages(confint.default(model2)))[2:3,],pv2)
  m3 = cbind(cbind(coef(model3), suppressMessages(confint.default(model3)))[2:3,],pv3)
  m4 = cbind(cbind(coef(model4), suppressMessages(confint.default(model4)))[2:3,],pv4)
  m5 = cbind(cbind(coef(model5), suppressMessages(confint.default(model5)))[2:3,],pv5)
  m6 = c(cbind(coef(model6), suppressMessages(confint.default(model6)))[2,],pv6)
  m8 = c(cbind(coef(model8), suppressMessages(confint.default(model8)))[2,],pv8)
  m7 = c(cbind(coef(model7), suppressMessages(confint.default(model7)))[2,],pv7)
  m9 = c(cbind(coef(model9), suppressMessages(confint.default(model9)))[2,],pv9)


  colnames(m1)=colnames(m2)=colnames(m3)=colnames(m4)=colnames(m5)=colnames(m6)=colnames(m7)=colnames(m8)=colnames(m9)=NULL
  Res = rbind(as.matrix(m1,3,4),
              as.matrix(m2,2,4),
              as.matrix(m3,2,4),
              as.matrix(m4,2,4),
              as.matrix(m5,2,4),
              matrix(m6,1),
              matrix(m8,1),
              matrix(m7,1),
              matrix(m9,1))

  rownames(Res) = c("AA_Full_1","AA_Full_2","AA_Full_12",
                    "AA_M1_int_o1_1","AA_M1_int_o1_12",
                    "AA_M1_int_r1_1","AA_M1_int_r1_12",
                    "AA_M2_int_o2_2","AA_M2_int_o2_12",
                    "AA_M2_int_r2_2","AA_M2_int_r2_12",
                    "AA_int_oo_12",
                    "AA_int_or_12",
                    "AA_int_ro_12",
                    "AA_int_rr_12")
  Res[,1:3] = exp(Res[,1:3])
  return(Res)
}

.Ors_naa_all = function(Outcome,Adata,Bdata,ModelType){
  wholeABData = cbind(Outcome,Adata,Bdata)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  wholeABData = NULL
  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  #1
  a = c()
  for (i in 1: length(Adata)){
    if (Adata[i]==0 & Bdata[i]==0){
      a = c(a, 0)
    }else if (Adata[i]==1 & Bdata[i]==0){
      a = c(a, 1)
    }else if (Adata[i]==0 & Bdata[i]==1){
      a = c(a, 2)
    }else{
      a = c(a, 3)}
    }
  if (sum(a==1)>0){
    b = ((a==0) | (a==1))
    model11 = glm(Outcome[b]~factor(a[b]),family=ModelType)
    modelc = glm(Outcome[b]~1,family=ModelType)
    pv = unlist(.waldtest(modelc, model11, test="Chisq"))["Pr(>Chisq)2"]
    m11 = cbind(coef(model11), suppressMessages(confint.default(model11)),pv)[2,]
  }else{
    m11=c(NA, NA, NA, NA)
  }
  if (sum(a==2)>0){
  b = ((a==0) | (a==2))
  model12 = glm(Outcome[b]~factor(a[b]),family=ModelType)
  modelc = glm(Outcome[b]~1,family=ModelType)
  pv = unlist(.waldtest(modelc, model12, test="Chisq"))["Pr(>Chisq)2"]
  m12 = cbind(coef(model12), suppressMessages(confint.default(model12)),pv)[2,]
  }else{
    m12 = c(NA, NA, NA, NA)
  }
  if (sum(a==3)>0){
  b = ((a==0) | (a==3))
  model13 = glm(Outcome[b]~factor(a[b]),family=ModelType)
  modelc = glm(Outcome[b]~1,family=ModelType)
  pv = unlist(.waldtest(modelc, model13, test="Chisq"))["Pr(>Chisq)2"]
  m13 = cbind(coef(model13), suppressMessages(confint.default(model13)),pv)[2,]
  }else{
    m13 = c(NA, NA, NA, NA)
  }
  #2
  a = c()
  for (i in 1: length(Adata)){
    if (Adata[i]==0 & Bdata[i]==0){
      a = c(a, 0)
    }else if (Adata[i]==1 & Bdata[i]==0){
      a = c(a, 1)
    }else if (Adata[i]==0 & Bdata[i]==1){
      a = c(a, 0)
    }else{
      a = c(a, 2)}
  }
  if (sum(a==1)>0){
    b = ((a==0) | (a==1))
    model21 = glm(Outcome[b]~factor(a[b]),family=ModelType)
    modelc = glm(Outcome[b]~1,family=ModelType)
    pv = unlist(.waldtest(modelc, model21, test="Chisq"))["Pr(>Chisq)2"]
    m21 = cbind(coef(model21), suppressMessages(confint.default(model21)),pv)[2,]
  }else{
    m21 = c(NA, NA, NA, NA)
  }
  if (sum(a==2)>0){
  b = ((a==0) | (a==2))
  model22 = glm(Outcome[b]~factor(a[b]),family=ModelType)
  modelc = glm(Outcome[b]~1,family=ModelType)
  pv = unlist(.waldtest(modelc, model22, test="Chisq"))["Pr(>Chisq)2"]
  m22 = cbind(coef(model22), suppressMessages(confint.default(model22)),pv)[2,]
  }else{
    m22 = c(NA, NA, NA, NA)
  }

  #3
  a = c()
  for (i in 1: length(rAdata)){
    if (rAdata[i]==0 & Bdata[i]==0){
      a = c(a, 0)
    }else if (rAdata[i]==0 & Bdata[i]==1){
      a = c(a, 0)
    }else if (rAdata[i]==1 & Bdata[i]==0){
      a = c(a, 1)
    }else{
      a = c(a, 2)}
  }
  if (sum(a==1)>0){
    b = ((a==0) | (a==1))
    model31 = glm(Outcome[b]~factor(a[b]),family=ModelType)
    modelc = glm(Outcome[b]~1,family=ModelType)
    pv = unlist(.waldtest(modelc, model31, test="Chisq"))["Pr(>Chisq)2"]
    m31 = cbind(coef(model31), suppressMessages(confint.default(model31)),pv)[2,]
  }else{
    m31 = c(NA, NA, NA, NA)
  }
  if (sum(a==2)>0){
  b = ((a==0) | (a==2))
  model32 = glm(Outcome[b]~factor(a[b]),family=ModelType)
  modelc = glm(Outcome[b]~1,family=ModelType)
  pv = unlist(.waldtest(modelc, model32, test="Chisq"))["Pr(>Chisq)2"]
  m32 = cbind(coef(model32), suppressMessages(confint.default(model32)),pv)[2,]
  }else{
    m32 = c(NA, NA, NA, NA)
  }

  #4
  a = c()
  for (i in 1: length(Adata)){
    if (Adata[i]==0 & Bdata[i]==0){
      a = c(a, 0)
    }else if (Adata[i]==1 & Bdata[i]==0){
      a = c(a, 0)
    }else if (Adata[i]==0 & Bdata[i]==1){
      a = c(a, 1)
    }else{
      a = c(a, 2)}
  }
  if (sum(a==1)>0){
    b = ((a==0) | (a==1))
    model41 = glm(Outcome[b]~factor(a[b]),family=ModelType)
    modelc = glm(Outcome[b]~1,family=ModelType)
    pv = unlist(.waldtest(modelc, model41, test="Chisq"))["Pr(>Chisq)2"]
    m41 = cbind(coef(model41), suppressMessages(confint.default(model41)),pv)[2,]
  }else{
    m41 = c(NA, NA, NA, NA)
  }
  if (sum(a==2)>0){
    b = ((a==0) | (a==2))
    model42 = glm(Outcome[b]~factor(a[b]),family=ModelType)
    modelc = glm(Outcome[b]~1,family=ModelType)
    pv = unlist(.waldtest(modelc, model42, test="Chisq"))["Pr(>Chisq)2"]
    m42 = cbind(coef(model42), suppressMessages(confint.default(model42)),pv)[2,]
  }else{
    m42 = c(NA, NA, NA, NA)
  }

  #5
  a = c()
  for (i in 1: length(Adata)){
    if (Adata[i]==0 & rBdata[i]==0){
      a = c(a, 0)
    }else if (Adata[i]==1 & rBdata[i]==0){
      a = c(a, 0)
    }else if (Adata[i]==1 & rBdata[i]==1){
      a = c(a, 2)
    }else{
      a = c(a, 1)}
  }
  if (sum(a==1)>0){
    b = ((a==0) | (a==1))
    model51 = glm(Outcome[b]~factor(a[b]),family=ModelType)
    modelc = glm(Outcome[b]~1,family=ModelType)
    pv = unlist(.waldtest(modelc, model51, test="Chisq"))["Pr(>Chisq)2"]
    m51 = cbind(coef(model51), suppressMessages(confint.default(model51)),pv)[2,]
  }else{
    m51 = c(NA, NA, NA, NA)
  }
  if (sum(a==2)>0){
    b = ((a==0) | (a==2))
    model52 = glm(Outcome[b]~factor(a[b]),family=ModelType)
    modelc = glm(Outcome[b]~1,family=ModelType)
    pv = unlist(.waldtest(modelc, model52, test="Chisq"))["Pr(>Chisq)2"]
    m52 = cbind(coef(model52), suppressMessages(confint.default(model52)),pv)[2,]
  }else{
    m52 = c(NA, NA, NA, NA)
  }

  #6
  a = c()
  for (i in 1: length(Adata)){
    if (Adata[i]==1 & Bdata[i]==1){
      a = c(a, 1)
    }else{
      a = c(a, 0)}
  }
  if (sum(a==1)>0){
  b = ((a==0) | (a==1))
  model61 = glm(Outcome[b]~factor(a[b]),family=ModelType)
  modelc = glm(Outcome[b]~1,family=ModelType)
  pv = unlist(.waldtest(modelc, model61, test="Chisq"))["Pr(>Chisq)2"]
  m61 = cbind(coef(model61), suppressMessages(confint.default(model61)),pv)[2,]
  }else{
    m61 = c(NA, NA, NA, NA)
  }
  #7
  a = c()
  for (i in 1: length(rAdata)){
    if (rAdata[i]==1 & Bdata[i]==1){
      a = c(a, 1)
    }else{
      a = c(a, 0)}
  }
  if (sum(a==1)>0){
  b = ((a==0) | (a==1))
  model71 = glm(Outcome[b]~factor(a[b]),family=ModelType)
  modelc = glm(Outcome[b]~1,family=ModelType)
  pv = unlist(.waldtest(modelc, model71, test="Chisq"))["Pr(>Chisq)2"]
  m71 = cbind(coef(model71), suppressMessages(confint.default(model71)),pv)[2,]
  }else{
    m71 = c(NA, NA, NA, NA)
  }

  #8
  a = c()
  for (i in 1: length(Adata)){
    if (Adata[i]==1 & rBdata[i]==1){
      a = c(a, 1)
    }else{
      a = c(a, 0)}
  }
  if (sum(a==1)>0){
  b = ((a==0) | (a==1))
  model81 = glm(Outcome[b]~factor(a[b]),family=ModelType)
  modelc = glm(Outcome[b]~1,family=ModelType)
  pv = unlist(.waldtest(modelc, model81, test="Chisq"))["Pr(>Chisq)2"]
  m81 = cbind(coef(model81), suppressMessages(confint.default(model81)),pv)[2,]
  }else{
    m81 = c(NA, NA, NA, NA)
  }
  #9
  a = c()
  for (i in 1: length(rAdata)){
    if (rAdata[i]==1 & rBdata[i]==1){
      a = c(a, 1)
    }else{
      a = c(a, 0)}
  }
  if (sum(a==1)>0){
  b = ((a==0) | (a==1))
  model91 = glm(Outcome[b]~factor(a[b]),family=ModelType)
  modelc = glm(Outcome[b]~1,family=ModelType)
  pv = unlist(.waldtest(modelc, model91, test="Chisq"))["Pr(>Chisq)2"]
  m91 = cbind(coef(model91), suppressMessages(confint.default(model91)),pv)[2,]
  }else{
    m91 = c(NA, NA, NA, NA)
  }
  colnames(m11)=colnames(m12)=colnames(m13)=colnames(m21)=colnames(m22)=colnames(m31)=colnames(m32)=NULL
  colnames(m41)=colnames(m42)=colnames(m51)=colnames(m52)=colnames(m61)=colnames(m71)=colnames(m81)=colnames(m91)=NULL

  Res = rbind(matrix(m11,1),
              matrix(m12,1),
              matrix(m13,1),
              matrix(m21,1),
              matrix(m22,1),
              matrix(m31,1),
              matrix(m32,1),
              matrix(m41,1),
              matrix(m42,1),
              matrix(m51,1),
              matrix(m52,1),
              matrix(m61,1),
              matrix(m81,1),
              matrix(m71,1),
              matrix(m91,1))

  rownames(Res) = c("Full_1vs0","Full_2vs0","Full_3vs0",
                    "M1_int_o1_1vs0","M1_int_o1_2vs0",
                    "M1_int_r1_1vs0","M1_int_r1_2vs0",
                    "M2_int_o2_1vs0","M2_int_o2_2vs0",
                    "M2_int_r2_1vs0","M2_int_r2_2vs0",
                    "int_oo_1vs0",
                    "int_or_1vs0",
                    "int_ro_1vs0",
                    "int_rr_1vs0")

  Res[,1:3] = exp(Res[,1:3])

  return(Res)
}
