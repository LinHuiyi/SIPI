#SNP Interaction Pattern Identifier (SIPI)
.SNP_int_9 = function(Outcome,Adata,Bdata,X,ZIM,TestType,ModelType){
  if (length(X)==0){
    if (ZIM){
      return(.SNP_int_9_zeroinfl_nc(Outcome,Adata,Bdata,TestType,ModelType))
    }
    else{
      return(.SNP_int_9_nc(Outcome,Adata,Bdata,TestType,ModelType))
    }
  }else{
    if (ZIM){
      return(.SNP_int_9_zeroinfl_c(Outcome,Adata,Bdata,X,TestType,ModelType))
    }else{
      return(.SNP_int_9_c(Outcome,Adata,Bdata,X,TestType,ModelType))
    }
  }
}



###function for each pair to get min(BIC) in 45 models
#DD:Dom-Dom
#DR:Dom-Rec
#RD:Rec-Dom
#RR:Rec-Rec
#AA:Add-Add
.SNP_int_45 = function(Outcome,Domdata,Recdata,Condata,a,b,X,ZIM,TestType,ModelType){
  DD = .SNP_int_9(Outcome,Domdata[,a],Domdata[,b],X,ZIM,TestType,ModelType)
  DR = .SNP_int_9(Outcome,Domdata[,a],Recdata[,b],X,ZIM,TestType,ModelType)
  RD = .SNP_int_9(Outcome,Recdata[,a],Domdata[,b],X,ZIM,TestType,ModelType)
  RR = .SNP_int_9(Outcome,Recdata[,a],Recdata[,b],X,ZIM,TestType,ModelType)
  AA = .SNP_int_9(Outcome,Condata[,a],Condata[,b],X,ZIM,TestType,ModelType)
  Bic = c(DD[,5],DR[,5],RD[,5],RR[,5],AA[,5])
  if (all(is.na(Bic))){
    MinCp = MaxC = Minm = NA
  }else{
    m = which.min(Bic)
    Cp = c(DD[,4],DR[,4],RD[,4],RR[,4],AA[,4])
    Cv = c(DD[,3],DR[,3],RD[,3],RR[,3],AA[,3])
    MinCp = Cp[m]
    MaxC = Cv[m]
    minB = c(DD[,1],DR[,1],RD[,1],RR[,1],AA[,1])[m]
    minS = c(DD[,2],DR[,2],RD[,2],RR[,2],AA[,2])[m]
    mod = c("DD","DR","RD","RR","AA")[ceiling(m/9)]
    Minm = paste(mod,names(m),sep='_')
  }

  rownames(DD) = paste("DD",rownames(DD),sep='_')
  rownames(DR) = paste("DR",rownames(DR),sep='_')
  rownames(RD) = paste("RD",rownames(RD),sep='_')
  rownames(RR) = paste("RR",rownames(RR),sep='_')
  rownames(AA) = paste("AA",rownames(AA),sep='_')
  return(list(DD=DD,DR=DR,RD=RD,RR=RR,AA=AA,Bic=Bic,SM=Minm,Scv=MaxC,Scp=MinCp,minB=minB,minS=minS))
}

.X_DataFrame = function(X, categXNames){
  if (length(X)==0|length(categXNames)==0|is.factor(X)){
    return(X)
  }else if (is.vector(X)){
    X = factor(X)
    return(X)
  }else if(length(categXNames)==1){
    X[,categXNames] = factor(X[,categXNames])
    return(X)
  }else{
    X[,categXNames]=lapply(X[,categXNames],factor)
    return(X)
  }

}
##function for one-pair analysis/pairwise analysis
SIPI = function(Outcome,SNPdata,PairInfo,X=NULL,categXNames=NULL,ZIM=FALSE,TestType="WaldTest",ModelType="binomial",OR=FALSE){
  X = .X_DataFrame(X,categXNames)
  Nsnp = dim(SNPdata)[2]
  sData = setupSNP(SNPdata,1:Nsnp,sep="")
  Domdata = sapply(1:Nsnp, function(x) as.numeric(dominant(sData[,x]))) - 1
  Recdata = sapply(1:Nsnp, function(x) as.numeric(recessive(sData[,x]))) - 1
  Condata = sapply(1:Nsnp, function(x) as.numeric(additive(sData[,x])))

  checkTwo = sapply(1:Nsnp, function(x)length(unique(na.omit(sData[,x]))))
  if (any(checkTwo<3)){
    VectorIntersect <- function(v,z) {
      unlist(lapply(unique(v[v%in%z]), function(x) rep(x,min(sum(v==x),sum(z==x)))))
    }
    is.contained <- function(v,z) {length(VectorIntersect(v,z))==length(v)}
    for (i in which(checkTwo<3)){
      for (j in which(checkTwo==3)){
        if (is.contained(levels(unique(na.omit(sData[,i]))),levels(unique(na.omit(sData[,j])))) ){
          q1 = c(as.character(SNPdata[,j]),as.character(SNPdata[,i]))
          q1f = data.frame(q1)
          q = setupSNP(q1f,1,sep="")
          Domdata[,i] = as.numeric(dominant(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Recdata[,i] = as.numeric(recessive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]] - 1
          Condata[,i] = as.numeric(additive(q[,1]))[(dim(q)[1]/2+1):dim(q)[1]]
          break
        }
      }
    }
  }

  sData = NULL
  if (is.list(PairInfo)){
    PairInfo = as.matrix(expand.grid(PairInfo[[1]], PairInfo[[2]]))
  }
  if (any(PairInfo=="all")){
    matrix_idx = 1
  }else if (is.null(dim(PairInfo))){
    matrix_idx = 2
  }else{
    matrix_idx = 3
  }

  if (matrix_idx != 2){
    SNPNames = colnames(SNPdata)
    if (matrix_idx == 1){
      allpair = combn(1:Nsnp,2)
    }else{
      PairInfo = as.matrix(PairInfo)
      allpair = .pairIndex(SNPNames, PairInfo)
    }
    comslist = split(t(allpair),as.factor(1:dim(t(allpair))[1]))
    reslist = sapply(comslist,
                     function(allpair){
                       Eachp = .SNP_int_45_r(Outcome,Domdata,Recdata,Condata,allpair[1],allpair[2],X,ZIM,TestType,ModelType)
                       if (length(Eachp$Scv)==0){
                         return(c(NA,NA,NA,NA,NA,NA))
                       }else{
                         return(c(Eachp$SM,Eachp$Scv,Eachp$Scp,min(Eachp$Bic),Eachp$minB,Eachp$minS))
                       }

                     })

    if (ModelType=="binomial"){
      res = data.frame(unlist(lapply(allpair[1,], function(m) SNPNames[[m]])),
                       unlist(lapply(allpair[2,], function(m) SNPNames[[m]])),
                       reslist[1,],
                       as.numeric(reslist[2,]),
                       as.numeric(reslist[3,]),stringsAsFactors=FALSE)

      if (TestType=="WaldTest"){
        colnames(res) = c("Var1","Var2","Pattern","Wald_Chisq","Wald_p")
      }else{
        colnames(res) = c("Var1","Var2","Pattern","LRT_Chisq","LRT_p")
      }
      if (OR==TRUE){
        if (matrix_idx==1){
          #OR = OddsRatioEst_unit_forall(Outcome,SNPdata,res[,1],res[,2],res[,3])
          #OR = OddsRatioEst_unit_pair_cal(Outcome,SNPdata,res[,1],res[,2],res[,3])
          OR = OddsRatioEst_unit_pair_cal_ALL(Outcome,SNPdata,res[,1],res[,2],res[,3],X)
        }else{
          #OR = OddsRatioEst_unit(Outcome,SNPdata,res[,1],res[,2],res[,3])
          #OR = OddsRatioEst_unit_pair_cal(Outcome,SNPdata,res[,1],res[,2],res[,3])
          OR = OddsRatioEst_unit_pair_cal_ALL(Outcome,SNPdata,res[,1],res[,2],res[,3],X)
        }
        return(list(selectedModel=res, OR=OR))
      }else{
        return(list(selectedModel=res))
      }
    }else{##Gaussian##
      res = data.frame(unlist(lapply(allpair[1,], function(m) SNPNames[[m]])),
                       unlist(lapply(allpair[2,], function(m) SNPNames[[m]])),
                       reslist[1,],
                       as.numeric(reslist[2,]),
                       as.numeric(reslist[3,]),
                       as.numeric(reslist[5,]),
                       as.numeric(reslist[6,]),
                       stringsAsFactors=FALSE)

      if (TestType=="WaldTest"){
        colnames(res) = c("Var1","Var2","Pattern","Wald_Chisq","Wald_p","Est.","Std.Er")
      }else{
        colnames(res) = c("Var1","Var2","Pattern","LRT_Chisq","LRT_p","Est.","Std.Er")
      }
      return(list(selectedModel=res))
    }

  }else{
    SNPNames = colnames(SNPdata)
    a = which(SNPNames==PairInfo[1])
    b = which(SNPNames==PairInfo[2])
    resSM = resSv = resSp = resScv = resScp = resnames1 = resnames2 = resbeta = resbeta = c()
    Eachp = .SNP_int_45(Outcome,Domdata,Recdata,Condata,a,b,X,ZIM,TestType,ModelType)
    if (length(Eachp$Scv)==0 | is.na(Eachp$Scv)){
      resSM = NA
      resScv = NA
      resScp = NA
      resBic = NA
      resbeta = NA
      resstd =  NA
      res45models = NA
    }else{
      resSM = Eachp$SM
      resScv = Eachp$Scv
      resScp = Eachp$Scp
      resBic = min(Eachp$Bic,na.rm=TRUE)
      resbeta = Eachp$minB
      resstd =  Eachp$minS
      res45models = data.frame(rbind(Eachp$DD,Eachp$DR,Eachp$RD,Eachp$RR,Eachp$AA))
      res45models = res45models[with(res45models,order(BIC)),]
      Var1 = rep(PairInfo[1],45)
      Var2 = rep(PairInfo[2],45)
      Pattern = as.matrix(rownames(res45models))

      res45models_G = cbind(Var1,Var2,Pattern,res45models[,c(5,3,4,1,2)])
      rownames(res45models_G) = NULL

      res45models = cbind(Var1,Var2,Pattern,res45models[,c(5,3,4)])
      rownames(res45models) = NULL
    }
    resnames1 = PairInfo[1]
    resnames2 = PairInfo[2]

    if (ModelType=="binomial"){
      res = data.frame(resnames1,resnames2,
                       resSM,resBic,resScv,resScp,stringsAsFactors=FALSE)
      rownames(res) = ''
      if (TestType=="WaldTest"){
        colnames(res) = c("Var1","Var2","Pattern","BIC","Wald_Chisq","Wald_p")
      }else{
        colnames(res) = c("Var1","Var2","Pattern","BIC","LRT_Chisq","LRT_p")
      }
      if (OR==TRUE){
        #OR = OddsRatioEst_unit(Outcome,SNPdata,res[1,1],res[1,2],res[1,3])
        #OR = OddsRatioEst(Outcome,SNPdata,PairInfo)
        OR = OddsRatioEst_unit_pair_cal_ALL(Outcome,SNPdata,res[,1],res[,2],res[,3],X)
        return(list(selectedModel=res,res45Models=res45models,OR=OR))
      }else{
        return(list(selectedModel=res,res45Models=res45models))
      }
    }else{
      res = data.frame(resnames1,resnames2,
                       resSM,resBic,resScv,resScp,resbeta ,resstd ,
                       stringsAsFactors=FALSE)
      rownames(res) = ''
      if (TestType=="WaldTest"){
        colnames(res) = c("Var1","Var2","Pattern","BIC","Wald_Chisq","Wald_p","Est.","Std.Er")
      }else{
        colnames(res) = c("Var1","Var2","Pattern","BIC","LRT_Chisq","LRT_p","Est.","Std.Er")
      }
      return(list(selectedModel=res,res45Models=res45models_G))
    }

  }
}

.Ide_miss = function(label_name, maj_min_1){
  maj_name_1 = strsplit(maj_min_1,"/")
  jj = paste(maj_name_1[[1]][1],maj_name_1[[1]][1],sep="")
  jn = paste(maj_name_1[[1]][2],maj_name_1[[1]][1],sep="")
  nn = paste(maj_name_1[[1]][2],maj_name_1[[1]][2],sep="")
  ad = c(jj, jn, nn)
  a = c()
  for (i in label_name){
    i %in% ad
    a = c(a, which(ad == i))
  }
  b = rep(FALSE,3)
  b[a] = TRUE
  return(b)
  }

.genotype = function(maj_min_1){
  maj_name_1 = strsplit(maj_min_1,"/")
  jj = paste(maj_name_1[[1]][1],maj_name_1[[1]][1],sep="")
  jn = paste(maj_name_1[[1]][2],maj_name_1[[1]][1],sep="")
  nn = paste(maj_name_1[[1]][2],maj_name_1[[1]][2],sep="")
  nj = paste(maj_name_1[[1]][1],maj_name_1[[1]][2],sep="")
  ad = c(jj, jn, nn, nj)
  return(ad)
}

#Outcome prevalence by the 3-by-3 genotypes of a given SNP pair
.maj_min = function(SNPdata){
  sData = setupSNP(SNPdata,1:dim(SNPdata)[2],sep="")
  snpRes = capture.output(summary(sData))[-1]
  snpInfor = matrix(rep(0,1*dim(SNPdata)[2]),dim(SNPdata)[2])
  for (i in 1:dim(SNPdata)[2]){
    snpRes1 = (strsplit(snpRes[i],' '))[[1]]
    snpRes1 =  snpRes1[snpRes1!=""]
    snpInfor[i,] = snpRes1[2]
  }
  snpInfor = as.data.frame(snpInfor)
  rownames(snpInfor) = colnames(SNPdata)
  colnames(snpInfor) = c('maj/min')
  return(snpInfor)
}

Grid3by3 = function(Outcome,SNPdata,PairInfo){
  wholeData = cbind(Outcome,SNPdata[,PairInfo])
  vdata = complete.cases(wholeData)
  wholeData = wholeData[vdata,]
  Outcome =  wholeData[,1]
  SNPdata = wholeData[,PairInfo]

  SNP1 = as.character(SNPdata[,PairInfo[1]])
  SNP2 = as.character(SNPdata[,PairInfo[2]])
  Lev1 = unique(SNP1)
  Lev2 = unique(SNP2)
  Lev1NA = (apply(array(Lev1),1,function(x) length((strsplit(x,""))[[1]])) > 1)
  Lev2NA = (apply(array(Lev2),1,function(x) length((strsplit(x,""))[[1]])) > 1)
  Lev1 = Lev1[Lev1NA]
  Lev2 = Lev2[Lev2NA]
  #len_Lev1 = length(Lev1)
  #len_Lev2 = length(Lev2)
  table3by3 = matrix(rep(0,3*3),3)
  table3by3Freq = matrix(rep(0,3*3),3)
  maj_min = .maj_min(SNPdata[,PairInfo])
  Lev1_f = .genotype(levels(maj_min[[1]])[maj_min[[1]][1]])
  Lev2_f = .genotype(levels(maj_min[[1]])[maj_min[[1]][2]])
  if ((sum(SNP1 == Lev1_f[2])==0) &  (sum(SNP1 == Lev1_f[4])>0)){
    Lev1_f = c(Lev1_f[1], Lev1_f[4], Lev1_f[3])
  }
  if ((sum(SNP2 == Lev2_f[2])==0) &  (sum(SNP2 == Lev2_f[4])>0)){
    Lev2_f = c(Lev2_f[1], Lev2_f[4], Lev2_f[3])
  }

  for (i in 1:3){
    for (j in 1:3){
      selectedN = ((SNP1 == Lev1_f[i]) & (SNP2 == Lev2_f[j]))
      totalN = sum(selectedN)
      OuptN = sum(Outcome[selectedN] == 1)
      table3by3[i,j] = OuptN / totalN
      if (is.nan(OuptN / totalN)){
        table3by3Freq [i, j] = 0#OuptN / totalN
        table3by3[i,j] = 0
      }else{
        table3by3Freq [i, j] = totalN
      }

    }
  }

  rownames(table3by3) = c(paste(PairInfo[1],':Maj/maj',sep=''),
                          paste(PairInfo[1],':Maj/min',sep=''),
                          paste(PairInfo[1],':Min/min',sep=''))
  colnames(table3by3) = c(paste(PairInfo[2],':Maj/maj',sep=''),
                          paste(PairInfo[2],':Maj/min',sep=''),
                          paste(PairInfo[2],':Min/min',sep=''))
  rownames(table3by3Freq) = c(paste(PairInfo[1],':Maj/maj',sep=''),
                              paste(PairInfo[1],':Maj/min',sep=''),
                              paste(PairInfo[1],':Min/min',sep=''))
  colnames(table3by3Freq) = c(paste(PairInfo[2],':Maj/maj',sep=''),
                              paste(PairInfo[2],':Maj/min',sep=''),
                              paste(PairInfo[2],':Min/min',sep=''))
  #if (len_Lev1 < 3){
  #  Idn = .Ide_miss(Lev1, levels(maj_min[[1]])[maj_min[[1]][1]])
  #  rownames(table3by3) = c(paste(PairInfo[1],':Maj/maj',sep=''),
  #                          paste(PairInfo[1],':Maj/min',sep=''),
  #                          paste(PairInfo[1],':Min/min',sep=''))[Idn]
  #  colnames(table3by3) = c(paste(PairInfo[2],':Maj/maj',sep=''),
  #                          paste(PairInfo[2],':Maj/min',sep=''),
  #                          paste(PairInfo[2],':Min/min',sep=''))
  #}else if(len_Lev2 < 3){
  #  Idn = .Ide_miss(Lev2, levels(maj_min[[1]])[maj_min[[1]][2]])
  #  rownames(table3by3) = c(paste(PairInfo[1],':Maj/maj',sep=''),
  #                          paste(PairInfo[1],':Maj/min',sep=''),
  #                          paste(PairInfo[1],':Min/min',sep=''))
  #  colnames(table3by3) = c(paste(PairInfo[2],':Maj/maj',sep=''),
  #                          paste(PairInfo[2],':Maj/min',sep=''),
  #                          paste(PairInfo[2],':Min/min',sep=''))[Idn]
  #}else{
  #  rownames(table3by3) = c(paste(PairInfo[1],':Maj/maj',sep=''),
  #                          paste(PairInfo[1],':Maj/min',sep=''),
  #                          paste(PairInfo[1],':Min/min',sep=''))
  #  colnames(table3by3) = c(paste(PairInfo[2],':Maj/maj',sep=''),
  #                          paste(PairInfo[2],':Maj/min',sep=''),
  #                          paste(PairInfo[2],':Min/min',sep=''))
  #}

  return (list(table3by3=table3by3,table3by3Freq=table3by3Freq,maj_min=maj_min))
}


MAFinfo = function(SNPdata){
  options(max.print=dim(SNPdata)[1]*10)
  sData = setupSNP(SNPdata,1:dim(SNPdata)[2],sep="")
  snpRes = capture.output(summary(sData))[-1]
  snpInfor = matrix(rep(0,5*dim(SNPdata)[2]),dim(SNPdata)[2])
  for (i in 1:dim(SNPdata)[2]){
    snpRes1 = (strsplit(snpRes[i],' '))[[1]]
    snpRes1 =  snpRes1[snpRes1!=""]
    snpInfor[i,] = c(snpRes1[-1], length(levels(sData[,i])))
  }
  snpInfor[,2] = round(1-(as.numeric(snpInfor[,2])/100),3)
  snpInfor = as.data.frame(snpInfor[,-3])
  rownames(snpInfor) = colnames(SNPdata)
  colnames(snpInfor) = c('maj/min','MAF','Missing(%)','No_genotype')
  return(snpInfor)
}

.pairIndex = function (SNPNames, pairMatrix){
  Npair = dim(pairMatrix)[1]
  SNP1 = sapply(1:Npair, function(x) which(SNPNames == pairMatrix[x,1]))
  SNP2 = sapply(1:Npair, function(x) which(SNPNames == pairMatrix[x,2]))
  return(rbind(t(SNP1),t(SNP2)))
}
