
Z_score_correct = function(p1,n1,p2){
  p1_c = (p1*n1+2)/(n1+4)
  a1 = p1_c - p2
  b3 = sqrt(p1_c*(1-p1_c)/(n1+4))
  return(a1/b3)
}

Z_score = function(p1,n1,p2){
  p1 = (p1*n1)/(n1)
  a1 = p1 - p2
  b3 = sqrt(p1*(1-p1)/(n1))
  b3[which(b3==0)]=0.01
  return(a1/b3)


}

Z_similarity = function(p1_list, n1_list, p2_list, n2_list,correct=TRUE){
  p1 = sum(p1_list * n1_list) / sum(n1_list)
  p2 = sum(p2_list * n2_list) / sum(n2_list)

  if (correct){
    z1 = Z_score_correct(p1_list,n1_list,p1)
    z2 = Z_score_correct(p2_list,n2_list,p2)
  }else{
    z1 = Z_score(p1_list,n1_list,p1)
    z2 = Z_score(p2_list,n2_list,p2)
  }
  return(cor.test(z1,z2,method=c("pearson")))
}


corSI = function(p1_Outcome,p1_SNPdata,p2_Outcome,p2_SNPdata,method='wcor',plot=FALSE){
  p1_name = colnames(p1_SNPdata)
  concatdata = cbind(p1_Outcome,p1_SNPdata)
  colnames(concatdata) = c('D',p1_name)
  p1 = Grid3by3(concatdata$D,concatdata,p1_name)
  p1_p = matrix(matrix(p1$table3by3,3,3,byrow=TRUE))
  p1_n = matrix(matrix(p1$table3by3Freq,3,3,byrow=TRUE))

  p2_name = colnames(p2_SNPdata)
  concatdata = cbind(p2_Outcome,p2_SNPdata)
  colnames(concatdata) = c('D',p2_name)
  p2 = Grid3by3(concatdata$D,concatdata,p2_name)
  p2_p = matrix(matrix(p2$table3by3,3,3,byrow=TRUE))
  p2_n = matrix(matrix(p2$table3by3Freq,3,3,byrow=TRUE))
  if (method == 'CorSIw'){
    weight = (p1_n+p2_n)/sum(p1_n+p2_n)
    m2 = wtd.cor(p1_p,p2_p,weight=weight)
    metrics = m2[1]
    pvalue  = m2[4]
  }else if(method == 'Cor'){
    m1 = cor.test(p1_p,p2_p)
    metrics = m1$estimate
    pvalue  = m1$p.value
  }else{
    m3 = Z_similarity(p1_p,p1_n,p2_p,p2_n,correct=TRUE)
    metrics = m3$estimate
    pvalue  = m3$p.value
  }

  if (plot==TRUE){
    a = plot3by3(p1, scale = "fixed", axis_fs = 0.6, outcome_fs = 0.6, freq_fs = 0.6, legend=FALSE,SNP_info=TRUE,marginal = T)
    b = plot3by3(p2, scale = "fixed", axis_fs = 0.6, outcome_fs = 0.6, freq_fs = 0.6, legend=FALSE,SNP_info=TRUE,marginal = T)
    aa = a
    bb = b
    plot = ggarrange(a, b, heights = c(2, 0.7),ncol = 2, nrow = 1)
    return(list(metric=as.numeric(metrics),pvalue=as.numeric(pvalue),plot=plot))
  }else{
    return(list(metric=as.numeric(metrics),pvalue=as.numeric(pvalue)))
    }
}

