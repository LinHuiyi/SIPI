### function plot3by3
# R version 3.4.3
# require:
#       SIPI(0.56)
#       ggplot2(3.0.0)
#       ggpubr(0.1.7)

### roxgeny2 documentation

#' Heatmap plot of outcome proportions by genotype combinations
#'
#' Create a heatmap plot of outcome proportions by the 3-by-3 genotype combinations for a given SNP pair.
#'
#' This function creates a heatmap plot based on the output of \code{\link{Grid3by3}}, which generates outcome proportions by genotype combinations of a given SNP pair.
#'
#'
#' @param x List object output from function \code{Grid3by3}.
#' @param SNP_info Put SNP information(SNP name and major/minor allele) on plot. Default is \code{TRUE}.
#' @param outcome Include outcome proportions in each cell of plot. Default is \code{TRUE}. When no observations is in the given cell, 'NaN' will be shown. If there is no observation and \code{outcome=FALSE}, a warning will be shown.
#' @param freq Include frequency in each cell. Default is \code{TRUE}
#' @param legend Include legend. Default is \code{TRUE}.
#' @param monochrome Output monochrome plot. Default is \code{FALSE}.
#' @param scale A character string specifying the colour gradient scale type. \code{"fixed"} will lend color to heatmap with fixed color gradient scale from 0 to 1, \code{"sliding"} will lend color to heatmap with sliding gradient scale between minimum and maximum outcome proportion. Default is \code{"fixed"}.
#' @param marginal Include outcome proportions for overall and individual SNPs. Default is \code{FALSE}.
#' @param axis_fs Axis font size. Adjusted both axis title font size and axis label font size. Number greater than 1 will enlarge the font size, less than 1 will reduce the font size. Default is \code{1}.
#' @param outcome_fs Outcome font size. Number greater than 1 will enlarge the font size, less than 1 will reduce the font size. Default is \code{1}.
#' @param freq_fs Frequency font sizr. Number greater than 1 will enlarge the font size, less than 1 will reduce the font size. Default is \code{1}.
#' @param lgd_fs Legend font size. Number greater than 1 will enlarge the font size, less than 1 will reduce the font size. Default is \code{1}.
#' @return A heatmap plot of outcome proportions, which is a \code{\link[ggplot2]{ggplot}} object.
#' @seealso \code{\link{Grid3by3}}
#' @references H. Wickham. ggplot2: Elegant Graphics for Data Analysis. Springer-Verlag New York, 2009.
#' @examples
#' data(simData)
#' SNPdata = simData[,3:12]
#' x = Grid3by3(simData$D, SNPdata, c('SNP1', 'SNP2'))
#' plot3by3(x, SNP_info = F, outcome = F, legend = T, scale = "fixed", monochrome = T, lgd_fs = 1.2)
#'
#' x = Grid3by3(simData$D, SNPdata, c('SNP4', 'SNP6'))
#' plot3by3(x, scale = "sliding", axis_fs = 1.2, outcome_fs = 0.9, freq_fs = 0.8)
#' plot3by3(x, scale = "sliding", freq = F, axis_fs = 1.2, outcome_fs = 0.9)
plot3by3 <- function(x, SNP_info = T, outcome = T, freq = T, legend = T,
                     monochrome = F, scale = "fixed", marginal = F,
                     axis_fs = 1, outcome_fs = 1, freq_fs = 1, lgd_fs = 1){
    snp1 <- gl(3,1)
    snp2 <- gl(3,1)
    levels(snp1)[1:3] <- c("aa", "Aa", "AA")
    levels(snp2)[1:3] <- c("BB", "Bb", "bb")
    heat_table <- expand.grid("SNP1" = rev(snp1), "SNP2" = (snp2))

    heat_table$color_scale <- c(x$table3by3)
    heat_table$outcome_prop <- round(c(x$table3by3), 2)
    heat_table$outcome_prop[is.nan(heat_table$outcome_prop)] <- "NaN"

    heat_table$freq <- round(c(x$table3by3Freq), 2)
    heat_table$freq[is.nan(heat_table$freq)] <- "NaN"
    heat_table$freq <- paste0("(", heat_table$freq, ")")

    p_33 <- ggplot(heat_table, aes(SNP2, SNP1, z = color_scale)) + geom_tile(aes(fill = color_scale)) +
	        theme(panel.background = element_rect(fill = NA),
	              axis.ticks = element_blank(), axis.text = element_text(size = 20*axis_fs, color = "black"),
	              axis.title = element_text(size = 25*axis_fs), axis.line = element_line(),
	              legend.position = "right")

    p_adj11 <- guides(fill =  guide_colorbar(title = "Outcome \nProportion", ,
                                            barwidth = 2.5, barheight = 8, ticks = F, nbin = 60,
                                            title.theme = element_text(size = 15*lgd_fs, angle = 0, vjust = 0.9),
                                            label.theme = element_text(size = 15*lgd_fs, angle = 0)))

    if(monochrome == T){
    	col_use <- c("white", "grey80", "grey20")
    }else{
    	col_use <- c("white", "firebrick1", "firebrick")
    }
    if(scale == "fixed"){
        p_adj1 <- scale_fill_gradientn(colors = col_use, guide = "colorbar", na.value = "transparent",
                                      limits = c(0, 1),
                                      breaks = c(0.1, 0.9), labels = c("Low", "High"))
    }else{
        p_adj1 <- scale_fill_gradientn(colors = col_use, guide = "colorbar", na.value = "transparent",
                                      limits = round(c(min(heat_table$color_scale, na.rm = T) *9/10, max(heat_table$color_scale, na.rm = T) * 11/10), 2),
                                      breaks = round(c(min(heat_table$color_scale, na.rm = T), max(heat_table$color_scale, na.rm = T)), 2),
                                      labels = c("Low", "High") )
    }
    p_33 <- p_33 + p_adj1 + p_adj11

    if(outcome == T & freq == T){
    	p_33 <- p_33 + geom_text(aes(label = outcome_prop), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = -0.5) +
                geom_text(aes(label = freq), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.9)
    }else if(outcome == T & freq == F){
        p_33 <- p_33 + geom_text(aes(label = outcome_prop), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = 0)
    }else if(outcome == F & freq == T){
        p_33 <- p_33 + geom_text(aes(label = freq), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.8)
    }

    if(SNP_info == T){
        A <- substr(x$maj_min[1,], 1,1)
        a <- substr(x$maj_min[1,], 3,3)
        B <- substr(x$maj_min[2,], 1,1)
        b <- substr(x$maj_min[2,], 3,3)
        p_33 <- p_33 + scale_x_discrete(position = "top",breaks = c("BB","Bb","bb"), labels = c(paste0(B,B), paste0(B,b), paste0(b,b)) ) +
            scale_y_discrete(breaks = c("AA","Aa","aa"), labels = c(paste0("   ", A,A), paste0("   ", A,a), paste0("   ", a,a)) ) +
            labs(x = rownames(x$maj_min)[2], y = rownames(x$maj_min)[1])
    }else{
        p_33 <- p_33 + scale_x_discrete(position = "top",breaks = c("BB","Bb","bb"), labels = c("BB","Bb","bb")) +
            scale_y_discrete(breaks = c("AA","Aa","aa"), labels = c("   AA","   Aa","   aa"))
    }

	if((any(is.nan(x$table3by3)) == TRUE) & (outcome == FALSE)){
	    warning("Some cells without observations, show outcome proportions to avoid misleading.")
	}

  if(marginal == T){

    cell_size <- x$table3by3Freq
    case_size <- x$table3by3Freq * x$table3by3
	  v_mar_Freq <- rowSums(cell_size, na.rm = T)
	  h_mar_Freq <- colSums(cell_size, na.rm = T)
	  v_mar_op <- rowSums(case_size, na.rm = T) / rowSums(cell_size, na.rm = T)
	  h_mar_op <- colSums(case_size, na.rm = T) / colSums(cell_size, na.rm = T)
		mar_df <- data.frame(xy = rep("Total", 3), SNP1 = snp1, SNP2 = snp2, Freq1 = paste0("(", rev(v_mar_Freq), ")"), Freq2 = paste0("(", h_mar_Freq, ")"),
							outcome_prop1 = rev(round(v_mar_op, 2)), outcome_prop2 = round(h_mar_op, 2) )
		tot_df <- data.frame(x = 1, y = 1, Freq = paste0("(", sum(x$table3by3Freq), ")"), outcome_prop = round(sum(case_size, na.rm = T)/sum(cell_size, na.rm = T), 2) )
		p_snp1 <- ggplot(mar_df, aes(xy, SNP1, z = outcome_prop1)) + geom_tile(aes(fill = outcome_prop1)) + scale_x_discrete(position = "top") + labs(x = " ") +
						theme(panel.background = element_blank(), axis.ticks = element_blank(), axis.line = element_blank(),
							  axis.title.y = element_blank(), legend.position="none", axis.title.x = element_text(size = 25*axis_fs),
			        		  axis.text.x = element_text(size = 20*axis_fs, angle = 0, color = "black"), axis.text.y = element_blank()) + p_adj1
		p_snp2 <- ggplot(mar_df, aes(SNP2, xy, z = outcome_prop2)) + geom_tile(aes(fill = outcome_prop2)) + scale_y_discrete(position = "left", breaks = "Total", labels = "Total") + labs(y = " ") +
						theme(panel.background = element_blank(), axis.ticks = element_blank(), axis.line = element_blank(),
							  axis.title.x = element_blank(), legend.position="none", axis.title.y = element_text(size = 25*axis_fs),
			        		  axis.text.y = element_text(size = 20*axis_fs, angle = 0, color = "black"), axis.text.x = element_blank()) + p_adj1
		p_tot <- ggplot(tot_df, aes(x, y, z = outcome_prop)) + geom_tile(aes(fill = outcome_prop)) + theme_void() + theme(legend.position="none") + p_adj1

		if(outcome == T & freq == T){
	    	p_snp1 <- p_snp1 + geom_text(aes(label = outcome_prop1), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = -0.5) +
	                geom_text(aes(label = Freq1), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.9)
	        p_snp2 <- p_snp2 + geom_text(aes(label = outcome_prop2), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = -0.5) +
	                geom_text(aes(label = Freq2), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.9)
	        p_tot <- p_tot + geom_text(aes(label = outcome_prop), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = -0.5) +
	                geom_text(aes(label = Freq), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.9)
	    }else if(outcome == T & freq == F){
	        p_snp1 <- p_snp1 + geom_text(aes(label = outcome_prop1), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = 0)
	    	p_snp2 <- p_snp2 + geom_text(aes(label = outcome_prop2), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = 0)
	        p_tot <- p_tot + geom_text(aes(label = outcome_prop), na.rm = T, size = 8*outcome_fs, fontface = "bold", vjust = 0)
	    }else if(outcome == F & freq == T){
	        p_snp1 <- p_snp1 + geom_text(aes(label = Freq1), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.8)
	        p_snp2 <- p_snp2 + geom_text(aes(label = Freq2), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.8)
	        p_tot <- p_tot + geom_text(aes(label = Freq), na.rm = T, size = 7*freq_fs, fontface = "bold", vjust = 0.8)
	    }

	    if(legend == F){
	    	p_mar <- ggpubr::ggarrange(p_33, p_snp1, p_snp2, p_tot,
										ncol = 2, nrow = 2,
										widths = c(5, 1), heights = c(5, 1),
										common.legend = TRUE, legend = "none")
	    }else{
	    	p_mar <- ggpubr::ggarrange(p_33, p_snp1, p_snp2, p_tot,
								        ncol = 2, nrow = 2,
								        widths = c(5, 1), heights = c(5, 1),
								        common.legend = TRUE, legend = "right")

	    }
	    return(p_mar)
    }else{
    	if(legend == F){
        p_33 <- p_33 + theme(legend.position = "none")
	    }
	    return(p_33)
    }
}

