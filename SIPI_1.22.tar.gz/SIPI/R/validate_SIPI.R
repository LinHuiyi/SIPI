

#Bootstrap method of internal validation for reducing false positivity in SNP-SNP interaction patterns:
#validate_SIPI: takes bootstrap samples, fits main effect SNPmain() and SNP-SNP interaction SIPI() models and then decide significance based on method2;

boot_res = function(data, snp1_name, snp2_name, outcomeName, XNames=NULL, categXNames=NULL, ModelType="binomial", pvalCutoff, n.boot, seed=NULL){
  info = c(snp1_name, snp2_name, outcomeName, XNames)
  short_df = data[ ,info, drop=FALSE]
  cname = colnames(short_df) 
  colnames(short_df)[which(cname==outcomeName)] = "response"    
  boot_sam_mod = function(short_df){
    b_sam = sample(1:dim(short_df)[1], size = dim(short_df)[1], replace=T)
    b_sam = short_df[b_sam, ,drop=FALSE]
    X1 <- b_sam[, XNames, drop=FALSE]
    if(dim(X1)[2]==0){X1 = NULL} else {X1}
    snp_indx = c(which(cname==snp1_name), which(cname==snp2_name))
    res_int = SIPI(Outcome=as.numeric(as.character(b_sam$response)), SNPdata=b_sam[ ,snp_indx, drop=FALSE], PairInfo=c(snp1_name, snp2_name), X=X1,
	categXNames=categXNames,ModelType=ModelType, OR=FALSE)$selectedModel 
    res_main = SNPmain(Outcome = as.numeric(as.character(b_sam$response)), SNPdata=b_sam[ ,snp_indx, drop=FALSE], PairInfo=c(snp1_name, snp2_name), X=X1, categXNames=categXNames, ModelType=ModelType)
    sig_status = ifelse(res_int$Wald_p <pvalCutoff & res_int$Wald_p < res_main$P.value[1] & res_int$Wald_p < res_main$P.value[2], "sig", "not_sig") 
    return(sig_status)
  }
  set.seed(seed)
  res = replicate(n=n.boot, boot_sam_mod(short_df), simplify = FALSE) 
  res <- do.call(rbind, Map(rbind, res))
  colnames(res) = paste(snp1_name, snp2_name, sep = "_")
  return(res)
}


validate_SIPI = function(data, PairList, outcomeName, XNames=NULL, categXNames=NULL, ModelType="binomial", pvalCutoff, n.boot=100, seed=NULL){
  data = as.data.frame(data) 
  if(!all(categXNames %in% XNames)) stop(paste('"', categXNames,'"', " must be in ", '"XNames"', sep=""))
  if(dim(PairList)[2]>2 | dim(PairList)[2]<2) stop("PairList (a dataframe) must have two columns: snp1 name and snp2 name")
  PairList = as.data.frame(PairList)
  colnames(PairList)[1:2] = c("snp1","snp2")
  sig_res = NULL
  for(i in 1:dim(PairList)[1]){
    sig_res=cbind(sig_res, boot_res(data=data, snp1_name=as.character(PairList$snp1[i]), snp2_name=as.character(PairList$snp2[i]), outcomeName=outcomeName,
             XNames=XNames, categXNames=categXNames, ModelType=ModelType, pvalCutoff=pvalCutoff, n.boot=n.boot, seed=seed))
    }           
  pair_names = colnames(sig_res)
  sig_pairs_prop = lapply(pair_names, function(x, y){mean(y[, x]=="sig")}, y=sig_res) 
  sig_pairs_prop = do.call(rbind, Map(rbind, sig_pairs_prop))
  sig_pairs_prop = data.frame(pair_names, sig_pairs_prop)
  colnames(sig_pairs_prop) = c("Pairs", "Prop_sig")
  return(sig_pairs_prop)
}

#*************************************************************************************************
#arguments:
#--------------------------------------------
#PairList = SNP Pairs: must be a data frame with two variables. 1st variable: SNP1 names of the pairs; 2nd variable: SNP2 names of the pairs. 
#outcomeName = Outcome variable name. Supported outcome types are binary (1: event of interest; 0: reference) or continuous variable.
#XNames = Name(s) covariate(s) to be adjusted in the model (for missing values, keep the field blank), NULL=without covariate. Default is NULL
#data = a data.frame/a data.table of all SNP variables, covariates to be adjusted and outcome variable (binary/continuous).
#All SNP variables should have a character variable attribute and contain two of four letters (C, T, A, and G). 
#No other letters or numbers should be used.
#categXNames = The variable names of categorical variables, NULL=without categorical covariates. Default is NULL.
#ModelType = "binomial"=logistic regression; "gaussian"=linear regression. Default is "binomial".
#pvalCutoff = Cut-point of pvalue to define significance. For example, Bonferroni criterion i.e., 0.05 divided by total number of pairs.
#n.boot = number of bootstrap samples; Default is 50.
#seed = use a specific seed to reproduce the results later on. Default is NULL.

#********************* Usage *****************

 # validate_SIPI(data, PairList, outcomeName, XNames = NULL, categXNames = NULL, ModelType = "binomial", pvalCutoff, n.boot = 100, seed = NULL)


#********************************************

