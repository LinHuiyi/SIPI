

#input:
#snp_main: SNP main effects output from SIPI SNPmain() function; it is a data frame
#sipi_int_res:


#function to add sig column in  SIPI SNP-SNP interaction results dataset

eval3pRule = function(MAINres, SIPIres, pvalCutoff){
      status =NULL
      SIPIres$Wald_p = signif(SIPIres$Wald_p, digits=5)
      for(i in 1:dim(SIPIres)[1]){
       snp1pval_id = which(MAINres$SNP == SIPIres$Var1[i])
       pval1 = signif(MAINres$P.value[snp1pval_id], digits=5)
       snp2pval_id = which(MAINres$SNP == SIPIres$Var2[i])
       pval2 = signif(MAINres$P.value[snp2pval_id], digits=5)
       status = rbind(status, c(pval1, pval2,
        ifelse(SIPIres$Wald_p[i]<pvalCutoff & SIPIres$Wald_p[i]<pval1 & SIPIres$Wald_p[i]<pval2,"sig","not_sig")))
       }
       colnames(status) = c("p_Var1", "p_Var2", "sig.status")
       SIPIres = data.frame(SIPIres, status)
       SIPIres$p_Var1 = as.numeric(as.character(SIPIres$p_Var1))
       SIPIres$p_Var2 = as.numeric(as.character(SIPIres$p_Var2))
       colnames(SIPIres)[which(colnames(SIPIres)=="Wald_p")] ="p_pair"
       SIPIres = SIPIres[, -4]
       print("Note: sig.status is based on p_pair < pvalCutoff & p_pair < p_Var1 & p_pair < p_Var2")
       return(SIPIres)
     }


 #***********************
 #arguments:
 #MAINres: SNP main effect results. That is, results data from evaluating SNPmain() function.
 #SIPIres: SIPI SNP-SNP interaction results. That is, results data from evaluating SIPI()$selectedModel function
 #pvalCutoff: Cut-point of pvalue to define significance. For example, Bonferroni criterion i.e., 0.05 divided by total number of pairs.

 #***********************
 #usage:
 #eval3pRule(MAINres, SIPIres, pvalCutoff)


 #*****************************


 #testing
 #library(SIPI)
 #data(simData)
 #MAINres = SNPmain(simData$D, SNPdata=simData[, 3:7], PairInfo="all")
 #SIPIres = SIPI(simData$D, SNPdata=simData[, 3:7], PairInfo="all")$selectedModel

 #res = eval3pRule(MAINres, SIPIres, pvalCutoff = 0.05/10)
 #res




