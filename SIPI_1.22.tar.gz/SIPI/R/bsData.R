

#Bootstrap method of internal validation for reducing false positivity in SNP-SNP interaction patterns:
#bsData() allows to extract bootstrap samples from validate_SIPI for a given SNP pair

bsData = function(data, SNPselect, Xname=NULL, IDname = NULL, outcomeName=NULL, n.boot=100, bindMethod = c("rowbind", "colbind"), seed=NULL){
  bindMethod = match.arg(bindMethod)
  data = as.data.frame(data)
  if(is.null(outcomeName)) warning("SNP data are not showing outcome variable. No 'outcomeName' was provided")
  if(is.null(Xname)) print("SNP data are not showing covariates. No 'Xname' was provided")
  info = c(IDname, outcomeName, SNPselect, Xname)
  short_df = data[ ,info, drop=FALSE]
  boot_sam = function(short_df){
    b_sam = sample(1:dim(short_df)[1], size = dim(short_df)[1], replace=T)
    b_sam = short_df[b_sam, ,drop=FALSE]
    return(b_sam)
  }
  set.seed(seed)
  res = replicate(n=n.boot, boot_sam(short_df), simplify = FALSE)
  if(bindMethod=="colbind"){
  res = do.call(cbind, Map(cbind, res))
  colnames(res) = paste(colnames(res),rep(1:n.boot, each=length(info)), sep="_")
  } else if(bindMethod=="rowbind"){
  res = do.call(rbind, Map(rbind, res))
  res = as.data.frame(cbind(sample_indx = rep(1:n.boot,each=dim(short_df)[1]), res))
  }
  row.names(res) = NULL
  return(res)
}

#*************************************************************************************************
#arguments:
#-----------------------------------------------
#SNPselect = c('SNP1','SNP2'): names of the SNPs; number of bootstrap samples=n.boot for the selected SNPs.
#outcomeName = Outcome variable name. Supported outcome types are binary (1: event of interest; 0: reference) or continuous variable.
#Xname = Covariate(s) to be adjusted in the model (for missing values, keep the field blank), NULL=without covariate. Default is NULL
#IDname = subject ID column name (e.g., PatientID). NULL=no subject ID to show in bootstrap samples; Default is NULL
#data = a data.frame/a data.table of all SNP variables, covariates to be adjusted and outcome variable (binary/continuous).
#n.boot = number of bootstrap samples; Default is 100.
#bindMethod = c('rowbind', 'colbind'): colbind merges bootstrap samples side by side (in column direction);
# rowbind appends bootstrap smaples one after another (in row direction) ; default bindMethod = 'rowbind'
#seed = use a specific seed to reproduce the results later on. Default is NULL.


#*************************** Usage *******************

#   bsData(data, SNPselect, Xname = NULL, IDname = NULL, outcomeName = NULL, n.boot = 100, bindMethod = "rowbind", seed=NULL)




#**************************************** Testing the function *************************
 # library(SIPI)
 # data(simData)
 #
 # snp1 = c("SNP1", "SNP1", "SNP1","SNP1","SNP1")
 # snp2 = c("SNP3", "SNP4", "SNP5", "SNP6", "SNP7")
 # snp = c(snp1, snp2)
 # #snp_pairs = data.frame(snp1, snp2)
 #
 # d = bsData(data=simData, SNPselect = c("SNP1","SNP2","SNP4"), Xname = c("age", "group"), IDname = "id", outcomeName="D",  n.boot=2, seed=200)
 # head(d)
 # dim(d)
 #
 # d = bsData(data=simData, SNPselect = c("SNP1","SNP2"), Xname = c("age", "group"), IDname = "id", outcomeName="D", n.boot=2, bindMethod="rowbind", seed=200)
 # head(d)
 # dim(d)
 #
 # d = bsData(data=simData, SNPselect = c("SNP1","SNP2"), Xname = c("age", "group"),  outcomeName="D", n.boot=2, seed=200)
 # head(d)
 # dim(d)
 #
 # d = bsData(data=simData, SNPselect = c("SNP1","SNP2"), Xname = c("age", "group"), n.boot=2, seed=200)
 # head(d)
 # dim(d)
 #
 # d = bsData(data=simData, SNPselect = c("SNP1","SNP2"), n.boot=2, seed=200)
 # head(d)
 # dim(d)




