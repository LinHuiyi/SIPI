###tryCatch
.waldtest = function(model1,model2,test_n){
  options(warn=-1)
  result = tryCatch({
    waldtest(model1,model2,test = test_n)
  }, error = function(w) {
    matrix(c(NA,NA),1,2,dimnames=list(c('a'),c('Chisq','Pr(>Chisq)2')))
  })
  return(result)
}
.lrtest = function(model1,model2){
  options(warn=-1)
  result = tryCatch({
    lrtest(model1,model2)
  }, error = function(w) {
    matrix(c(NA,NA),1,2,dimnames=list(c('a'),c('Chisq','Pr(>Chisq)2')))
  })
  return(result)
}

###function for 9 patterns
.SNP_int_9_c = function(Outcome,Adata,Bdata,X,TestType,ModelType){
  X = data.frame(X)
  wholeABData = cbind(Outcome,Adata,Bdata,X)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }

  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  X = wholeABData[,4:dim(wholeABData)[2]]
  X = data.frame(X)

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  data_OAB = data.frame(Outcome=Outcome,Adata=Adata,Bdata=Bdata,
                        rAdata=rAdata,rBdata=rBdata)
  data_OABX = cbind(data_OAB,X)

  biccon = log(length(Outcome))
  lenX = dim(X)[2]

  X_names =  paste(colnames(X), collapse= "+")

  model1_for = as.formula(paste("Outcome~Adata+Bdata+Adata:Bdata+",
                                X_names))
  model1 = glm(model1_for,data=data_OABX,family=ModelType)

  model2_for = as.formula(paste("Outcome~Adata+Adata:Bdata+",
                                X_names))
  model2 = glm(model2_for,data=data_OABX,family=ModelType)

  model3_for = as.formula(paste("Outcome~rAdata+rAdata:Bdata+",
                                X_names))
  model3 = glm(model3_for,data=data_OABX,family=ModelType)

  model4_for = as.formula(paste("Outcome~Bdata+Adata:Bdata+",
                                X_names))
  model4 = glm(model4_for,data=data_OABX,family=ModelType)

  model5_for = as.formula(paste("Outcome~rBdata+Adata:rBdata+",
                                X_names))
  model5 = glm(model5_for,data=data_OABX,family=ModelType)

  model6_for = as.formula(paste("Outcome~Adata:Bdata+",
                                X_names))
  model6 = glm(model6_for,data=data_OABX,family=ModelType)

  model7_for = as.formula(paste("Outcome~rAdata:Bdata+",
                                X_names))
  model7 = glm(model7_for,data=data_OABX,family=ModelType)

  model8_for = as.formula(paste("Outcome~Adata:rBdata+",
                                X_names))
  model8 = glm(model8_for,data=data_OABX,family=ModelType)

  model9_for = as.formula(paste("Outcome~rAdata:rBdata+",
                                X_names))
  model9 = glm(model9_for,data=data_OABX,family=ModelType)

  model0_for = as.formula(paste("Outcome~",
                                X_names))
  model0 = glm(model0_for,data=data_OABX,family=ModelType)

  Res = matrix(numeric(0),9,5)

  if (is.na(model1$coefficients[length(model1$coefficients)])){
    Res[1,] = NA
  }else{
    coeff = summary(model1)$coefficients[,c(1,2)]
    Res[1,1:2] = coeff[dim(coeff)[1],]
    Res[1,5] = extractAIC(model1,k=biccon)[2]
    model1_for = as.formula(paste("Outcome~Adata+Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc =glm(model1_for,data=data_OABX,family=ModelType)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
    }else{
      modelc = glm(model1_for,data=data_OABX,family=ModelType)
      anova = unlist(.lrtest(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (is.na(model2$coefficients[length(model2$coefficients)])){
    Res[2,] = NA
  }else{
    coeff = summary(model2)$coefficients[,c(1,2)]
    Res[2,1:2] = coeff[dim(coeff)[1],]
    Res[2,5] = extractAIC(model2,k=biccon)[2]
    model2_for = as.formula(paste("Outcome~Adata+",
                                  X_names))
    if (is.waldtest){
      modelc = glm(model2_for,data=data_OABX,family=ModelType)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
    }else{
      modelc = glm(model2_for,data=data_OABX,family=ModelType)
      anova = unlist(.lrtest(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (is.na(model3$coefficients[length(model3$coefficients)])){
    Res[3,] = NA
  }else{
    coeff = summary(model3)$coefficients[,c(1,2)]
    Res[3,1:2] = coeff[dim(coeff)[1],]
    Res[3,5] = extractAIC(model3,k=biccon)[2]
    model3_for = as.formula(paste("Outcome~rAdata+",
                                  X_names))
    if (is.waldtest){
      modelc = glm(model3_for,data=data_OABX,family=ModelType)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
    }else{
      modelc = glm(model3_for,data=data_OABX,family=ModelType)
      anova = unlist(.lrtest(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (is.na(model4$coefficients[length(model4$coefficients)])){
    Res[4,] = NA
  }else{
    coeff = summary(model4)$coefficients[,c(1,2)]
    Res[4,1:2] = coeff[dim(coeff)[1],]
    Res[4,5] = extractAIC(model4,k=biccon)[2]
    model4_for = as.formula(paste("Outcome~Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc = glm(model4_for,data=data_OABX,family=ModelType)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
    }else{
      modelc = glm(model4_for,data=data_OABX,family=ModelType)
      anova = unlist(.lrtest(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (is.na(model5$coefficients[length(model5$coefficients)])){
    Res[5,] = NA
  }else{
    coeff = summary(model5)$coefficients[,c(1,2)]
    Res[5,1:2] = coeff[dim(coeff)[1],]
    Res[5,5] = extractAIC(model5,k=biccon)[2]
    model5_for = as.formula(paste("Outcome~rBdata+",
                                  X_names))
    if (is.waldtest){
      modelc = glm(model5_for,data=data_OABX,family=ModelType)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
    }else{
      modelc = glm(model5_for,data=data_OABX,family=ModelType)
      anova = unlist(.lrtest(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (is.na(model6$coefficients[length(model6$coefficients)])){
    Res[6,] = NA
  }else{
    coeff = summary(model6)$coefficients[,c(1,2)]
    Res[6,1:2] = coeff[dim(coeff)[1],]
    Res[6,5] = extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model6,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model6))
    }
    Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (is.na(model7$coefficients[length(model7$coefficients)])){
    Res[7,] = NA
  }else{
    coeff = summary(model7)$coefficients[,c(1,2)]
    Res[7,1:2] = coeff[dim(coeff)[1],]
    Res[7,5] = extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model7,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model7))
    }
    Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (is.na(model8$coefficients[length(model8$coefficients)])){
    Res[8,] = NA
  }else{
    coeff = summary(model8)$coefficients[,c(1,2)]
    Res[8,1:2] = coeff[dim(coeff)[1],]
    Res[8,5] = extractAIC(model8,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova = unlist(.waldtest(model0,model8,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model8))
    }
    Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (is.na(model9$coefficients[length(model9$coefficients)])){
    Res[9,] = NA
  }else{
    coeff = summary(model9)$coefficients[,c(1,2)]
    Res[9,1:2] = coeff[dim(coeff)[1],]
    Res[9,5] = extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model9,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model9))
    }
    Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }

  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}



.SNP_int_9_nc = function(Outcome,Adata,Bdata,TestType,ModelType){
  wholeABData = cbind(Outcome,Adata,Bdata)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }
  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  wholeABData = NULL

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  model1 = glm(Outcome~Adata+Bdata+Adata:Bdata,family=ModelType)
  model2 = glm(Outcome~Adata+Adata:Bdata,family=ModelType)
  model3 = glm(Outcome~rAdata+rAdata:Bdata,family=ModelType)
  model4 = glm(Outcome~Bdata+Adata:Bdata,family=ModelType)
  model5 = glm(Outcome~rBdata+Adata:rBdata,family=ModelType)
  model6 = glm(Outcome~Adata:Bdata,family=ModelType)
  model7 = glm(Outcome~rAdata:Bdata,family=ModelType)
  model8 = glm(Outcome~Adata:rBdata,family=ModelType)
  model9 = glm(Outcome~rAdata:rBdata,family=ModelType)

  biccon = log(length(Outcome))

  model0 = glm(Outcome~1,family=ModelType)
  Res = matrix(numeric(0),9,5)
  if (dim(summary(model1)$coefficients)[1]<4){
    Res[1,] = NA
  }else{
    Res[1,1:2] = summary(model1)$coefficients[4,c(1,2)]
    Res[1,5] = extractAIC(model1,k=biccon)[2]
    if (is.waldtest){
      modelc = glm(Outcome~Adata+Bdata,family=ModelType)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
    }else{
      modelc = glm(Outcome~Adata+Bdata,family=ModelType)
      anova = unlist(.lrtest(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (dim(summary(model2)$coefficients)[1]<3){
    Res[2,] = NA
  }else{
    Res[2,1:2] = summary(model2)$coefficients[3,c(1,2)]
    Res[2,5] = extractAIC(model2,k=biccon)[2]
    if (is.waldtest){
      modelc = glm(Outcome~Adata,family=ModelType)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
    }else{
      modelc = glm(Outcome~Adata,family=ModelType)
      anova = unlist(.lrtest(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (dim(summary(model3)$coefficients)[1]<3){
    Res[3,] = NA
  }else{
    Res[3,1:2] = summary(model3)$coefficients[3,c(1,2)]
    Res[3,5] = extractAIC(model3,k=biccon)[2]
    if (is.waldtest){
      modelc = glm(Outcome~rAdata,family=ModelType)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
    }else{
      modelc = glm(Outcome~rAdata,family=ModelType)
      anova = unlist(.lrtest(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (dim(summary(model4)$coefficients)[1]<3){
    Res[4,] = NA
  }else{
    Res[4,1:2] = summary(model4)$coefficients[3,c(1,2)]
    Res[4,5] = extractAIC(model4,k=biccon)[2]

    if (is.waldtest){
      modelc = glm(Outcome~Bdata,family=ModelType)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
    }else{
      modelc = glm(Outcome~Bdata,family=ModelType)
      anova = unlist(.lrtest(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (dim(summary(model5)$coefficients)[1]<3){
    Res[5,] = NA
  }else{
    Res[5,1:2] = summary(model5)$coefficients[3,c(1,2)]
    Res[5,5] = extractAIC(model5,k=biccon)[2]
    if (is.waldtest){
      modelc = glm(Outcome~rBdata,family=ModelType)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
    }else{
      modelc = glm(Outcome~rBdata,family=ModelType)
      anova = unlist(.lrtest(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (dim(summary(model6)$coefficients)[1]<2){
    Res[6,] = NA
  }else{
    Res[6,1:2] = summary(model6)$coefficients[2,c(1,2)]
    Res[6,5] = extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model6,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model6))
    }
    Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (dim(summary(model7)$coefficients)[1]<2){
    Res[7,] = NA
  }else{
    Res[7,1:2] = summary(model7)$coefficients[2,c(1,2)]
    Res[7,5] = extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model7,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model7))
    }
    Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (dim(summary(model8)$coefficients)[1]<2){
    Res[8,] = NA
  }else{
    Res[8,1:2] = summary(model8)$coefficients[2,c(1,2)]
    Res[8,5] = extractAIC(model8,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model8,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model8))
    }
    Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (dim(summary(model9)$coefficients)[1]<2){
    Res[9,] = NA
  }else{
    Res[9,1:2] = summary(model9)$coefficients[2,c(1,2)]
    Res[9,5] = extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model9,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model9))
    }
    Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }

  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}

#############
.SNP_int_9_c_1 = function(Outcome,Adata,Bdata,X,TestType,ModelType){
  X = data.frame(X)
  wholeABData = cbind(Outcome,Adata,Bdata,X)
  vdata = complete.cases(wholeABData)
  wholeABData = wholeABData[vdata,]
  is.waldtest = (TestType=='WaldTest')
  min_sample = length(names(wholeABData)) + 3
  if (sum(vdata)<min_sample){
    Res = matrix(rep(NA,45),9,5)
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    if (is.waldtest){
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
    }else{
      colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
    }
    return(Res)
  }

  Outcome = wholeABData[,1]
  Adata = wholeABData[,2]
  Bdata = wholeABData[,3]
  X = wholeABData[,4:dim(wholeABData)[2]]
  X = data.frame(X)
  wholeABData = NULL

  if (sum(Adata==2)>0){
    rAdata = abs(2-Adata)
    rBdata = abs(2-Bdata)
  }else{
    rAdata = 1-Adata
    rBdata = 1-Bdata
  }
  data_OAB = data.frame(Outcome=Outcome,Adata=Adata,Bdata=Bdata,
                        rAdata=rAdata,rBdata=rBdata)
  data_OABX = cbind(data_OAB,X)

  data_OAB = NULL

  biccon = log(length(Outcome))
  lenX = dim(X)[2]

  X_names =  paste(colnames(X), collapse= "+")
  rm(Outcome,Adata,Bdata,rAdata,rBdata,X,data_OAB)

  model1_for = as.formula(paste("Outcome~Adata+Bdata+Adata:Bdata+",
                                X_names))
  model1 = glm(model1_for,data=data_OABX,family=ModelType)

  model2_for = as.formula(paste("Outcome~Adata+Adata:Bdata+",
                                X_names))
  model2 = glm(model2_for,data=data_OABX,family=ModelType)

  model3_for = as.formula(paste("Outcome~rAdata+rAdata:Bdata+",
                                X_names))
  model3 = glm(model3_for,data=data_OABX,family=ModelType)

  model4_for = as.formula(paste("Outcome~Bdata+Adata:Bdata+",
                                X_names))
  model4 = glm(model4_for,data=data_OABX,family=ModelType)

  model5_for = as.formula(paste("Outcome~rBdata+Adata:rBdata+",
                                X_names))
  model5 = glm(model5_for,data=data_OABX,family=ModelType)

  model6_for = as.formula(paste("Outcome~Adata:Bdata+",
                                X_names))
  model6 = glm(model6_for,data=data_OABX,family=ModelType)

  model7_for = as.formula(paste("Outcome~rAdata:Bdata+",
                                X_names))
  model7 = glm(model7_for,data=data_OABX,family=ModelType)

  model8_for = as.formula(paste("Outcome~Adata:rBdata+",
                                X_names))
  model8 = glm(model8_for,data=data_OABX,family=ModelType)

  model9_for = as.formula(paste("Outcome~rAdata:rBdata+",
                                X_names))
  model9 = glm(model9_for,data=data_OABX,family=ModelType)


  model0_for = as.formula(paste("Outcome~",
                                X_names))
  model0 = glm(model0_for,data=data_OABX,family=ModelType)

  Res = matrix(numeric(0),9,5)

  if (is.na(model1$coefficients[length(model1$coefficients)])){
    Res[1,] = NA
  }else{
    Res[1,5] = extractAIC(model1,k=biccon)[2]
    model1_for = as.formula(paste("Outcome~Adata+Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc = glm(model1_for,data=data_OABX,family=ModelType)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
    }else{
      modelc = glm(model1_for,data=data_OABX,family=ModelType)
      anova = unlist(.lrtest(modelc,model1))
    }
    Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[1,]=NA}
  }
  if (is.na(model2$coefficients[length(model2$coefficients)])){
    Res[2,] = NA
  }else{
    Res[2,5] = extractAIC(model2,k=biccon)[2]
    model2_for = as.formula(paste("Outcome~Adata+",
                                  X_names))
    if (is.waldtest){
      modelc = glm(model2_for,data=data_OABX,family=ModelType)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
    }else{
      modelc = glm(model2_for,data=data_OABX,family=ModelType)
      anova = unlist(.lrtest(modelc,model2))
    }
    Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[2,]=NA}
  }
  if (is.na(model3$coefficients[length(model3$coefficients)])){
    Res[3,] = NA
  }else{
    Res[3,5] = extractAIC(model3,k=biccon)[2]
    model3_for = as.formula(paste("Outcome~rAdata+",
                                  X_names))
    if (is.waldtest){
      modelc = glm(model3_for,data=data_OABX,family=ModelType)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
    }else{
      modelc = glm(model3_for,data=data_OABX,family=ModelType)
      anova = unlist(.lrtest(modelc,model3))
    }
    Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[3,]=NA}
  }
  if (is.na(model4$coefficients[length(model4$coefficients)])){
    Res[4,] = NA
  }else{
    Res[4,5] = extractAIC(model4,k=biccon)[2]
    model4_for = as.formula(paste("Outcome~Bdata+",
                                  X_names))
    if (is.waldtest){
      modelc = glm(model4_for,data=data_OABX,family=ModelType)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
    }else{
      modelc = glm(model4_for,data=data_OABX,family=ModelType)
      anova = unlist(.lrtest(modelc,model4))
    }
    Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[4,]=NA}
  }
  if (is.na(model5$coefficients[length(model5$coefficients)])){
    Res[5,] = NA
  }else{
    Res[5,5] = extractAIC(model5,k=biccon)[2]
    model5_for = as.formula(paste("Outcome~rBdata+",
                                  X_names))
    if (is.waldtest){
      modelc = glm(model5_for,data=data_OABX,family=ModelType)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
    }else{
      modelc = glm(model5_for,data=data_OABX,family=ModelType)
      anova = unlist(.lrtest(modelc,model5))
    }
    Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[5,]=NA}
  }
  if (is.na(model6$coefficients[length(model6$coefficients)])){
    Res[6,] = NA
  }else{
    Res[6,5] = extractAIC(model6,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model6,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model6))
    }
    Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[6,]=NA}
  }
  if (is.na(model7$coefficients[length(model7$coefficients)])){
    Res[7,] = NA
  }else{
    Res[7,5] = extractAIC(model7,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model7,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model7))
    }
    Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[7,]=NA}
  }
  if (is.na(model8$coefficients[length(model8$coefficients)])){
    Res[8,] = NA
  }else{
    Res[8,5] = extractAIC(model8,k=biccon)[2]
    if (TestType=='WaldTest'){
      anova = unlist(.waldtest(model0,model8,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model8))
    }
    Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[8,]=NA}
  }
  if (is.na(model9$coefficients[length(model9$coefficients)])){
    Res[9,] = NA
  }else{
    Res[9,5] = extractAIC(model9,k=biccon)[2]
    if (is.waldtest){
      anova = unlist(.waldtest(model0,model9,test="Chisq"))
    }else{
      anova = unlist(.lrtest(model0,model9))
    }
    Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
    if (is.na(anova["Chisq2"])){Res[9,]=NA}
  }

  rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
  if (is.waldtest){
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}


.SNP_int_9_nc_1 = function(Outcome,Adata,Bdata,TestType,ModelType){
  if (TestType=='WaldTest'){
    wholeABData = cbind(Outcome,Adata,Bdata)
    vdata = complete.cases(wholeABData)
    wholeABData = wholeABData[vdata,]
    min_sample = length(names(wholeABData)) + 3
    if (sum(vdata)<min_sample){
      Res = matrix(rep(NA,45),9,5)
      rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
      return(Res)
    }

    Outcome = wholeABData[,1]
    Adata = wholeABData[,2]
    Bdata = wholeABData[,3]
    if (sum(Adata==2)>0){
      rAdata = abs(2-Adata)
      rBdata = abs(2-Bdata)
    }else{
      rAdata = 1-Adata
      rBdata = 1-Bdata
    }
    model1 = glm(Outcome~Adata+Bdata+Adata:Bdata,family=ModelType)
    model2 = glm(Outcome~Adata+Adata:Bdata,family=ModelType)
    model3 = glm(Outcome~rAdata+rAdata:Bdata,family=ModelType)
    model4 = glm(Outcome~Bdata+Adata:Bdata,family=ModelType)
    model5 = glm(Outcome~rBdata+Adata:rBdata,family=ModelType)
    model6 = glm(Outcome~Adata:Bdata,family=ModelType)
    model7 = glm(Outcome~rAdata:Bdata,family=ModelType)
    model8 = glm(Outcome~Adata:rBdata,family=ModelType)
    model9 = glm(Outcome~rAdata:rBdata,family=ModelType)

    biccon = log(length(Outcome))
    model0 = glm(Outcome~1,family=ModelType)

    Res = matrix(numeric(0),9,5)
    if (dim(summary(model1)$coefficients)[1]<4){
      Res[1,] = NA
    }else{
      Res[1,5] = extractAIC(model1,k=biccon)[2]
      modelc = glm(Outcome~Adata+Bdata,family=ModelType)
      anova = unlist(.waldtest(modelc,model1,test="Chisq"))
      Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[1,]=NA}
    }
    if (dim(summary(model2)$coefficients)[1]<3){
      Res[2,] = NA
    }else{
      Res[2,5] = extractAIC(model2,k=biccon)[2]
      modelc = glm(Outcome~Adata,family=ModelType)
      anova = unlist(.waldtest(modelc,model2,test="Chisq"))
      Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[2,]=NA}
    }
    if (dim(summary(model3)$coefficients)[1]<3){
      Res[3,] = NA
    }else{
      Res[3,5] = extractAIC(model3,k=biccon)[2]
      modelc = glm(Outcome~rAdata,family=ModelType)
      anova = unlist(.waldtest(modelc,model3,test="Chisq"))
      Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[3,]=NA}
    }
    if (dim(summary(model4)$coefficients)[1]<3){
      Res[4,] = NA
    }else{
      Res[4,5] = extractAIC(model4,k=biccon)[2]
      modelc=glm(Outcome~Bdata,family=ModelType)
      anova = unlist(.waldtest(modelc,model4,test="Chisq"))
      Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[4,]=NA}
    }
    if (dim(summary(model5)$coefficients)[1]<3){
      Res[5,] = NA
    }else{
      Res[5,5] = extractAIC(model5,k=biccon)[2]
      modelc = glm(Outcome~rBdata,family=ModelType)
      anova = unlist(.waldtest(modelc,model5,test="Chisq"))
      Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[5,]=NA}
    }
    if (dim(summary(model6)$coefficients)[1]<2){
      Res[6,] = NA
    }else{
      Res[6,5] = extractAIC(model6,k=biccon)[2]
      anova = unlist(.waldtest(model0,model6,test="Chisq"))
      Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[6,]=NA}
    }
    if (dim(summary(model7)$coefficients)[1]<2){
      Res[7,] = NA
    }else{
      Res[7,5] = extractAIC(model7,k=biccon)[2]
      anova = unlist(.waldtest(model0,model7,test="Chisq"))
      Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[7,]=NA}
    }
    if (dim(summary(model8)$coefficients)[1]<2){
      Res[8,] = NA
    }else{
      Res[8,5] = extractAIC(model8,k=biccon)[2]
      anova = unlist(.waldtest(model0,model8,test="Chisq"))
      Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[8,]=NA}
    }
    if (dim(summary(model9)$coefficients)[1]<2){
      Res[9,] = NA
    }else{
      Res[9,5] = extractAIC(model9,k=biccon)[2]
      anova = unlist(.waldtest(model0,model9,test="Chisq"))
      Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[9,]=NA}
    }
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
  }else{
    wholeABData = cbind(Outcome,Adata,Bdata)
    vdata = complete.cases(wholeABData)
    wholeABData = wholeABData[vdata,]
    min_sample = length(names(wholeABData)) + 3
    if (sum(vdata)<min_sample){
      Res = matrix(rep(NA,45),9,5)
      rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
      colnames(Res) = c("Est.","Std.Er","Wald_Chisq","Wald_p","BIC")
      return(Res)
    }
    Outcome = wholeABData[,1]
    Adata = wholeABData[,2]
    Bdata = wholeABData[,3]
    wholeABData = NULL

    if (sum(Adata==2)>0){
      rAdata = abs(2-Adata)
      rBdata = abs(2-Bdata)
    }else{
      rAdata = 1-Adata
      rBdata = 1-Bdata
    }

    model1 = glm(Outcome~Adata+Bdata+Adata:Bdata,family=ModelType)
    model2 = glm(Outcome~Adata+Adata:Bdata,family=ModelType)
    model3 = glm(Outcome~rAdata+rAdata:Bdata,family=ModelType)
    model4 = glm(Outcome~Bdata+Adata:Bdata,family=ModelType)
    model5 = glm(Outcome~rBdata+Adata:rBdata,family=ModelType)
    model6 = glm(Outcome~Adata:Bdata,family=ModelType)
    model7 = glm(Outcome~rAdata:Bdata,family=ModelType)
    model8 = glm(Outcome~Adata:rBdata,family=ModelType)
    model9 = glm(Outcome~rAdata:rBdata,family=ModelType)

    biccon = log(length(Outcome))

    model0 = glm(Outcome~1,family=ModelType)
    Res = matrix(0,9,5)
    if (dim(summary(model1)$coefficients)[1]<4){
      Res[1,] = NA
    }else{
      Res[1,5] = extractAIC(model1,k=biccon)[2]
      modelc = glm(Outcome~Adata+Bdata,family=ModelType)
      anova = unlist(.lrtest(modelc,model1))
      Res[1,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[1,]=NA}
    }
    if (dim(summary(model2)$coefficients)[1]<3){
      Res[2,] = NA
    }else{
      Res[2,5] = extractAIC(model2,k=biccon)[2]
      modelc = glm(Outcome~Adata,family=ModelType)
      anova = unlist(.lrtest(modelc,model2))
      Res[2,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[2,]=NA}
    }
    if (dim(summary(model3)$coefficients)[1]<3){
      Res[3,] = NA
    }else{
      Res[3,5] = extractAIC(model3,k=biccon)[2]
      modelc = glm(Outcome~rAdata,family=ModelType)
      anova = unlist(.lrtest(modelc,model3))
      Res[3,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[3,]=NA}
    }
    if (dim(summary(model4)$coefficients)[1]<3){
      Res[4,] = NA
    }else{
      Res[4,5] = extractAIC(model4,k=biccon)[2]
      modelc = glm(Outcome~Bdata,family=ModelType)
      anova = unlist(.lrtest(modelc,model4))
      Res[4,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[4,]=NA}
    }
    if (dim(summary(model5)$coefficients)[1]<3){
      Res[5,] = NA
    }else{
      Res[5,5] = extractAIC(model5,k=biccon)[2]
      modelc = glm(Outcome~rBdata,family=ModelType)
      anova = unlist(.lrtest(modelc,model5))
      Res[5,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[5,]=NA}
    }
    if (dim(summary(model6)$coefficients)[1]<2){
      Res[6,] = NA
    }else{
      Res[6,5] = extractAIC(model6,k=biccon)[2]
      anova = unlist(.lrtest(model0,model6))
      Res[6,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[6,]=NA}
    }
    if (dim(summary(model7)$coefficients)[1]<2){
      Res[7,] = NA
    }else{
      Res[7,5] = extractAIC(model7,k=biccon)[2]
      anova = unlist(.lrtest(model0,model7))
      Res[7,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[7,]=NA}
    }
    if (dim(summary(model8)$coefficients)[1]<2){
      Res[8,] = NA
    }else{
      Res[8,5] = extractAIC(model8,k=biccon)[2]
      anova = unlist(.lrtest(model0,model8))
      Res[8,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[8,]=NA}
    }
    if (dim(summary(model9)$coefficients)[1]<2){
      Res[9,] = NA
    }else{
      Res[9,5] = extractAIC(model9,k=biccon)[2]
      anova = unlist(.lrtest(model0,model9))
      Res[9,3:4] = c(anova["Chisq2"],anova["Pr(>Chisq)2"])
      if (is.na(anova["Chisq2"])){Res[9,]=NA}
    }
    rownames(Res) = c("Full","M1_int_o1","M1_int_r1","M2_int_o2","M2_int_r2","int_oo","int_ro","int_or","int_rr")
    colnames(Res) = c("Est.","Std.Er","LRT_Chisq","LRT_p","BIC")
  }
  return(Res)
}
####################

